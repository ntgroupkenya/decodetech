import { renderToString } from "react-dom/server";
import { Link, Route, Routes, StaticRouter, useLocation, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, ArrowRight, ArrowUpRight, BadgeDollarSign, BadgePercent, Boxes, Check, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, Clock, Cpu, Download, ExternalLink, Eye, FileSpreadsheet, FileText, Filter, Flame, Gift, Globe, Handshake, Headphones, Inbox, LayoutDashboard, LayoutGrid, Lightbulb, List, LogOut, Mail, MapPin, Menu, MessageCircle, MessagesSquare, Minus, MousePointerClick, Newspaper, PackageCheck, PackageOpen, PackageSearch, Pencil, Phone, Plus, Rocket, Search, Send, Settings, ShieldCheck, ShoppingCart, Sparkles, Tag, Target, Ticket, Trash2, Trophy, Truck, Upload, User, Users, Wallet, Wrench, X, Zap, ZoomIn } from "lucide-react";
import Papa from "papaparse";
var ROOT_DOMAIN = (typeof process !== "undefined" ? process.env.VITE_ROOT_DOMAIN : "") || "example.com";
var MAIN_HOST = `www.${ROOT_DOMAIN}`;
var SHOP_HOST = `shop.${ROOT_DOMAIN}`;
var ADMIN_HOST = `admin.${ROOT_DOMAIN}`;
var MAIN_URL = `https://${MAIN_HOST}`;
var SHOP_URL = `https://${SHOP_HOST}`;
var ADMIN_URL = `https://${ADMIN_HOST}`;
var isShopPath = (path) => path === "/shop" || path.startsWith("/shop/");
var isAdminPath = (path) => path === "/admin" || path.startsWith("/admin/");
function targetHost(path) {
	if (isShopPath(path)) return "shop";
	if (isAdminPath(path)) return "admin";
	if (path === "/login" || path === "/signup") return "any";
	return "main";
}
function hostKind(pathname) {
	if (typeof window === "undefined") {
		if (!globalThis.__SSR_SITE__) return null;
		return isShopPath(pathname) ? "shop" : "main";
	}
	const host = window.location.hostname;
	if (host === SHOP_HOST) return "shop";
	if (host === ADMIN_HOST) return "admin";
	if (host === MAIN_HOST || host === ROOT_DOMAIN) return "main";
	return null;
}
function logicalPath(pathname) {
	return pathname === "/" && hostKind(pathname) === "shop" ? "/shop" : pathname;
}
function siteHref(host, path) {
	if (host === "shop") return `${SHOP_URL}${path === "/shop" ? "/" : path}`;
	if (host === "admin") return `${ADMIN_URL}${path}`;
	return `${MAIN_URL}${path}`;
}
function crossHref(path, pathname = typeof window === "undefined" ? "/" : window.location.pathname) {
	const here = hostKind(pathname);
	const target = targetHost(path);
	if (here && target !== "any" && target !== here) return siteHref(target, path);
	if (here === "admin" && target === "any") return siteHref("main", path);
	return here === "shop" && path === "/shop" ? "/" : path;
}
function apiOrigin() {
	if (typeof window === "undefined") return "";
	const here = hostKind(window.location.pathname);
	return here === "shop" || here === "admin" ? MAIN_URL : "";
}
//#endregion
//#region src/components/SiteLink.jsx
function SiteLink({ to, state, children, ...props }) {
	const { pathname } = useLocation();
	const here = hostKind(pathname);
	const target = targetHost(to);
	if (here && target !== "any" && target !== here) return /* @__PURE__ */ jsx("a", {
		href: siteHref(target, to),
		...props,
		children
	});
	return /* @__PURE__ */ jsx(Link, {
		to: here === "shop" && to === "/shop" ? "/" : to,
		state,
		...props,
		children
	});
}
//#endregion
//#region src/auth/AuthContext.js
var AuthContext = createContext({
	user: null,
	ready: false,
	login: async () => {},
	signup: async () => {},
	logout: async () => {},
	setUser: () => {}
});
//#endregion
//#region src/auth/useAuth.js
function useAuth() {
	return useContext(AuthContext);
}
//#endregion
//#region src/cart/CartContext.js
var CartContext = createContext({
	items: [],
	count: 0,
	isOpen: false,
	notice: null,
	add: () => {},
	setQty: () => {},
	remove: () => {},
	clear: () => {},
	open: () => {},
	close: () => {}
});
//#endregion
//#region src/cart/useCart.js
function useCart() {
	return useContext(CartContext);
}
//#endregion
//#region src/api.js
var API_BASE = "".replace(/\/$/, "");
var apiUrl = (path) => `${API_BASE || apiOrigin()}${path}`;
function assetUrl(src) {
	if (!src) return src;
	return src.startsWith("/uploads/") ? `${API_BASE}${src}` : src;
}
async function api(path, { method = "GET", body, form } = {}) {
	const headers = {};
	let payload;
	if (form) {
		payload = form;
		headers["X-Requested-With"] = "fetch";
	} else if (body !== void 0) {
		headers["Content-Type"] = "application/json";
		payload = JSON.stringify(body);
	}
	if (method === "DELETE") headers["X-Requested-With"] = "fetch";
	const res = await fetch(apiUrl(`/api${path}`), {
		method,
		headers,
		body: payload,
		credentials: "include"
	});
	let data = null;
	try {
		data = await res.json();
	} catch {}
	if (!res.ok) {
		const error = new Error(data?.error || `Request failed (${res.status})`);
		error.status = res.status;
		throw error;
	}
	return data;
}
function post(path, body) {
	try {
		fetch(apiUrl(`/api${path}`), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(body),
			keepalive: true,
			credentials: "include"
		}).catch(() => {});
	} catch {}
}
function trackWhatsApp({ label = "", productId = "", message = "" } = {}) {
	post("/track", {
		type: "whatsapp_click",
		label,
		productId,
		message,
		page: logicalPath(window.location.pathname)
	});
}
function trackProductClick({ productId, label = "" }) {
	post("/track", {
		type: "product_click",
		label,
		productId,
		page: logicalPath(window.location.pathname)
	});
}
function recordOrder({ productId, productName, message, offerIds = [], quantity = 1, deliveryAddress = "", cartRef = "" }) {
	post("/orders", {
		productId,
		productName,
		message,
		offerIds,
		quantity,
		deliveryAddress,
		cartRef
	});
}
function recordMessage(data) {
	post("/messages", data);
}
//#endregion
//#region src/siteDefaults.js
var SITE_NAME = "JOJO Tech Solutions Ltd";
var TAGLINE = "Powering Your Digital Future";
var DEFAULT_SETTINGS = {
	contact: {
		email: "info@jojotechsolutions.co.ke",
		email2: "",
		address: "Moi Avenue\nNairobi",
		whatsapp: "254704343633",
		mobilePhone: "",
		officePhone: "+254 704 343633"
	},
	hours: [{
		days: "Monday - Saturday",
		time: "8:00 AM - 6:00 PM"
	}, {
		days: "Sunday",
		time: "Closed"
	}],
	announcement: {
		enabled: false,
		text: "",
		link: ""
	},
	social: [
		{
			id: "facebook",
			label: "Facebook",
			url: ""
		},
		{
			id: "x",
			label: "X",
			url: ""
		},
		{
			id: "linkedin",
			label: "LinkedIn",
			url: ""
		},
		{
			id: "tiktok",
			label: "TikTok",
			url: ""
		}
	]
};
var digitsOnly = (value) => String(value || "").replace(/\D+/g, "");
function telHref(value) {
	let digits = digitsOnly(value);
	if (digits.startsWith("0")) digits = `254${digits.slice(1)}`;
	return `tel:+${digits}`;
}
function displayPhone(value) {
	const digits = digitsOnly(value);
	const kenya = digits.match(/^254(\d{3})(\d{6})$/);
	return kenya ? `+254 ${kenya[1]} ${kenya[2]}` : `+${digits}`;
}
var whatsappLink = (settings) => `https://wa.me/${digitsOnly(settings.contact.whatsapp)}`;
//#endregion
//#region src/siteSettings.js
var preloadedFrom = null;
var preloadedValue = DEFAULT_SETTINGS;
function preloaded() {
	const saved = typeof window !== "undefined" ? window.__SETTINGS__ : globalThis.__SSR_SETTINGS__;
	if (saved !== preloadedFrom) {
		preloadedFrom = saved;
		preloadedValue = saved && typeof saved === "object" ? {
			...DEFAULT_SETTINGS,
			...saved
		} : DEFAULT_SETTINGS;
	}
	return preloadedValue;
}
var current = preloaded();
var fetched = false;
var listeners = /* @__PURE__ */ new Set();
function setSiteSettings(next) {
	current = {
		...DEFAULT_SETTINGS,
		...next
	};
	listeners.forEach((fn) => fn());
}
var subscribe = (fn) => {
	listeners.add(fn);
	return () => listeners.delete(fn);
};
var getSnapshot = () => current;
var getServerSnapshot = () => preloaded();
function useSiteSettings() {
	const settings = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
	useEffect(() => {
		if (fetched) return;
		fetched = true;
		api("/settings").then((data) => data?.contact && setSiteSettings(data)).catch(() => {
			fetched = false;
		});
	}, []);
	return {
		...settings,
		whatsappUrl: whatsappLink(settings)
	};
}
var getSiteSettings = () => current;
//#endregion
//#region src/components/Navigation.jsx
function Navigation() {
	const [isOpen, setIsOpen] = useState(false);
	const { contact, hours, whatsappUrl } = useSiteSettings();
	const { user, logout } = useAuth();
	const { count, open: openCart } = useCart();
	const cartButton = (extra = "") => /* @__PURE__ */ jsxs("button", {
		type: "button",
		onClick: openCart,
		"aria-label": count > 0 ? `Open cart, ${count} item${count === 1 ? "" : "s"}` : "Open cart",
		className: `relative rounded-lg p-2 hover:bg-slate-100 ${extra}`,
		children: [/* @__PURE__ */ jsx(ShoppingCart, {
			size: 22,
			"aria-hidden": "true"
		}), count > 0 && /* @__PURE__ */ jsx("span", {
			className: "absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-brand-yellow px-1 text-xs font-bold text-brand-charcoal",
			children: count > 99 ? "99+" : count
		})]
	});
	const currentPath = logicalPath(useLocation().pathname);
	const showAccount = currentPath.startsWith("/shop");
	const navLinks = [
		{
			name: "Home",
			path: "/"
		},
		{
			name: "About",
			path: "/about"
		},
		{
			name: "Catalogue",
			path: "/products"
		},
		{
			name: "Partners",
			path: "/brands"
		},
		{
			name: "Insights",
			path: "/news"
		},
		{
			name: "Contact",
			path: "/contact"
		},
		{
			name: "Shop Online",
			path: "/shop",
			highlight: true
		}
	];
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("div", {
		className: "hidden bg-brand-charcoal text-xs text-blue-100 md:block",
		children: /* @__PURE__ */ jsxs("div", {
			className: "mx-auto flex h-9 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8",
			children: [/* @__PURE__ */ jsx("p", {
				className: "italic text-brand-yellow",
				children: TAGLINE
			}), /* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-5",
				children: [
					contact.whatsapp && /* @__PURE__ */ jsxs("a", {
						href: whatsappUrl,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "flex items-center gap-1.5 hover:text-white",
						children: [/* @__PURE__ */ jsx(Phone, {
							size: 13,
							"aria-hidden": "true"
						}), displayPhone(contact.whatsapp)]
					}),
					contact.email && /* @__PURE__ */ jsxs("a", {
						href: `mailto:${contact.email}`,
						className: "flex items-center gap-1.5 hover:text-white",
						children: [/* @__PURE__ */ jsx(Mail, {
							size: 13,
							"aria-hidden": "true"
						}), contact.email]
					}),
					hours[0] && /* @__PURE__ */ jsxs("span", {
						className: "flex items-center gap-1.5",
						children: [
							/* @__PURE__ */ jsx(Clock, {
								size: 13,
								"aria-hidden": "true"
							}),
							hours[0].days,
							": ",
							hours[0].time
						]
					})
				]
			})]
		})
	}), /* @__PURE__ */ jsxs("nav", {
		className: "brand-underline bg-white/95 text-brand-charcoal backdrop-blur sticky top-0 z-50 shadow-sm",
		children: [/* @__PURE__ */ jsx("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: /* @__PURE__ */ jsxs("div", {
				className: "flex items-center justify-between h-20",
				children: [
					/* @__PURE__ */ jsx(SiteLink, {
						to: "/",
						className: "flex shrink-0 items-center",
						"aria-label": "JOJO Tech Solutions Ltd home",
						children: /* @__PURE__ */ jsx("img", {
							src: "/logo.png",
							alt: "JOJO Tech Solutions Ltd",
							className: "h-14 w-52 object-contain"
						})
					}),
					/* @__PURE__ */ jsx("div", {
						className: "hidden xl:flex flex-1 items-center justify-center gap-1 whitespace-nowrap",
						children: navLinks.filter((link) => !link.highlight).map((link) => /* @__PURE__ */ jsx(SiteLink, {
							to: link.path,
							"aria-current": currentPath === link.path ? "page" : void 0,
							className: `rounded-full px-3 py-2 text-sm font-medium transition-colors hover:bg-slate-100 2xl:px-4 ${currentPath === link.path ? "bg-brand-charcoal/5 text-brand-ember" : ""}`,
							children: link.name
						}, link.name))
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "hidden xl:flex items-center gap-3 whitespace-nowrap",
						children: [
							navLinks.filter((link) => link.highlight).map((link) => /* @__PURE__ */ jsx(SiteLink, {
								to: link.path,
								className: "rounded-full bg-brand-yellow px-5 py-2 text-sm font-bold text-brand-charcoal transition-colors hover:bg-brand-orange",
								children: link.name
							}, link.name)),
							cartButton(),
							showAccount && (user ? /* @__PURE__ */ jsxs("div", {
								className: "flex items-center space-x-3 text-sm",
								children: [
									/* @__PURE__ */ jsxs("span", {
										className: "flex items-center gap-1 text-gray-600",
										title: user.name || user.username,
										children: [/* @__PURE__ */ jsx(User, {
											size: 16,
											"aria-hidden": "true"
										}), /* @__PURE__ */ jsx("span", {
											className: "hidden 2xl:inline",
											children: user.name.split(" ")[0] || user.username
										})]
									}),
									user.role === "admin" && /* @__PURE__ */ jsx(SiteLink, {
										to: "/admin",
										className: "font-medium hover:text-brand-ember",
										children: "Admin"
									}),
									/* @__PURE__ */ jsx("button", {
										type: "button",
										onClick: logout,
										className: "font-medium hover:text-brand-ember",
										children: "Log out"
									})
								]
							}) : /* @__PURE__ */ jsxs("div", {
								className: "flex items-center space-x-3 text-sm font-medium",
								children: [/* @__PURE__ */ jsx(SiteLink, {
									to: "/login",
									className: "hover:text-brand-ember",
									children: "Log in"
								}), /* @__PURE__ */ jsx(SiteLink, {
									to: "/signup",
									className: "rounded-lg border border-brand-ember px-3 py-1.5 text-brand-ember hover:bg-brand-yellow hover:text-brand-charcoal",
									children: "Sign up"
								})]
							})),
							/* @__PURE__ */ jsxs("a", {
								href: whatsappUrl,
								target: "_blank",
								rel: "noopener noreferrer",
								"aria-label": "WhatsApp",
								className: "flex items-center gap-2 rounded-full border-2 border-green-600 px-4 py-1.5 text-green-700 transition-colors hover:bg-green-600 hover:text-white",
								children: [/* @__PURE__ */ jsx(Phone, { size: 16 }), /* @__PURE__ */ jsx("span", {
									className: `text-sm font-semibold ${showAccount ? "hidden 2xl:inline" : ""}`,
									children: "WhatsApp"
								})]
							})
						]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-1 xl:hidden",
						children: [cartButton(), /* @__PURE__ */ jsx("button", {
							className: "p-2",
							onClick: () => setIsOpen(!isOpen),
							"aria-label": "Toggle menu",
							children: isOpen ? /* @__PURE__ */ jsx(X, { size: 24 }) : /* @__PURE__ */ jsx(Menu, { size: 24 })
						})]
					})
				]
			})
		}), isOpen && /* @__PURE__ */ jsx("div", {
			className: "xl:hidden bg-white border-t border-slate-200",
			children: /* @__PURE__ */ jsxs("div", {
				className: "px-4 py-4 space-y-3",
				children: [
					navLinks.map((link) => /* @__PURE__ */ jsx(SiteLink, {
						to: link.path,
						className: `block py-2 text-sm font-medium transition-colors hover:text-brand-ember ${link.highlight ? "bg-brand-yellow text-brand-charcoal px-4 py-2 rounded-lg font-bold text-center" : ""}`,
						onClick: () => setIsOpen(false),
						children: link.name
					}, link.name)),
					showAccount && (user ? /* @__PURE__ */ jsxs(Fragment, { children: [
						/* @__PURE__ */ jsxs("p", {
							className: "py-2 text-sm text-gray-600",
							children: ["Signed in as ", user.name || user.username]
						}),
						user.role === "admin" && /* @__PURE__ */ jsx(SiteLink, {
							to: "/admin",
							className: "block py-2 text-sm font-medium",
							onClick: () => setIsOpen(false),
							children: "Admin"
						}),
						/* @__PURE__ */ jsx("button", {
							type: "button",
							onClick: () => {
								setIsOpen(false);
								logout();
							},
							className: "block py-2 text-sm font-medium",
							children: "Log out"
						})
					] }) : /* @__PURE__ */ jsxs("div", {
						className: "flex gap-3 py-2",
						children: [/* @__PURE__ */ jsx(SiteLink, {
							to: "/login",
							className: "flex-1 rounded-lg border border-slate-300 py-2 text-center text-sm font-medium",
							onClick: () => setIsOpen(false),
							children: "Log in"
						}), /* @__PURE__ */ jsx(SiteLink, {
							to: "/signup",
							className: "flex-1 rounded-lg bg-brand-yellow py-2 text-center text-sm font-bold text-brand-charcoal",
							onClick: () => setIsOpen(false),
							children: "Sign up"
						})]
					})),
					/* @__PURE__ */ jsxs("a", {
						href: whatsappUrl,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "flex items-center justify-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors",
						children: [/* @__PURE__ */ jsx(Phone, { size: 18 }), /* @__PURE__ */ jsx("span", {
							className: "text-sm font-medium",
							children: "WhatsApp"
						})]
					})
				]
			})
		})]
	})] });
}
//#endregion
//#region src/components/SocialIcon.jsx
var PATHS = {
	facebook: "M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z",
	x: "M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z",
	linkedin: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z",
	tiktok: "M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"
};
var outline = (children, size) => /* @__PURE__ */ jsx("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 24 24",
	width: size,
	height: size,
	fill: "none",
	stroke: "currentColor",
	strokeWidth: "2",
	strokeLinecap: "round",
	strokeLinejoin: "round",
	"aria-hidden": "true",
	focusable: "false",
	children
});
function SocialIcon({ name, size = 20 }) {
	if (PATHS[name]) return /* @__PURE__ */ jsx("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		viewBox: "0 0 24 24",
		width: size,
		height: size,
		fill: "currentColor",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ jsx("path", { d: PATHS[name] })
	});
	if (name === "instagram") return outline(/* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx("rect", {
			x: "3",
			y: "3",
			width: "18",
			height: "18",
			rx: "5"
		}),
		/* @__PURE__ */ jsx("circle", {
			cx: "12",
			cy: "12",
			r: "4"
		}),
		/* @__PURE__ */ jsx("circle", {
			cx: "17.5",
			cy: "6.5",
			r: "0.6",
			fill: "currentColor"
		})
	] }), size);
	if (name === "youtube") return outline(/* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("rect", {
		x: "2",
		y: "5",
		width: "20",
		height: "14",
		rx: "4"
	}), /* @__PURE__ */ jsx("path", {
		d: "m10 9 5 3-5 3z",
		fill: "currentColor"
	})] }), size);
	if (name === "whatsapp") return /* @__PURE__ */ jsx(MessageCircle, {
		size,
		"aria-hidden": "true"
	});
	return /* @__PURE__ */ jsx(Globe, {
		size,
		"aria-hidden": "true"
	});
}
//#endregion
//#region src/components/Footer.jsx
var CURRENT_YEAR = (/* @__PURE__ */ new Date()).getFullYear();
function Footer() {
	const { contact, hours, social } = useSiteSettings();
	return /* @__PURE__ */ jsx("footer", {
		className: "site-footer text-brand-charcoal",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8",
				children: [
					/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("img", {
						src: "/logo.png",
						alt: "JOJO Tech Solutions Ltd",
						className: "h-14 w-56 object-contain object-left mb-4"
					}), /* @__PURE__ */ jsx("p", {
						className: "text-brand-ember text-sm italic mb-4",
						children: TAGLINE
					})] }),
					/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h4", {
						className: "footer-heading text-lg font-semibold mb-4 text-brand-charcoal",
						children: "Explore"
					}), /* @__PURE__ */ jsx("ul", {
						className: "space-y-2 text-sm text-gray-600",
						children: [
							["/", "Home"],
							["/shop", "Shop Online"],
							["/products", "Catalogue"],
							["/brands", "Partners"],
							["/about", "About Us"],
							["/news", "Insights"],
							["/contact", "Contact"]
						].map(([to, label]) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(SiteLink, {
							to,
							className: "hover:text-brand-ember transition-colors",
							children: label
						}) }, to))
					})] }),
					/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h4", {
						className: "footer-heading text-lg font-semibold mb-4 text-brand-charcoal",
						children: "Get in touch"
					}), /* @__PURE__ */ jsxs("ul", {
						className: "space-y-3 text-sm text-gray-600",
						children: [
							contact.address && /* @__PURE__ */ jsxs("li", {
								className: "flex items-start space-x-2",
								children: [/* @__PURE__ */ jsx(MapPin, {
									size: 18,
									className: "text-brand-ember/80 mt-1 flex-shrink-0"
								}), /* @__PURE__ */ jsx("span", {
									className: "whitespace-pre-line",
									children: contact.address
								})]
							}),
							[contact.mobilePhone, contact.officePhone].filter(Boolean).map((phone) => /* @__PURE__ */ jsxs("li", {
								className: "flex items-center space-x-2",
								children: [/* @__PURE__ */ jsx(Phone, {
									size: 18,
									className: "text-brand-ember/80 flex-shrink-0"
								}), /* @__PURE__ */ jsx("a", {
									href: telHref(phone),
									className: "hover:text-brand-ember transition-colors",
									children: phone
								})]
							}, phone)),
							[contact.email, contact.email2].filter(Boolean).map((email) => /* @__PURE__ */ jsxs("li", {
								className: "flex items-center space-x-2",
								children: [/* @__PURE__ */ jsx(Mail, {
									size: 18,
									className: "text-brand-ember/80 flex-shrink-0"
								}), /* @__PURE__ */ jsx("a", {
									href: `mailto:${email}`,
									className: "break-all hover:text-brand-ember transition-colors",
									children: email
								})]
							}, email))
						]
					})] }),
					/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h4", {
						className: "footer-heading text-lg font-semibold mb-4 text-brand-charcoal",
						children: "Opening Hours"
					}), /* @__PURE__ */ jsx("ul", {
						className: "space-y-2 text-sm text-gray-600",
						children: hours.map(({ days, time }) => /* @__PURE__ */ jsxs("li", {
							className: "flex items-center space-x-2",
							children: [/* @__PURE__ */ jsx(Clock, {
								size: 18,
								className: "text-brand-ember/80 flex-shrink-0"
							}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", { children: days }), /* @__PURE__ */ jsx("p", {
								className: "font-medium text-brand-charcoal",
								children: time
							})] })]
						}, days))
					})] })
				]
			}), /* @__PURE__ */ jsxs("div", {
				className: "border-t border-brand-charcoal/10 mt-8 pt-8 flex flex-col items-center gap-4 text-sm text-gray-600 sm:flex-row sm:justify-between sm:pr-20",
				children: [/* @__PURE__ */ jsxs("p", {
					className: "text-center sm:text-left",
					children: [
						"© ",
						CURRENT_YEAR,
						" JOJO Tech Solutions Ltd. All rights reserved."
					]
				}), /* @__PURE__ */ jsx("ul", {
					className: "flex items-center gap-2",
					"aria-label": "Social media",
					children: social.filter(({ url }) => url).map(({ id, label, url }, index) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
						href: url,
						target: "_blank",
						rel: "noopener noreferrer",
						"aria-label": `JOJO Tech Solutions Ltd on ${label}`,
						title: label,
						className: "flex h-8 w-8 items-center justify-center rounded-full bg-brand-charcoal/5 text-brand-charcoal ring-1 ring-brand-charcoal/10 transition-colors hover:bg-brand-yellow hover:text-brand-charcoal",
						children: /* @__PURE__ */ jsx(SocialIcon, {
							name: id,
							size: 15
						})
					}) }, `${id}-${index}`))
				})]
			})]
		})
	});
}
//#endregion
//#region src/contact.js
function whatsappMessageUrl(message) {
	return `${whatsappLink(getSiteSettings())}?text=${encodeURIComponent(message)}`;
}
//#endregion
//#region src/components/WhatsAppWidget.jsx
var TOPICS = [
	{
		icon: Sparkles,
		label: "Help me choose a product",
		message: "Hi JOJO, I need help choosing a product"
	},
	{
		icon: BadgeDollarSign,
		label: "Get a price quote",
		message: "Hi JOJO, I would like a price quote"
	},
	{
		icon: PackageSearch,
		label: "Check availability",
		message: "Hi JOJO, I want to check product availability"
	},
	{
		icon: Cpu,
		label: "Technical support",
		message: "Hi JOJO, I need technical support"
	}
];
function WhatsAppWidget() {
	const [isOpen, setIsOpen] = useState(false);
	const { whatsappUrl } = useSiteSettings();
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("button", {
		type: "button",
		onClick: () => setIsOpen(!isOpen),
		className: "fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full bg-brand-charcoal py-3 pl-4 pr-5 font-semibold text-white shadow-lg ring-4 ring-brand-yellow/30 transition-colors hover:bg-brand-blue",
		"aria-label": isOpen ? "Close chat options" : "Chat with us on WhatsApp",
		"aria-expanded": isOpen,
		children: [isOpen ? /* @__PURE__ */ jsx(X, {
			size: 20,
			"aria-hidden": "true"
		}) : /* @__PURE__ */ jsx(MessageCircle, {
			size: 20,
			"aria-hidden": "true"
		}), /* @__PURE__ */ jsx("span", {
			className: "hidden sm:inline",
			children: isOpen ? "Close" : "Chat with us"
		})]
	}), isOpen && /* @__PURE__ */ jsxs("div", {
		className: "fixed bottom-24 right-6 z-50 w-80 overflow-hidden rounded-2xl bg-white shadow-2xl ring-1 ring-slate-200",
		children: [
			/* @__PURE__ */ jsx("div", {
				className: "bg-gradient-to-br from-brand-charcoal to-brand-blue p-5 text-white",
				children: /* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ jsx("img", {
						src: "/favicon-48.png",
						alt: "",
						width: "40",
						height: "40",
						className: "h-10 w-10 rounded-full bg-white p-1"
					}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
						className: "font-semibold",
						children: "JOJO Tech Support"
					}), /* @__PURE__ */ jsx("p", {
						className: "text-xs text-blue-100",
						children: "Usually replies within minutes"
					})] })]
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "p-4",
				children: [/* @__PURE__ */ jsx("p", {
					className: "mb-3 text-sm text-gray-600",
					children: "What can we help you with?"
				}), /* @__PURE__ */ jsx("div", {
					className: "space-y-2",
					children: TOPICS.map(({ icon: Icon, label, message }) => /* @__PURE__ */ jsxs("a", {
						href: whatsappMessageUrl(message),
						target: "_blank",
						rel: "noopener noreferrer",
						className: "flex w-full items-center gap-3 rounded-xl border border-slate-200 p-3 text-left text-sm text-brand-charcoal transition-colors hover:border-brand-yellow hover:bg-brand-yellow/5",
						children: [/* @__PURE__ */ jsx(Icon, {
							size: 18,
							className: "shrink-0 text-brand-ember",
							"aria-hidden": "true"
						}), label]
					}, label))
				})]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "border-t border-slate-200 p-3",
				children: /* @__PURE__ */ jsx("a", {
					href: whatsappUrl,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "block w-full rounded-full bg-green-600 py-3 text-center font-semibold text-white transition-colors hover:bg-green-700",
					children: "Start a WhatsApp chat"
				})
			})
		]
	})] });
}
//#endregion
//#region src/components/WhatsAppClickTracker.jsx
function WhatsAppClickTracker() {
	useEffect(() => {
		const onClick = (event) => {
			const link = event.target instanceof Element ? event.target.closest("a[href*=\"wa.me/\"]") : null;
			if (!link) return;
			let message = "";
			try {
				message = new URL(link.href).searchParams.get("text") || "";
			} catch {}
			trackWhatsApp({
				label: (link.textContent || "").replace(/\s+/g, " ").trim().slice(0, 120),
				message
			});
		};
		document.addEventListener("click", onClick);
		return () => document.removeEventListener("click", onClick);
	}, []);
	return null;
}
//#endregion
//#region src/productSlug.js
function slugify(name) {
	return String(name || "").replace(/[^A-Za-z0-9]+/g, "-").replace(/^-+|-+$/g, "").toLowerCase().slice(0, 60).replace(/-+$/g, "");
}
function productPath(product) {
	const slug = slugify(product.name);
	return `/product/${encodeURIComponent(product.id)}${slug ? `/${slug}` : ""}`;
}
function postPath(post) {
	const slug = slugify(post.title);
	return `/news/${post.id}${slug ? `/${slug}` : ""}`;
}
//#endregion
//#region src/pageMeta.js
var SITE_URL = MAIN_URL;
function canonicalUrl(pathname) {
	const path = pathname.length > 1 ? pathname.replace(/\/+$/, "") : pathname;
	if (isShopPath(path)) return `${SHOP_URL}${path === "/shop" ? "/" : path}`;
	return `${MAIN_URL}${path === "/" ? "/" : path}`;
}
var PAGE_META = {
	"/": {
		title: `${SITE_NAME} | ${TAGLINE}`,
		description: "Laptops, desktops and accessories from HP, Lenovo, Dell, Apple, ASUS and more. Visit us on Moi Avenue, Nairobi, or order on WhatsApp."
	},
	"/about": {
		title: `About Us | ${SITE_NAME}`,
		description: "JOJO Tech Solutions supplies genuine laptops, desktops and accessories in Nairobi, with honest advice and after-sales support."
	},
	"/brands": {
		title: `Brands We Stock | ${SITE_NAME}`,
		description: "The brands we stock and supply."
	},
	"/products": {
		title: `Product Catalogue | ${SITE_NAME}`,
		description: "Browse our full product range. Ask for prices and availability on WhatsApp."
	},
	"/shop": {
		title: `Shop Online | Order on WhatsApp | ${SITE_NAME}`,
		description: "Shop online: see hot products and best sellers, unlock member discounts, coupons and delivery offers, then order on WhatsApp."
	},
	"/how-to-order": {
		title: `How to Order Online | ${SITE_NAME}`,
		description: "Order online in 5 steps: add products to your cart, send one WhatsApp order, pay by M-Pesa or bank, then get delivery or pickup."
	},
	"/news": {
		title: `News & Updates | ${SITE_NAME}`,
		description: "New stock, offers, buying tips and announcements from JOJO Tech Solutions Ltd."
	},
	"/contact": {
		title: `Contact Us | ${SITE_NAME}`,
		description: "Visit us, call us, or message us on WhatsApp for quotes and advice."
	},
	"/login": {
		title: `Log In | ${SITE_NAME}`,
		description: "Log in to your JOJO Tech Solutions Ltd account to see member discounts, coupons and delivery offers.",
		noindex: true
	},
	"/signup": {
		title: `Create an Account | ${SITE_NAME}`,
		description: "Create a free JOJO Tech Solutions Ltd account to unlock member discounts, coupons and delivery offers.",
		noindex: true
	}
};
function setMeta(selector, attribute, key, content) {
	let tag = document.head.querySelector(selector);
	if (!tag) {
		tag = document.createElement("meta");
		tag.setAttribute(attribute, key);
		document.head.appendChild(tag);
	}
	tag.setAttribute("content", content);
}
function applyPageMeta({ title, description, noindex = false, path }) {
	document.title = title;
	if (path) {
		const url = canonicalUrl(path);
		let link = document.head.querySelector("link[rel=\"canonical\"]");
		if (!link) {
			link = document.createElement("link");
			link.setAttribute("rel", "canonical");
			document.head.appendChild(link);
		}
		link.setAttribute("href", url);
		setMeta("meta[property=\"og:url\"]", "property", "og:url", url);
	}
	if (description) {
		setMeta("meta[name=\"description\"]", "name", "description", description);
		setMeta("meta[property=\"og:description\"]", "property", "og:description", description);
		setMeta("meta[name=\"twitter:description\"]", "name", "twitter:description", description);
	}
	setMeta("meta[property=\"og:title\"]", "property", "og:title", title);
	setMeta("meta[name=\"twitter:title\"]", "name", "twitter:title", title);
	const robots = document.head.querySelector("meta[name=\"robots\"]");
	if (noindex) setMeta("meta[name=\"robots\"]", "name", "robots", "noindex, nofollow");
	else robots?.remove();
}
var clip$1 = (text, max) => {
	const clean = String(text || "").replace(/\s+/g, " ").trim();
	if (clean.length <= max) return clean;
	return `${clean.slice(0, max - 1).replace(/\s+\S*$/, "")}…`;
};
function productMeta(product) {
	const brand = product.brand && product.brand.toLowerCase() !== "generic" ? ` | ${product.brand}` : "";
	const title = `${clip$1(product.name, 42)}${brand} | ${SITE_NAME}`;
	const specs = product.specs ? `${String(product.specs).replace(/\.+$/, "")}. ` : "";
	const price = product.price ? `KES ${Number(product.price).toLocaleString("en-KE")}. ` : "";
	return {
		title,
		description: clip$1(`${product.name}: ${specs}${price}Order or ask for a quote on WhatsApp from ${SITE_NAME}.`, 158)
	};
}
function postMeta(post) {
	return {
		title: `${clip$1(post.title, 52)} | News | ${SITE_NAME}`,
		description: clip$1(post.summary || post.body || post.title, 158)
	};
}
//#endregion
//#region src/offerMath.js
function offerApplies(offer, product) {
	if (offer.category && offer.category.toLowerCase() !== (product.category || "").toLowerCase()) return false;
	if (offer.minPrice != null && (product.price == null || product.price < offer.minPrice)) return false;
	return true;
}
function priceAfter(offer, price) {
	let off = 0;
	if (offer.percentOff != null) off = price * offer.percentOff / 100;
	if (offer.amountOff != null) off = Math.max(off, offer.amountOff);
	return Math.max(0, Math.round((price - off) * 100) / 100);
}
function offerLabel(offer) {
	if (offer.percentOff != null && offer.amountOff != null) return `${offer.percentOff}% off or KES ${offer.amountOff.toLocaleString()} off`;
	if (offer.percentOff != null) return `${offer.percentOff}% off`;
	if (offer.amountOff != null) return `KES ${offer.amountOff.toLocaleString()} off`;
	return "";
}
function bestPriceOffer(offers, product) {
	const priced = offers.filter((o) => o.type !== "delivery" && offerApplies(o, product));
	if (priced.length === 0) return null;
	if (product.price == null) return {
		offer: priced[0],
		price: null
	};
	return priced.map((offer) => ({
		offer,
		price: priceAfter(offer, product.price)
	})).sort((a, b) => a.price - b.price)[0];
}
//#endregion
//#region src/cart/cartMessage.js
var kes$2 = (n) => `KES ${Number(n).toLocaleString("en-KE")}`;
function priceLine(product, qty, offers, couponId) {
	const candidates = offers.filter((o) => (o.type === "discount" || o.type === "coupon" && o.id === couponId) && offerApplies(o, product));
	const listed = product.price != null ? Number(product.price) : null;
	let offer = candidates[0] || null;
	let unit = listed;
	if (listed != null && candidates.length) {
		const best = candidates.map((o) => ({
			o,
			price: priceAfter(o, listed)
		})).sort((a, b) => a.price - b.price)[0];
		offer = best.o;
		unit = best.price;
	}
	return {
		product,
		qty,
		listed,
		unit,
		offer,
		lineTotal: unit != null ? Math.round(unit * qty * 100) / 100 : null
	};
}
function cartTotals(lines) {
	const priced = lines.filter((l) => l.lineTotal != null);
	return {
		total: Math.round(priced.reduce((sum, l) => sum + l.lineTotal, 0) * 100) / 100,
		pricedCount: priced.length,
		unpricedCount: lines.length - priced.length
	};
}
var makeCartRef = () => Math.random().toString(36).slice(2, 10).toUpperCase().padEnd(8, "X");
function buildCartMessage({ lines, address, user, coupon, delivery, ref }) {
	const items = lines.map((l, i) => {
		const brand = l.product.brand && l.product.brand.toLowerCase() !== "generic" ? ` (${l.product.brand})` : "";
		const price = l.unit != null ? ` - ${kes$2(l.unit)} each${l.qty > 1 ? ` = ${kes$2(l.lineTotal)}` : ""}` : " - price to be confirmed";
		return `${i + 1}. ${l.product.name}${brand} x ${l.qty}${price}\n   ${canonicalUrl(productPath(l.product))}`;
	});
	const { total, pricedCount, unpricedCount } = cartTotals(lines);
	const details = [];
	if (pricedCount > 0) {
		const extra = unpricedCount > 0 ? ` (plus ${unpricedCount} item${unpricedCount === 1 ? "" : "s"} priced on WhatsApp)` : "";
		details.push(`Estimated total: ${kes$2(total)}${extra}`);
	}
	details.push(`Delivery address: ${address.trim() || "to be confirmed on WhatsApp"}`);
	if (user) details.push(`Member: ${user.name || user.username} (${user.username})${user.phone ? `, ${user.phone}` : ""}`);
	const usedOffers = [...new Map(lines.filter((l) => l.offer).map((l) => [l.offer.id, l.offer])).values()];
	const discounts = usedOffers.filter((o) => o.type === "discount");
	if (discounts.length) details.push(`Member discount: ${discounts.map((o) => o.title).join(", ")}`);
	if (coupon && usedOffers.some((o) => o.id === coupon.id)) details.push(`Coupon ${coupon.code}: ${coupon.title}`);
	if (delivery) details.push(`Delivery offer: ${delivery.title}`);
	return [
		"Hi, I'd like to order these items:",
		items.join("\n"),
		details.join("\n"),
		"Please confirm the current prices, availability, and delivery or pickup.",
		`Order ref: ${ref}`
	].join("\n\n");
}
//#endregion
//#region src/useOffers.js
function useOffers() {
	const { user } = useAuth();
	const [offers, setOffers] = useState([]);
	const memberId = user?.role === "customer" || user?.role === "admin" ? user.id : null;
	useEffect(() => {
		let cancelled = false;
		if (!memberId) return void 0;
		api("/offers").then((data) => !cancelled && setOffers(data.offers || [])).catch(() => !cancelled && setOffers([]));
		return () => {
			cancelled = true;
		};
	}, [memberId]);
	return memberId ? offers : [];
}
//#endregion
//#region src/data/newProducts.js
var newProducts = [];
//#endregion
//#region src/useProducts.js
var cache$1 = null;
function preloadedProducts() {
	const list = typeof window !== "undefined" ? window.__PRODUCTS__ : globalThis.__SSR_PRODUCTS__;
	return Array.isArray(list) && list.length > 0 ? list : null;
}
function useProducts() {
	const [products, setProducts] = useState(() => cache$1 || preloadedProducts() || newProducts);
	useEffect(() => {
		let cancelled = false;
		api("/products").then((data) => {
			if (cancelled || !Array.isArray(data?.products) || data.products.length === 0) return;
			cache$1 = data.products;
			setProducts(data.products);
		}).catch(() => {});
		return () => {
			cancelled = true;
		};
	}, []);
	return products;
}
//#endregion
//#region src/components/CartDrawer.jsx
var kes$1 = (n) => `KES ${Number(n).toLocaleString("en-KE")}`;
function CartDrawer() {
	const { items, count, isOpen, notice, setQty, remove, clear, open, close } = useCart();
	const { user } = useAuth();
	const offers = useOffers();
	const products = useProducts();
	const [fetched, setFetched] = useState({});
	const [couponId, setCouponId] = useState(null);
	const [deliveryId, setDeliveryId] = useState(null);
	const [code, setCode] = useState("");
	const [codeMessage, setCodeMessage] = useState({
		ok: true,
		text: ""
	});
	const [address, setAddress] = useState("");
	const byId = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);
	const missingKey = items.map((i) => i.id).filter((id) => !byId.has(id) && !(id in fetched)).join(",");
	useEffect(() => {
		if (!isOpen || !missingKey) return void 0;
		let cancelled = false;
		for (const id of missingKey.split(",")) api(`/products/${encodeURIComponent(id)}`).then((data) => !cancelled && setFetched((f) => ({
			...f,
			[id]: data.product
		}))).catch(() => !cancelled && setFetched((f) => ({
			...f,
			[id]: null
		})));
		return () => {
			cancelled = true;
		};
	}, [isOpen, missingKey]);
	useEffect(() => {
		if (!isOpen) return void 0;
		const onKey = (e) => e.key === "Escape" && close();
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [isOpen, close]);
	const resolved = items.map((item) => ({
		item,
		product: byId.get(item.id) || fetched[item.id] || null,
		pending: !byId.has(item.id) && !(item.id in fetched)
	}));
	const unavailable = resolved.filter((r) => !r.product && !r.pending);
	const coupon = offers.find((o) => o.type === "coupon" && o.id === couponId) || null;
	const lines = resolved.filter((r) => r.product).map((r) => priceLine(r.product, r.item.qty, offers, couponId));
	const { total, pricedCount, unpricedCount } = cartTotals(lines);
	const coupons = offers.filter((o) => o.type === "coupon" && lines.some((l) => offerApplies(o, l.product)));
	const deliveryOffers = offers.filter((o) => o.type === "delivery" && lines.some((l) => offerApplies(o, l.product)));
	const delivery = deliveryOffers.find((o) => o.id === deliveryId) || null;
	const applyCode = () => {
		const wanted = code.trim().toUpperCase();
		if (!wanted) return;
		const match = offers.find((o) => o.type === "coupon" && o.code === wanted);
		if (!match) setCodeMessage({
			ok: false,
			text: "That code is not recognised."
		});
		else if (!lines.some((l) => offerApplies(match, l.product))) setCodeMessage({
			ok: false,
			text: "That coupon does not apply to anything in your cart."
		});
		else {
			setCouponId(match.id);
			setCodeMessage({
				ok: true,
				text: `Coupon ${match.code} applied.`
			});
		}
	};
	const send = () => {
		if (lines.length === 0) return;
		const ref = makeCartRef();
		const message = buildCartMessage({
			lines,
			address,
			user,
			coupon,
			delivery,
			ref
		});
		for (const line of lines) trackWhatsApp({
			label: "Cart order",
			productId: line.product.id,
			message: ""
		});
		for (const line of lines) recordOrder({
			productId: line.product.id,
			productName: line.product.name,
			message,
			offerIds: [line.offer?.id, delivery?.id].filter(Boolean),
			quantity: line.qty,
			deliveryAddress: address.trim(),
			cartRef: ref
		});
		window.open(whatsappMessageUrl(message), "_blank");
		clear();
		setAddress("");
		setCouponId(null);
		setDeliveryId(null);
		setCode("");
		close();
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [notice && /* @__PURE__ */ jsxs("div", {
		role: "status",
		className: "fixed bottom-24 left-1/2 z-[90] flex w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 items-center gap-3 rounded-xl bg-brand-black px-4 py-3 text-sm text-white shadow-2xl",
		children: [
			/* @__PURE__ */ jsx(Check, {
				size: 18,
				className: "shrink-0 text-brand-yellow",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ jsx("span", {
				className: "min-w-0 flex-1 truncate",
				children: notice.full ? notice.text : `${notice.text}: ${notice.name}`
			}),
			/* @__PURE__ */ jsx("button", {
				type: "button",
				onClick: open,
				className: "shrink-0 font-semibold text-brand-yellow hover:underline",
				children: "View cart"
			})
		]
	}), isOpen && /* @__PURE__ */ jsxs("div", {
		className: "fixed inset-0 z-[100]",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Your cart",
		children: [/* @__PURE__ */ jsx("div", {
			className: "absolute inset-0 bg-black/60",
			onClick: close
		}), /* @__PURE__ */ jsxs("aside", {
			className: "absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-white shadow-2xl",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "flex items-center justify-between border-b border-gray-200 px-5 py-4",
				children: [/* @__PURE__ */ jsxs("h2", {
					className: "flex items-center gap-2 text-lg font-bold text-brand-charcoal",
					children: [
						/* @__PURE__ */ jsx(ShoppingCart, {
							size: 20,
							"aria-hidden": "true"
						}),
						" Your cart ",
						/* @__PURE__ */ jsxs("span", {
							className: "text-sm font-normal text-gray-500",
							children: [
								"(",
								count,
								" item",
								count === 1 ? "" : "s",
								")"
							]
						})
					]
				}), /* @__PURE__ */ jsx("button", {
					type: "button",
					onClick: close,
					"aria-label": "Close cart",
					className: "rounded-full p-2 text-gray-500 hover:bg-gray-100",
					children: /* @__PURE__ */ jsx(X, { size: 18 })
				})]
			}), items.length === 0 ? /* @__PURE__ */ jsxs("div", {
				className: "flex flex-1 flex-col items-center justify-center px-6 text-center",
				children: [
					/* @__PURE__ */ jsx(ShoppingCart, {
						size: 40,
						className: "text-gray-300",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-3 font-semibold text-brand-charcoal",
						children: "Your cart is empty"
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-1 text-sm text-gray-600",
						children: "Add several products, then send them to us in one WhatsApp order."
					}),
					/* @__PURE__ */ jsx(SiteLink, {
						to: "/shop",
						onClick: close,
						className: "mt-5 rounded-full bg-brand-yellow px-5 py-2 font-bold text-brand-charcoal hover:bg-brand-orange",
						children: "Browse the shop"
					})
				]
			}) : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("div", {
				className: "flex-1 space-y-5 overflow-y-auto px-5 py-4",
				children: [
					/* @__PURE__ */ jsx("ul", {
						className: "divide-y divide-gray-100",
						children: resolved.map(({ item, product, pending }) => /* @__PURE__ */ jsxs("li", {
							className: "flex gap-3 py-3",
							children: [product ? /* @__PURE__ */ jsx("img", {
								src: assetUrl(product.image),
								alt: "",
								className: "h-16 w-16 shrink-0 rounded-lg border border-gray-200 object-cover"
							}) : /* @__PURE__ */ jsx("div", { className: "h-16 w-16 shrink-0 rounded-lg bg-gray-100" }), /* @__PURE__ */ jsxs("div", {
								className: "min-w-0 flex-1",
								children: [
									product ? /* @__PURE__ */ jsx(SiteLink, {
										to: productPath(product),
										onClick: close,
										className: "line-clamp-2 text-sm font-semibold text-brand-charcoal hover:underline",
										children: product.name
									}) : /* @__PURE__ */ jsx("p", {
										className: "text-sm font-semibold text-gray-500",
										children: pending ? "Loading…" : "No longer available"
									}),
									product && (() => {
										const line = lines.find((l) => l.product.id === product.id);
										return /* @__PURE__ */ jsx("p", {
											className: "mt-0.5 text-xs text-gray-600",
											children: line.unit == null ? "Price on WhatsApp" : /* @__PURE__ */ jsxs(Fragment, { children: [
												line.unit < line.listed && /* @__PURE__ */ jsx("span", {
													className: "mr-1 text-gray-400 line-through",
													children: kes$1(line.listed)
												}),
												kes$1(line.unit),
												" each"
											] })
										});
									})(),
									/* @__PURE__ */ jsxs("div", {
										className: "mt-2 flex items-center gap-2",
										children: [/* @__PURE__ */ jsxs("div", {
											className: "inline-flex items-center rounded-lg border border-gray-300",
											children: [
												/* @__PURE__ */ jsx("button", {
													type: "button",
													onClick: () => setQty(item.id, item.qty - 1),
													disabled: item.qty <= 1,
													"aria-label": "Decrease quantity",
													className: "p-1.5 hover:bg-gray-100 disabled:opacity-30",
													children: /* @__PURE__ */ jsx(Minus, { size: 14 })
												}),
												/* @__PURE__ */ jsx("input", {
													type: "number",
													min: "1",
													max: "999",
													value: item.qty,
													onChange: (e) => setQty(item.id, e.target.value),
													"aria-label": `Quantity of ${product?.name || "item"}`,
													className: "w-12 border-x border-gray-300 py-1 text-center text-sm focus:outline-none"
												}),
												/* @__PURE__ */ jsx("button", {
													type: "button",
													onClick: () => setQty(item.id, item.qty + 1),
													"aria-label": "Increase quantity",
													className: "p-1.5 hover:bg-gray-100",
													children: /* @__PURE__ */ jsx(Plus, { size: 14 })
												})
											]
										}), /* @__PURE__ */ jsx("button", {
											type: "button",
											onClick: () => remove(item.id),
											"aria-label": `Remove ${product?.name || "item"}`,
											className: "rounded p-1.5 text-red-700 hover:bg-red-50",
											children: /* @__PURE__ */ jsx(Trash2, { size: 16 })
										})]
									})
								]
							})]
						}, item.id))
					}),
					unavailable.length > 0 && /* @__PURE__ */ jsx("p", {
						className: "rounded-lg bg-amber-50 p-3 text-sm text-amber-900",
						children: "Some items are no longer available. Remove them to continue."
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "block text-sm font-medium text-gray-700",
						children: [
							"Delivery address ",
							/* @__PURE__ */ jsx("span", {
								className: "font-normal text-gray-500",
								children: "(optional)"
							}),
							/* @__PURE__ */ jsx("textarea", {
								rows: 2,
								maxLength: 300,
								value: address,
								onChange: (e) => setAddress(e.target.value),
								placeholder: "Area, street or building. Leave blank to confirm on WhatsApp.",
								className: "mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-transparent focus:ring-2 focus:ring-brand-yellow"
							})
						]
					}),
					!user && /* @__PURE__ */ jsxs("div", {
						className: "rounded-xl border border-brand-yellow bg-yellow-50 p-4 text-sm",
						children: [/* @__PURE__ */ jsx("p", {
							className: "font-semibold text-brand-charcoal",
							children: "Members get discounts, coupons and delivery offers"
						}), /* @__PURE__ */ jsxs("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ jsx(SiteLink, {
								to: "/signup",
								state: { from: "/shop" },
								onClick: close,
								className: "rounded-full bg-brand-yellow px-4 py-2 font-bold text-brand-charcoal hover:bg-brand-orange",
								children: "Create account"
							}), /* @__PURE__ */ jsx(SiteLink, {
								to: "/login",
								state: { from: "/shop" },
								onClick: close,
								className: "rounded-lg border border-gray-300 bg-white px-4 py-2 font-medium hover:bg-gray-100",
								children: "Log in"
							})]
						})]
					}),
					user && /* @__PURE__ */ jsxs("div", {
						className: "space-y-4 text-sm",
						children: [
							lines.some((l) => l.offer?.type === "discount") && /* @__PURE__ */ jsxs("p", {
								className: "flex items-start gap-2 rounded-lg bg-green-50 p-3 text-green-900",
								children: [/* @__PURE__ */ jsx(BadgePercent, {
									size: 16,
									className: "mt-0.5 shrink-0",
									"aria-hidden": "true"
								}), " Member discounts are applied to the items they cover."]
							}),
							coupons.length > 0 && /* @__PURE__ */ jsxs("fieldset", { children: [/* @__PURE__ */ jsxs("legend", {
								className: "mb-2 flex items-center gap-2 font-semibold text-brand-charcoal",
								children: [
									/* @__PURE__ */ jsx(Ticket, {
										size: 16,
										"aria-hidden": "true"
									}),
									" Coupon ",
									/* @__PURE__ */ jsx("span", {
										className: "font-normal text-gray-500",
										children: "(the better price wins per item)"
									})
								]
							}), /* @__PURE__ */ jsx("div", {
								className: "flex flex-wrap gap-2",
								children: coupons.map((o) => /* @__PURE__ */ jsxs("button", {
									type: "button",
									"aria-pressed": couponId === o.id,
									onClick: () => setCouponId(couponId === o.id ? null : o.id),
									className: `rounded-lg border px-3 py-1.5 text-left ${couponId === o.id ? "border-brand-charcoal bg-brand-charcoal text-white" : "border-gray-300 hover:border-brand-yellow"}`,
									children: [
										/* @__PURE__ */ jsx("span", {
											className: "font-mono text-xs",
											children: o.code
										}),
										" ",
										/* @__PURE__ */ jsxs("span", {
											className: "block",
											children: [o.title, offerLabel(o) && !o.title.toLowerCase().includes(offerLabel(o).toLowerCase()) ? ` (${offerLabel(o)})` : ""]
										})
									]
								}, o.id))
							})] }),
							/* @__PURE__ */ jsxs("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ jsx("input", {
									value: code,
									onChange: (e) => setCode(e.target.value),
									onKeyDown: (e) => e.key === "Enter" && (e.preventDefault(), applyCode()),
									placeholder: "Have a coupon code?",
									"aria-label": "Coupon code",
									className: "min-w-0 flex-1 rounded-lg border border-gray-300 px-3 py-2 uppercase placeholder:normal-case focus:border-transparent focus:ring-2 focus:ring-brand-yellow"
								}), /* @__PURE__ */ jsx("button", {
									type: "button",
									onClick: applyCode,
									className: "rounded-lg border border-gray-300 px-4 py-2 font-medium hover:bg-gray-100",
									children: "Apply"
								})]
							}),
							codeMessage.text && /* @__PURE__ */ jsx("p", {
								role: "status",
								className: `text-xs ${codeMessage.ok ? "text-green-700" : "text-red-700"}`,
								children: codeMessage.text
							}),
							deliveryOffers.length > 0 && /* @__PURE__ */ jsxs("fieldset", { children: [/* @__PURE__ */ jsxs("legend", {
								className: "mb-2 flex items-center gap-2 font-semibold text-brand-charcoal",
								children: [/* @__PURE__ */ jsx(Truck, {
									size: 16,
									"aria-hidden": "true"
								}), " Delivery offer"]
							}), /* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [deliveryOffers.map((o) => /* @__PURE__ */ jsxs("label", {
									className: "flex cursor-pointer items-start gap-3 rounded-lg border border-gray-200 p-3 hover:border-brand-yellow",
									children: [/* @__PURE__ */ jsx("input", {
										type: "radio",
										name: "cart-delivery",
										className: "mt-0.5 accent-[#013d83]",
										checked: deliveryId === o.id,
										onChange: () => setDeliveryId(o.id)
									}), /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
										className: "font-medium",
										children: o.title
									}), o.description && /* @__PURE__ */ jsx("span", {
										className: "block text-gray-600",
										children: o.description
									})] })]
								}, o.id)), /* @__PURE__ */ jsxs("label", {
									className: "flex cursor-pointer items-center gap-3 rounded-lg border border-gray-200 p-3 hover:border-brand-yellow",
									children: [/* @__PURE__ */ jsx("input", {
										type: "radio",
										name: "cart-delivery",
										className: "accent-[#013d83]",
										checked: deliveryId === null,
										onChange: () => setDeliveryId(null)
									}), " No delivery offer"]
								})]
							})] })
						]
					})
				]
			}), /* @__PURE__ */ jsxs("div", {
				className: "border-t border-gray-200 px-5 py-4",
				children: [
					pricedCount > 0 && /* @__PURE__ */ jsxs("p", {
						className: "mb-3 flex items-baseline justify-between text-sm",
						children: [/* @__PURE__ */ jsxs("span", {
							className: "text-gray-600",
							children: ["Estimated total", unpricedCount > 0 ? ` (+ ${unpricedCount} priced on WhatsApp)` : ""]
						}), /* @__PURE__ */ jsx("span", {
							className: "text-lg font-bold text-brand-charcoal",
							children: kes$1(total)
						})]
					}),
					/* @__PURE__ */ jsxs("button", {
						type: "button",
						onClick: send,
						disabled: lines.length === 0 || unavailable.length > 0,
						className: "flex w-full items-center justify-center gap-2 rounded-full bg-green-600 px-5 py-3 font-semibold text-white hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-50",
						children: [/* @__PURE__ */ jsx(MessageCircle, { size: 18 }), " Send order on WhatsApp"]
					}),
					/* @__PURE__ */ jsxs("p", {
						className: "mt-2 text-center text-xs text-gray-500",
						children: ["Prices and availability are confirmed with you on WhatsApp. ", /* @__PURE__ */ jsx(SiteLink, {
							to: "/how-to-order",
							onClick: close,
							className: "underline hover:text-brand-charcoal",
							children: "How ordering works"
						})]
					})
				]
			})] })]
		})]
	})] });
}
//#endregion
//#region src/components/PageMeta.jsx
function PageMeta() {
	const { pathname } = useLocation();
	useEffect(() => {
		if (pathname.startsWith("/product/") || pathname.startsWith("/category/") || pathname.startsWith("/news/")) return;
		const path = logicalPath(pathname);
		const key = path.length > 1 ? path.replace(/\/+$/, "") : path;
		applyPageMeta({
			...PAGE_META[key] || PAGE_META["/"],
			path: key
		});
	}, [pathname]);
	return null;
}
//#endregion
//#region src/components/EmptyState.jsx
function EmptyState({ icon: Icon = PackageOpen, title, text, children, compact = false }) {
	return /* @__PURE__ */ jsxs("div", {
		className: `flex flex-col items-center rounded-2xl border border-dashed border-slate-300 bg-white text-center ${compact ? "px-6 py-8" : "px-6 py-14"}`,
		children: [
			/* @__PURE__ */ jsx("span", {
				className: "flex h-12 w-12 items-center justify-center rounded-full bg-brand-blue/10 text-brand-blue",
				children: /* @__PURE__ */ jsx(Icon, {
					size: 24,
					"aria-hidden": "true"
				})
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-4 font-semibold text-brand-charcoal",
				children: title
			}),
			text && /* @__PURE__ */ jsx("p", {
				className: "mt-1 max-w-md text-sm text-gray-500",
				children: text
			}),
			children && /* @__PURE__ */ jsx("div", {
				className: "mt-5",
				children
			})
		]
	});
}
//#endregion
//#region src/data/partnerLogos.js
var PARTNER_LOGOS = [
	{
		name: "HP",
		logo: "/logos/hp.png"
	},
	{
		name: "Lenovo",
		logo: "/logos/lenovo.png"
	},
	{
		name: "Dell",
		logo: "/logos/dell.png"
	},
	{
		name: "Apple",
		logo: "/logos/apple.png"
	},
	{
		name: "ASUS",
		logo: "/logos/asus.png"
	},
	{
		name: "Acer",
		logo: "/logos/acer.png"
	},
	{
		name: "Microsoft",
		logo: "/logos/microsoft.png"
	},
	{
		name: "Toshiba",
		logo: "/logos/toshiba.png"
	},
	{
		name: "Compaq",
		logo: "/logos/compaq.png"
	},
	{
		name: "Vention",
		logo: "/logos/vention.png"
	}
];
//#endregion
//#region src/components/LogoMarquee.jsx
function Logo({ name, logo, duplicate }) {
	return /* @__PURE__ */ jsx("li", {
		"aria-hidden": duplicate || void 0,
		className: "flex h-20 w-44 shrink-0 items-center justify-center rounded-2xl border border-slate-200 bg-white px-6 sm:w-52",
		children: logo ? /* @__PURE__ */ jsx("img", {
			src: logo,
			alt: duplicate ? "" : name,
			loading: "lazy",
			className: "h-10 w-auto max-w-full object-contain transition-transform duration-300 hover:scale-105"
		}) : /* @__PURE__ */ jsx("span", {
			className: "font-heading text-2xl font-bold tracking-wide text-slate-400",
			children: name
		})
	});
}
var MIN_TILES = 9;
function Row({ items, reverse }) {
	const copy = [];
	while (copy.length < Math.max(MIN_TILES, items.length)) copy.push(...items);
	return /* @__PURE__ */ jsx("div", {
		className: "marquee",
		children: /* @__PURE__ */ jsxs("ul", {
			className: `marquee-track ${reverse ? "marquee-reverse" : ""}`,
			children: [copy.map((item, i) => /* @__PURE__ */ jsx(Logo, {
				...item,
				duplicate: i >= items.length
			}, `a${i}`)), copy.map((item, i) => /* @__PURE__ */ jsx(Logo, {
				...item,
				duplicate: true
			}, `b${i}`))]
		})
	});
}
function LogoMarquee({ logos = PARTNER_LOGOS }) {
	if (!logos.length) return null;
	const rows = [logos.filter((_, i) => i % 2 === 0), logos.filter((_, i) => i % 2 === 1)].filter((row) => row.length);
	return /* @__PURE__ */ jsx("div", {
		className: "space-y-4",
		children: rows.map((row, index) => /* @__PURE__ */ jsx(Row, {
			items: row,
			reverse: index === 1
		}, index))
	});
}
//#endregion
//#region src/brands.js
var BRAND_INFO = {
	hp: {
		logo: "/logos/hp.png",
		photo: "/brands/hp-pavilion.jpg",
		blurb: "Pavilion, ProBook and EliteBook laptops, desktops and printers."
	},
	lenovo: {
		logo: "/logos/lenovo.png",
		photo: "/brands/lenovo-ideapad.jpg",
		card: "/brands/lenovo-card.jpg",
		blurb: "IdeaPad and ThinkPad laptops for study, work and business."
	},
	dell: {
		logo: "/logos/dell.png",
		blurb: "Inspiron, Latitude and Vostro laptops and desktops built for work."
	},
	apple: {
		logo: "/logos/apple.png",
		photo: "/brands/apple-macbook.jpg",
		blurb: "MacBook Air and MacBook Pro, plus Apple accessories."
	},
	asus: {
		logo: "/logos/asus.png",
		photo: "/brands/asus-vivobook.jpg",
		card: "/brands/asus-card.jpg",
		blurb: "VivoBook everyday laptops and ROG gaming machines."
	},
	acer: {
		logo: "/logos/acer.png",
		blurb: "Aspire and Swift laptops that give great value for money."
	},
	microsoft: {
		logo: "/logos/microsoft.png",
		photo: "/brands/microsoft-surface.jpg",
		card: "/brands/microsoft-card.jpg",
		blurb: "Surface laptops and tablets, Windows and Office."
	},
	toshiba: {
		logo: "/logos/toshiba.png",
		card: "/brands/toshiba-card.jpg",
		blurb: "Dependable laptops, hard drives and storage."
	},
	compaq: {
		logo: "/logos/compaq.png",
		blurb: "Affordable laptops and desktops for home and office."
	},
	vention: {
		logo: "/logos/vention.png",
		photo: "/brands/vention-dock.jpg",
		blurb: "Docking stations, USB-C hubs, HDMI switches and cables."
	}
};
var ORDER_ONLY = [
	"HP",
	"Lenovo",
	"Dell",
	"Apple",
	"ASUS",
	"Acer",
	"Microsoft",
	"Toshiba",
	"Compaq",
	"Vention"
];
var brandKey = (name) => String(name || "").toLowerCase().replace(/[\s-]+/g, "");
var isNamed = (name) => Boolean(name) && brandKey(name) !== "generic";
var brandProductsPath = (name) => `/products?brand=${encodeURIComponent(name)}`;
function groupBrands(products) {
	const groups = /* @__PURE__ */ new Map();
	for (const product of products) {
		if (product.active === false || !isNamed(product.brand)) continue;
		const key = brandKey(product.brand);
		if (!groups.has(key)) groups.set(key, {
			name: product.brand,
			key,
			products: [],
			labels: /* @__PURE__ */ new Map()
		});
		const group = groups.get(key);
		group.products.push(product);
		const label = product.categoryName || product.category;
		if (label) group.labels.set(label, (group.labels.get(label) || 0) + 1);
	}
	return [...groups.values()].map(({ name, key, products, labels }) => {
		const categories = [...labels.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).map(([label]) => label);
		return {
			name,
			key,
			logo: BRAND_INFO[key]?.logo || null,
			blurb: BRAND_INFO[key]?.blurb || `${categories.join(", ")} from ${name}.`,
			count: products.length,
			categories,
			products
		};
	}).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}
function orderOnlyBrands(brandGroups) {
	const stocked = new Set(brandGroups.map((b) => b.key));
	return ORDER_ONLY.filter((name) => !stocked.has(brandKey(name))).map((name) => ({
		name,
		key: brandKey(name),
		...BRAND_INFO[brandKey(name)]
	}));
}
var brandInfo = (name) => ({
	name,
	key: brandKey(name),
	...BRAND_INFO[brandKey(name)]
});
//#endregion
//#region src/data/categoryContent.js
var CATEGORY_CONTENT = {};
//#endregion
//#region src/categories.js
var categorySlug = (name) => slugify(name);
var categoryPath = (name) => `/category/${categorySlug(name)}`;
function groupCategories(products) {
	const groups = /* @__PURE__ */ new Map();
	for (const product of products) {
		if (product.active === false || !product.category) continue;
		const slug = categorySlug(product.category);
		if (!slug) continue;
		if (!groups.has(slug)) groups.set(slug, {
			slug,
			name: product.category,
			labels: /* @__PURE__ */ new Map(),
			brandCounts: /* @__PURE__ */ new Map(),
			products: []
		});
		const group = groups.get(slug);
		group.products.push(product);
		if (product.categoryName) group.labels.set(product.categoryName, (group.labels.get(product.categoryName) || 0) + 1);
		if (product.brand && product.brand.toLowerCase() !== "generic") group.brandCounts.set(product.brand, (group.brandCounts.get(product.brand) || 0) + 1);
	}
	const top = (map) => [...map.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
	return [...groups.values()].map(({ slug, name, labels, brandCounts, products }) => ({
		slug,
		name,
		label: top(labels)[0]?.[0] || name,
		brands: top(brandCounts).map(([brand, count]) => ({
			brand,
			count
		})),
		products
	})).sort((a, b) => b.products.length - a.products.length || a.name.localeCompare(b.name));
}
var clip = (text, max) => text.length <= max ? text : `${text.slice(0, max - 1).replace(/\s+\S*$/, "")}…`;
function categoryCopy(group) {
	const written = CATEGORY_CONTENT[group.slug];
	if (written) return written;
	const count = group.products.length;
	const brands = group.brands.slice(0, 4).map((b) => b.brand);
	const brandText = brands.length ? ` including ${brands.join(", ")}` : "";
	return {
		heading: group.name,
		description: clip(`Browse ${count} ${group.name.toLowerCase()} product${count === 1 ? "" : "s"}${brandText} from JOJO Tech Solutions Ltd. Order on WhatsApp.`, 158),
		intro: [`JOJO Tech Solutions Ltd supplies ${group.name.toLowerCase()} to customers across Kenya. Browse the ${count} product${count === 1 ? "" : "s"} below${brandText}.`, "Order on WhatsApp for the current price and availability, or visit our shop."]
	};
}
function categoryMeta(group, siteName = "JOJO Tech Solutions Ltd") {
	const { heading, description } = categoryCopy(group);
	return {
		title: `${heading} | ${siteName}`,
		description
	};
}
//#endregion
//#region src/pages/Home.jsx
var REASONS = [
	{
		icon: ShieldCheck,
		title: "Genuine products",
		text: "Original, warrantied products from trusted manufacturers."
	},
	{
		icon: Headphones,
		title: "Real technical advice",
		text: "Tell us what you need it for and we recommend what fits your setup and budget."
	},
	{
		icon: Truck,
		title: "Fast delivery",
		text: "Quick dispatch, delivery or pickup, confirmed with you on WhatsApp."
	},
	{
		icon: Cpu,
		title: "After-sales support",
		text: "Setup help and support long after you have made your purchase."
	}
];
var BRAND_TILES = [
	{
		brand: "ASUS",
		title: "ROG gaming laptops",
		image: "/brands/asus-rog.jpg",
		span: "sm:col-span-2 lg:row-span-2"
	},
	{
		brand: "Microsoft",
		title: "Surface laptops",
		image: "/brands/microsoft-surface.jpg",
		span: "sm:col-span-2",
		position: "object-[50%_75%]"
	},
	{
		brand: "Apple",
		title: "MacBook",
		image: "/brands/apple-macbook.jpg",
		span: ""
	},
	{
		brand: "HP",
		title: "Pavilion",
		image: "/brands/hp-pavilion.jpg",
		span: ""
	},
	{
		brand: "Lenovo",
		title: "IdeaPad & ThinkPad",
		image: "/brands/lenovo-ideapad.jpg",
		span: "sm:col-span-2"
	},
	{
		brand: "ASUS",
		title: "VivoBook",
		image: "/brands/asus-vivobook.jpg",
		span: "sm:col-span-2"
	}
];
function Home() {
	const { whatsappUrl } = useSiteSettings();
	const products = useProducts().filter((product) => product.active !== false && product.inCatalog !== false);
	const brands = groupBrands(products);
	const categoryGroups = groupCategories(products);
	const featured = [...products.filter((p) => p.hot), ...products.filter((p) => !p.hot)].filter((product) => product.image).slice(0, 4);
	const stats = [
		{
			value: products.length,
			label: "Products online"
		},
		{
			value: categoryGroups.length,
			label: "Categories"
		},
		{
			value: brands.length,
			label: "Brands"
		}
	];
	return /* @__PURE__ */ jsxs("div", {
		className: "bg-white",
		children: [
			/* @__PURE__ */ jsx("section", {
				className: "page-hero overflow-hidden",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 md:py-24 lg:grid-cols-[1fr_1.15fr] lg:px-8",
					children: [/* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("p", {
							className: "eyebrow",
							children: SITE_NAME
						}),
						/* @__PURE__ */ jsxs("h1", {
							className: "mt-4 text-4xl font-bold leading-tight text-brand-charcoal md:text-6xl",
							children: ["Powering Your ", /* @__PURE__ */ jsx("span", {
								className: "text-brand-ember",
								children: "Digital Future"
							})]
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mt-6 max-w-xl text-lg text-gray-600",
							children: "Laptops, desktops and accessories from the brands you trust, with honest advice and support from our team on Moi Avenue, Nairobi."
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ jsxs(SiteLink, {
								to: "/products",
								className: "inline-flex items-center justify-center gap-2 rounded-full bg-brand-yellow px-7 py-3.5 font-bold text-brand-charcoal transition-colors hover:bg-brand-orange",
								children: ["Explore products ", /* @__PURE__ */ jsx(ArrowRight, {
									size: 18,
									"aria-hidden": "true"
								})]
							}), /* @__PURE__ */ jsx(SiteLink, {
								to: "/contact",
								className: "inline-flex items-center justify-center gap-2 rounded-full border-2 border-brand-charcoal px-7 py-3.5 font-bold text-brand-charcoal transition-colors hover:bg-brand-charcoal hover:text-white",
								children: "Get a free consultation"
							})]
						}),
						/* @__PURE__ */ jsx("ul", {
							className: "mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-600",
							children: [
								"Genuine products",
								"Expert advice",
								"Order on WhatsApp"
							].map((item) => /* @__PURE__ */ jsxs("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ jsx(CheckCircle2, {
									size: 16,
									className: "text-brand-blue",
									"aria-hidden": "true"
								}), item]
							}, item))
						})
					] }), /* @__PURE__ */ jsxs("div", {
						className: "relative mx-auto w-full max-w-2xl lg:-mr-8",
						children: [
							/* @__PURE__ */ jsx("div", {
								"aria-hidden": "true",
								className: "hero-backdrop absolute inset-x-[4%] inset-y-[2%] rounded-full"
							}),
							/* @__PURE__ */ jsxs("svg", {
								"aria-hidden": "true",
								className: "absolute -left-2 top-6 h-24 w-40 sm:h-28 sm:w-48",
								viewBox: "0 0 200 110",
								fill: "none",
								strokeWidth: "4",
								strokeLinecap: "round",
								children: [
									/* @__PURE__ */ jsx("path", {
										d: "M4 20h90l18-14h40",
										stroke: "#f7941d"
									}),
									/* @__PURE__ */ jsx("circle", {
										cx: "160",
										cy: "6",
										r: "5",
										stroke: "#f7941d"
									}),
									/* @__PURE__ */ jsx("path", {
										d: "M4 48h120",
										stroke: "#f7941d"
									}),
									/* @__PURE__ */ jsx("circle", {
										cx: "132",
										cy: "48",
										r: "5",
										stroke: "#f7941d"
									}),
									/* @__PURE__ */ jsx("path", {
										d: "M4 76h70l18 18h40",
										stroke: "#066bc3"
									}),
									/* @__PURE__ */ jsx("circle", {
										cx: "140",
										cy: "94",
										r: "5",
										stroke: "#066bc3"
									})
								]
							}),
							/* @__PURE__ */ jsx("img", {
								src: "/hero-devices.png",
								alt: "Desktop computer, laptop, keyboard and mouse",
								width: "860",
								height: "538",
								fetchPriority: "high",
								className: "hero-float relative w-full drop-shadow-2xl"
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "hero-float absolute left-0 top-[58%] hidden items-center gap-3 rounded-2xl bg-white/95 px-4 py-3 shadow-lg ring-1 ring-slate-200 backdrop-blur sm:flex",
								style: { animationDelay: "-2s" },
								children: [/* @__PURE__ */ jsx("span", {
									className: "flex h-10 w-10 items-center justify-center rounded-xl bg-brand-yellow/15 text-brand-ember",
									children: /* @__PURE__ */ jsx(ShieldCheck, {
										size: 22,
										"aria-hidden": "true"
									})
								}), /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
									className: "block text-sm font-semibold text-brand-charcoal",
									children: "Genuine & warrantied"
								}), /* @__PURE__ */ jsx("span", {
									className: "block text-xs text-gray-500",
									children: "Laptops, desktops & accessories"
								})] })]
							}),
							products.length > 0 ? /* @__PURE__ */ jsx("div", {
								className: "hero-float absolute -bottom-4 right-2 flex divide-x divide-slate-200 rounded-2xl bg-white/95 py-3 shadow-lg ring-1 ring-slate-200 backdrop-blur sm:right-6",
								style: { animationDelay: "-4s" },
								children: stats.map(({ value, label }) => /* @__PURE__ */ jsxs("div", {
									className: "px-4 text-center",
									children: [/* @__PURE__ */ jsx("p", {
										className: "font-heading text-2xl font-bold text-brand-charcoal",
										children: value
									}), /* @__PURE__ */ jsx("p", {
										className: "text-[0.65rem] uppercase tracking-wide text-gray-500",
										children: label
									})]
								}, label))
							}) : /* @__PURE__ */ jsxs("div", {
								className: "hero-float absolute -bottom-4 right-2 flex items-center gap-3 rounded-2xl bg-white/95 px-4 py-3 shadow-lg ring-1 ring-slate-200 backdrop-blur sm:right-6",
								style: { animationDelay: "-4s" },
								children: [/* @__PURE__ */ jsx("span", {
									className: "flex h-10 w-10 items-center justify-center rounded-xl bg-brand-blue/10 text-brand-blue",
									children: /* @__PURE__ */ jsx(PackageOpen, {
										size: 20,
										"aria-hidden": "true"
									})
								}), /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
									className: "block text-sm font-semibold text-brand-charcoal",
									children: "No products added yet"
								}), /* @__PURE__ */ jsx("span", {
									className: "block text-xs text-gray-500",
									children: "Ask us on WhatsApp for today's stock"
								})] })]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "border-b border-slate-200 bg-white py-14",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ jsx("p", {
						className: "eyebrow justify-center",
						children: "Brands we supply"
					}), /* @__PURE__ */ jsx("h2", {
						className: "mt-3 text-2xl font-bold text-brand-charcoal md:text-3xl",
						children: "The names you trust, from one supplier"
					})]
				}), /* @__PURE__ */ jsx("div", {
					className: "mt-10",
					children: /* @__PURE__ */ jsx(LogoMarquee, {})
				})]
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-20",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap items-end justify-between gap-4",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
								className: "eyebrow",
								children: "What we offer"
							}), /* @__PURE__ */ jsx("h2", {
								className: "mt-3 text-3xl font-bold text-brand-charcoal md:text-4xl",
								children: "Solutions for every need"
							})] }), /* @__PURE__ */ jsxs(SiteLink, {
								to: "/products",
								className: "inline-flex items-center gap-2 font-semibold text-brand-charcoal hover:text-brand-ember",
								children: ["View the full catalogue ", /* @__PURE__ */ jsx(ArrowRight, {
									size: 16,
									"aria-hidden": "true"
								})]
							})]
						}),
						categoryGroups.length === 0 && /* @__PURE__ */ jsx("div", {
							className: "mt-10",
							children: /* @__PURE__ */ jsx(EmptyState, {
								icon: LayoutGrid,
								compact: true,
								title: "No categories added yet",
								text: "Laptops, desktops and accessories categories will appear here as products are added."
							})
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 empty:hidden",
							children: categoryGroups.map((group, index) => /* @__PURE__ */ jsxs(SiteLink, {
								to: categoryPath(group.name),
								className: "group flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-5 transition-all hover:-translate-y-0.5 hover:border-brand-yellow hover:shadow-md",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: `flex h-12 w-12 shrink-0 items-center justify-center rounded-xl font-heading text-lg font-bold ${index % 2 ? "bg-brand-yellow/15 text-brand-ember" : "bg-brand-blue/10 text-brand-blue"}`,
										children: group.name.slice(0, 2).toUpperCase()
									}),
									/* @__PURE__ */ jsxs("span", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ jsx("span", {
											className: "block font-semibold text-brand-charcoal",
											children: group.name
										}), /* @__PURE__ */ jsxs("span", {
											className: "block text-sm text-gray-500",
											children: [
												group.products.length,
												" product",
												group.products.length === 1 ? "" : "s"
											]
										})]
									}),
									/* @__PURE__ */ jsx(ArrowUpRight, {
										size: 20,
										className: "shrink-0 text-gray-400 transition-colors group-hover:text-brand-ember",
										"aria-hidden": "true"
									})
								]
							}, group.slug))
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "bg-slate-50 py-20",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap items-end justify-between gap-4",
						children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
							className: "eyebrow",
							children: "Shop by brand"
						}), /* @__PURE__ */ jsx("h2", {
							className: "mt-3 text-3xl font-bold text-brand-charcoal md:text-4xl",
							children: "Find your next laptop"
						})] }), /* @__PURE__ */ jsxs(SiteLink, {
							to: "/brands",
							className: "inline-flex items-center gap-2 font-semibold text-brand-charcoal hover:text-brand-ember",
							children: ["All brands ", /* @__PURE__ */ jsx(ArrowRight, {
								size: 16,
								"aria-hidden": "true"
							})]
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "mt-10 grid auto-rows-[220px] gap-4 sm:grid-cols-2 lg:grid-cols-4",
						children: BRAND_TILES.map(({ brand, title, image, span, position = "object-center" }) => /* @__PURE__ */ jsxs(SiteLink, {
							to: brandProductsPath(brand),
							className: `group relative overflow-hidden rounded-3xl bg-slate-900 ${span}`,
							children: [
								/* @__PURE__ */ jsx("img", {
									src: image,
									alt: "",
									loading: "lazy",
									className: `absolute inset-0 h-full w-full object-cover ${position} transition-transform duration-500 group-hover:scale-105`
								}),
								/* @__PURE__ */ jsx("span", {
									"aria-hidden": "true",
									className: "absolute inset-0 bg-gradient-to-t from-brand-black/85 via-brand-black/20 to-transparent"
								}),
								/* @__PURE__ */ jsxs("span", {
									className: "absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5",
									children: [/* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
										className: "block text-xs font-semibold uppercase tracking-[0.16em] text-brand-yellow",
										children: brand
									}), /* @__PURE__ */ jsx("span", {
										className: "mt-1 block font-heading text-xl font-bold text-white md:text-2xl",
										children: title
									})] }), /* @__PURE__ */ jsx("span", {
										className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/15 text-white backdrop-blur transition-colors group-hover:bg-brand-yellow group-hover:text-brand-charcoal",
										children: /* @__PURE__ */ jsx(ArrowUpRight, {
											size: 18,
											"aria-hidden": "true"
										})
									})]
								})
							]
						}, image))
					})]
				})
			}),
			featured.length > 0 && /* @__PURE__ */ jsx("section", {
				className: "bg-slate-50 py-20",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsx("p", {
							className: "eyebrow",
							children: "Popular right now"
						}),
						/* @__PURE__ */ jsx("h2", {
							className: "mt-3 text-3xl font-bold text-brand-charcoal md:text-4xl",
							children: "Featured products"
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-10 -mx-4 flex snap-x gap-4 overflow-x-auto px-4 pb-2 sm:mx-0 sm:grid sm:grid-cols-2 sm:overflow-visible sm:px-0 lg:grid-cols-4",
							children: featured.map((product) => /* @__PURE__ */ jsxs(SiteLink, {
								to: productPath(product),
								className: "group w-56 shrink-0 snap-start overflow-hidden rounded-2xl bg-white ring-1 ring-slate-200 transition-shadow hover:shadow-lg sm:w-auto",
								children: [/* @__PURE__ */ jsx("div", {
									className: "aspect-[4/3] bg-white p-4",
									children: /* @__PURE__ */ jsx("img", {
										src: assetUrl(product.image),
										alt: product.name,
										loading: "lazy",
										className: "h-full w-full object-contain"
									})
								}), /* @__PURE__ */ jsxs("div", {
									className: "border-t border-slate-100 p-4",
									children: [/* @__PURE__ */ jsx("p", {
										className: "text-xs font-semibold uppercase tracking-wide text-brand-blue",
										children: product.categoryName || product.category
									}), /* @__PURE__ */ jsx("h3", {
										className: "mt-1 line-clamp-2 font-semibold text-brand-charcoal group-hover:text-brand-ember",
										children: product.name
									})]
								})]
							}, product.id))
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-20",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "max-w-2xl",
						children: [/* @__PURE__ */ jsx("p", {
							className: "eyebrow",
							children: "Why JOJO"
						}), /* @__PURE__ */ jsx("h2", {
							className: "mt-3 text-3xl font-bold text-brand-charcoal md:text-4xl",
							children: "Technology you can rely on, people you can reach"
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
						children: REASONS.map(({ icon: Icon, title, text }, index) => /* @__PURE__ */ jsxs("div", {
							className: "relative rounded-2xl border border-slate-200 p-6",
							children: [
								/* @__PURE__ */ jsx("span", {
									className: "absolute right-5 top-4 font-heading text-4xl font-bold text-slate-100",
									"aria-hidden": "true",
									children: String(index + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ jsx(Icon, {
									size: 28,
									className: "relative text-brand-ember",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx("h3", {
									className: "relative mt-4 text-lg font-semibold text-brand-charcoal",
									children: title
								}),
								/* @__PURE__ */ jsx("p", {
									className: "relative mt-2 text-sm text-gray-600",
									children: text
								})
							]
						}, title))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "pb-4",
				children: /* @__PURE__ */ jsx("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "grid items-center gap-8 rounded-3xl bg-slate-50 p-6 ring-1 ring-slate-200 md:grid-cols-[1fr_1.2fr] md:p-10",
						children: [/* @__PURE__ */ jsxs("div", { children: [
							/* @__PURE__ */ jsx("p", {
								className: "eyebrow",
								children: "Accessories"
							}),
							/* @__PURE__ */ jsx("h2", {
								className: "mt-3 text-2xl font-bold text-brand-charcoal md:text-3xl",
								children: "The finishing touches"
							}),
							/* @__PURE__ */ jsx("p", {
								className: "mt-3 text-gray-600",
								children: "Docking stations, USB-C hubs, HDMI switches and cables that turn one laptop into a full workstation."
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-6 flex flex-wrap items-center gap-x-6 gap-y-3",
								children: [/* @__PURE__ */ jsxs(SiteLink, {
									to: brandProductsPath("Vention"),
									className: "inline-flex items-center gap-2 font-semibold text-brand-charcoal hover:text-brand-ember",
									children: ["Browse accessories ", /* @__PURE__ */ jsx(ArrowRight, {
										size: 16,
										"aria-hidden": "true"
									})]
								}), /* @__PURE__ */ jsxs("span", {
									className: "flex items-center gap-2 text-xs uppercase tracking-wide text-gray-400",
									children: ["Featuring ", /* @__PURE__ */ jsx("img", {
										src: "/logos/vention.png",
										alt: "Vention",
										width: "1090",
										height: "120",
										loading: "lazy",
										className: "h-3.5 w-auto opacity-80"
									})]
								})]
							})
						] }), /* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-[1.35fr_1fr] gap-4",
							children: [/* @__PURE__ */ jsx("img", {
								src: "/brands/vention-dock.jpg",
								alt: "Vention 12-in-1 docking station under a laptop",
								width: "800",
								height: "585",
								loading: "lazy",
								className: "h-48 w-full rounded-2xl object-cover object-bottom sm:h-56"
							}), /* @__PURE__ */ jsx("img", {
								src: "/brands/vention-hdmi-switch.jpg",
								alt: "Vention HDMI switch with gold-plated ports",
								width: "700",
								height: "700",
								loading: "lazy",
								className: "h-48 w-full rounded-2xl object-cover object-right sm:h-56"
							})]
						})]
					})
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-20",
				children: /* @__PURE__ */ jsx("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-charcoal to-brand-blue px-8 py-12 text-white md:px-14",
						children: [/* @__PURE__ */ jsx("div", {
							"aria-hidden": "true",
							className: "absolute -right-16 -top-16 h-64 w-64 rounded-full bg-brand-yellow/20 blur-2xl"
						}), /* @__PURE__ */ jsxs("div", {
							className: "relative flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "max-w-xl",
								children: [/* @__PURE__ */ jsx("h2", {
									className: "text-3xl font-bold md:text-4xl",
									children: "Ready to upgrade your setup?"
								}), /* @__PURE__ */ jsx("p", {
									className: "mt-3 text-blue-100",
									children: "Tell us what you need and get a recommendation and a quote, usually within minutes."
								})]
							}), /* @__PURE__ */ jsxs("div", {
								className: "flex flex-col gap-3 sm:flex-row",
								children: [/* @__PURE__ */ jsxs("a", {
									href: whatsappUrl,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "inline-flex items-center justify-center gap-2 rounded-full bg-brand-yellow px-7 py-3.5 font-bold text-brand-charcoal transition-colors hover:bg-brand-orange",
									children: [/* @__PURE__ */ jsx(MessageCircle, {
										size: 18,
										"aria-hidden": "true"
									}), " Chat on WhatsApp"]
								}), /* @__PURE__ */ jsx(SiteLink, {
									to: "/about",
									className: "inline-flex items-center justify-center rounded-full border-2 border-white/70 px-7 py-3.5 font-bold text-white transition-colors hover:bg-white hover:text-brand-charcoal",
									children: "About JOJO"
								})]
							})]
						})]
					})
				})
			})
		]
	});
}
//#endregion
//#region src/components/PageHeader.jsx
function PageHeader({ eyebrow, title, accent, intro, children }) {
	return /* @__PURE__ */ jsx("section", {
		className: "page-hero",
		children: /* @__PURE__ */ jsxs("div", {
			className: "mx-auto max-w-7xl px-4 py-14 sm:px-6 md:py-20 lg:px-8",
			children: [
				eyebrow && /* @__PURE__ */ jsx("p", {
					className: "eyebrow",
					children: eyebrow
				}),
				/* @__PURE__ */ jsxs("h1", {
					className: "mt-3 max-w-3xl text-4xl font-bold text-brand-charcoal md:text-5xl",
					children: [title, accent && /* @__PURE__ */ jsxs(Fragment, { children: [" ", /* @__PURE__ */ jsx("span", {
						className: "text-brand-ember",
						children: accent
					})] })]
				}),
				intro && /* @__PURE__ */ jsx("p", {
					className: "mt-4 max-w-2xl text-lg text-gray-600",
					children: intro
				}),
				children
			]
		})
	});
}
//#endregion
//#region src/pages/About.jsx
var STEPS$1 = [
	{
		icon: MessagesSquare,
		title: "Tell us what you need",
		text: "Message us on WhatsApp, call or visit. We ask a few questions about how you will use it."
	},
	{
		icon: PackageCheck,
		title: "Get the right solution",
		text: "We recommend products that fit your setup and budget, and confirm price and availability."
	},
	{
		icon: Wrench,
		title: "Stay supported",
		text: "Delivery or pickup, setup help, and support after the sale."
	}
];
var VALUES = [
	{
		icon: Eye,
		title: "Our vision",
		text: "To be the first name people in Kenya think of for genuine computers, accessories and the advice to choose them well."
	},
	{
		icon: Target,
		title: "Our mission",
		text: "To put the right technology in every customer's hands, at a fair price, with support that lasts beyond the sale."
	},
	{
		icon: Handshake,
		title: "Integrity",
		text: "Honest advice and genuine products, every time."
	},
	{
		icon: Lightbulb,
		title: "Innovation",
		text: "Keeping our customers up to date with technology that works."
	}
];
function About() {
	const products = useProducts().filter((product) => product.active !== false && product.inCatalog !== false);
	const brands = groupBrands(products);
	const categoryGroups = groupCategories(products);
	return /* @__PURE__ */ jsxs("div", {
		className: "bg-white",
		children: [
			/* @__PURE__ */ jsx(PageHeader, {
				eyebrow: "About us",
				title: SITE_NAME,
				intro: TAGLINE
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-20",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8",
					children: [/* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("p", {
							className: "eyebrow",
							children: "Who we are"
						}),
						/* @__PURE__ */ jsx("h2", {
							className: "mt-3 text-3xl font-bold text-brand-charcoal md:text-4xl",
							children: "Technology partners for homes and businesses"
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "mt-5 text-gray-600",
							children: [SITE_NAME, " supplies laptops, desktops and accessories from HP, Lenovo, Dell, Apple, ASUS and other trusted brands to students, professionals and businesses. Visit us on Moi Avenue, Nairobi, or order on WhatsApp: we help you choose, confirm price and availability, and stay on hand after the sale."]
						})
					] }), /* @__PURE__ */ jsx("dl", {
						className: "grid grid-cols-2 gap-4 self-center",
						children: [
							{
								value: products.length,
								label: "Products online",
								none: "No products added yet"
							},
							{
								value: categoryGroups.length,
								label: "Categories",
								none: "No categories added yet"
							},
							{
								value: Math.max(brands.length, PARTNER_LOGOS.length),
								label: "Brands we supply"
							},
							{
								value: "Moi Ave",
								label: "Find us in Nairobi"
							}
						].map(({ value, label, none }) => /* @__PURE__ */ jsxs("div", {
							className: "rounded-2xl border border-slate-200 p-6",
							children: [/* @__PURE__ */ jsx("dt", {
								className: "text-sm text-gray-500",
								children: label
							}), value === 0 && none ? /* @__PURE__ */ jsx("dd", {
								className: "mt-2 text-sm font-medium text-gray-400",
								children: none
							}) : /* @__PURE__ */ jsx("dd", {
								className: "mt-1 font-heading text-4xl font-bold text-brand-charcoal",
								children: value
							})]
						}, label))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "bg-slate-50 py-20",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsx("p", {
							className: "eyebrow",
							children: "How we work"
						}),
						/* @__PURE__ */ jsx("h2", {
							className: "mt-3 text-3xl font-bold text-brand-charcoal md:text-4xl",
							children: "Three simple steps"
						}),
						/* @__PURE__ */ jsx("ol", {
							className: "mt-10 grid gap-6 md:grid-cols-3",
							children: STEPS$1.map(({ icon: Icon, title, text }, index) => /* @__PURE__ */ jsxs("li", {
								className: "rounded-2xl bg-white p-6 ring-1 ring-slate-200",
								children: [
									/* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ jsx("span", {
											className: "flex h-10 w-10 items-center justify-center rounded-full bg-brand-charcoal font-heading font-bold text-white",
											children: index + 1
										}), /* @__PURE__ */ jsx(Icon, {
											size: 22,
											className: "text-brand-ember",
											"aria-hidden": "true"
										})]
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "mt-4 text-lg font-semibold text-brand-charcoal",
										children: title
									}),
									/* @__PURE__ */ jsx("p", {
										className: "mt-2 text-sm text-gray-600",
										children: text
									})
								]
							}, title))
						})
					]
				})
			}),
			categoryGroups.length > 0 && /* @__PURE__ */ jsx("section", {
				className: "py-20",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsx("p", {
							className: "eyebrow",
							children: "What we do"
						}),
						/* @__PURE__ */ jsx("h2", {
							className: "mt-3 text-3xl font-bold text-brand-charcoal md:text-4xl",
							children: "Our product range"
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: categoryGroups.map((group) => /* @__PURE__ */ jsxs(SiteLink, {
								to: categoryPath(group.name),
								className: "rounded-full border border-slate-200 px-5 py-2.5 text-sm font-medium text-brand-charcoal transition-colors hover:border-brand-yellow hover:bg-brand-yellow/10",
								children: [
									group.name,
									" ",
									/* @__PURE__ */ jsxs("span", {
										className: "text-gray-400",
										children: ["· ", group.products.length]
									})
								]
							}, group.slug))
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "border-t border-slate-200 py-20",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ jsx("p", {
						className: "eyebrow",
						children: "What drives us"
					}), /* @__PURE__ */ jsx("div", {
						className: "mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
						children: VALUES.map(({ icon: Icon, title, text }) => /* @__PURE__ */ jsxs("div", {
							className: "border-l-4 border-brand-yellow pl-5",
							children: [
								/* @__PURE__ */ jsx(Icon, {
									size: 24,
									className: "text-brand-blue",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx("h3", {
									className: "mt-3 font-semibold text-brand-charcoal",
									children: title
								}),
								/* @__PURE__ */ jsx("p", {
									className: "mt-1 text-sm text-gray-600",
									children: text
								})
							]
						}, title))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "pb-20",
				children: /* @__PURE__ */ jsx("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "flex flex-col items-start justify-between gap-6 rounded-3xl bg-gradient-to-br from-brand-charcoal to-brand-blue px-8 py-10 text-white md:flex-row md:items-center md:px-12",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ jsx(Rocket, {
								size: 32,
								className: "text-brand-yellow",
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsx("h2", {
								className: "text-2xl font-bold md:text-3xl",
								children: "Let's power your digital future."
							})]
						}), /* @__PURE__ */ jsxs(SiteLink, {
							to: "/contact",
							className: "inline-flex items-center gap-2 rounded-full bg-brand-yellow px-7 py-3.5 font-bold text-brand-charcoal transition-colors hover:bg-brand-orange",
							children: ["Talk to us ", /* @__PURE__ */ jsx(ArrowRight, {
								size: 18,
								"aria-hidden": "true"
							})]
						})]
					})
				})
			})
		]
	});
}
//#endregion
//#region src/pages/Brands.jsx
function BrandMark({ brand, className = "h-28" }) {
	return /* @__PURE__ */ jsx("div", {
		className: `${className} w-full flex items-center justify-center overflow-hidden bg-white rounded-lg`,
		children: brand.logo ? /* @__PURE__ */ jsx("img", {
			src: brand.logo,
			alt: `${brand.name} logo`,
			loading: "lazy",
			className: "h-full w-full object-contain p-2"
		}) : /* @__PURE__ */ jsx("span", {
			className: "px-3 text-center text-2xl font-extrabold uppercase tracking-wide text-brand-charcoal",
			children: brand.name
		})
	});
}
var FEATURED = [
	"Lenovo",
	"Microsoft",
	"ASUS",
	"Toshiba"
].map(brandInfo).filter((brand) => brand.card);
function Brands() {
	const brands = groupBrands(useProducts().filter((product) => product.inCatalog !== false));
	const orderOnly = orderOnlyBrands(brands);
	const productCount = brands.reduce((sum, brand) => sum + brand.count, 0);
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen bg-gray-50",
		children: [
			/* @__PURE__ */ jsx(PageHeader, {
				eyebrow: "Partners",
				title: "Brands we",
				accent: "supply",
				intro: "Genuine products from the manufacturers we trust, with warranty and support.",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mt-8 flex flex-wrap gap-4",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "rounded-2xl bg-white px-6 py-4 ring-1 ring-slate-200",
						children: [/* @__PURE__ */ jsx("div", {
							className: "font-heading text-3xl font-bold text-brand-charcoal",
							children: brands.length
						}), /* @__PURE__ */ jsx("div", {
							className: "text-sm text-gray-500",
							children: "Brands in our catalogue"
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "rounded-2xl bg-white px-6 py-4 ring-1 ring-slate-200",
						children: [/* @__PURE__ */ jsx("div", {
							className: "font-heading text-3xl font-bold text-brand-charcoal",
							children: productCount
						}), /* @__PURE__ */ jsx("div", {
							className: "text-sm text-gray-500",
							children: "Branded products online"
						})]
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "bg-white pt-14",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ jsx("p", {
						className: "eyebrow",
						children: "Featured brands"
					}), /* @__PURE__ */ jsx("div", {
						className: "mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4",
						children: FEATURED.map((brand) => /* @__PURE__ */ jsx(SiteLink, {
							to: brandProductsPath(brand.name),
							className: "group overflow-hidden rounded-2xl ring-1 ring-slate-200 transition-shadow hover:shadow-lg",
							children: /* @__PURE__ */ jsx("img", {
								src: brand.card,
								alt: brand.name,
								loading: "lazy",
								width: "800",
								height: "428",
								className: "aspect-[800/428] w-full object-cover transition-transform duration-500 group-hover:scale-105"
							})
						}, brand.key))
					})]
				})
			}),
			/* @__PURE__ */ jsx("nav", {
				"aria-label": "Jump to a brand",
				className: "bg-white border-b border-gray-200",
				children: /* @__PURE__ */ jsx("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-wrap gap-2",
					children: brands.map((brand) => /* @__PURE__ */ jsxs("a", {
						href: `#brand-${brand.key}`,
						className: "rounded-full bg-gray-100 px-3 py-1.5 text-sm font-medium text-gray-700 transition-colors hover:bg-brand-yellow hover:text-brand-charcoal",
						children: [
							brand.name,
							" ",
							/* @__PURE__ */ jsxs("span", {
								className: "text-gray-500",
								children: [
									"(",
									brand.count,
									")"
								]
							})
						]
					}, brand.key))
				})
			}),
			brands.length > 0 && /* @__PURE__ */ jsx("section", {
				className: "py-16 bg-white",
				children: /* @__PURE__ */ jsxs("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "mb-12",
						children: [/* @__PURE__ */ jsx("h2", {
							className: "text-3xl font-bold text-brand-charcoal mb-4",
							children: "Brands in Our Catalogue"
						}), /* @__PURE__ */ jsx("p", {
							className: "text-gray-600 max-w-2xl",
							children: "Every brand below has products you can browse online today. Open a brand to see all of its products."
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6",
						children: brands.map((brand) => /* @__PURE__ */ jsxs("article", {
							id: `brand-${brand.key}`,
							className: "scroll-mt-28 flex flex-col bg-gray-50 rounded-xl p-6 border-2 border-gray-200 hover:border-brand-yellow transition-all hover:shadow-lg",
							children: [
								/* @__PURE__ */ jsx("div", {
									className: "mb-4",
									children: /* @__PURE__ */ jsx(BrandMark, { brand })
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "mb-3 flex items-baseline justify-between gap-2",
									children: [/* @__PURE__ */ jsx("h3", {
										className: "text-xl font-bold text-brand-charcoal",
										children: brand.name
									}), /* @__PURE__ */ jsxs("span", {
										className: "shrink-0 rounded-full bg-brand-yellow px-3 py-1 text-xs font-semibold text-brand-charcoal",
										children: [
											brand.count,
											" product",
											brand.count === 1 ? "" : "s"
										]
									})]
								}),
								/* @__PURE__ */ jsx("p", {
									className: "text-gray-600 mb-3",
									children: brand.blurb
								}),
								/* @__PURE__ */ jsx("p", {
									className: "mb-5 text-xs uppercase tracking-wide text-gray-500",
									children: brand.categories.join(" · ")
								}),
								/* @__PURE__ */ jsxs(SiteLink, {
									to: brandProductsPath(brand.name),
									className: "mt-auto inline-flex items-center gap-2 font-semibold text-brand-charcoal hover:text-brand-ember",
									children: [
										"View ",
										brand.count === 1 ? "the product" : `all ${brand.count} products`,
										/* @__PURE__ */ jsx(ArrowRight, { size: 16 })
									]
								})
							]
						}, brand.key))
					})]
				})
			}),
			orderOnly.length > 0 && /* @__PURE__ */ jsx("section", {
				className: "py-16 bg-gray-50",
				children: /* @__PURE__ */ jsxs("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsx("h2", {
							className: "text-3xl font-bold text-brand-charcoal mb-4",
							children: "Also Available to Order"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-gray-600 max-w-2xl mb-8",
							children: "We also supply these brands. They aren't in the online catalogue yet, so ask us on WhatsApp or visit the shop for current stock."
						}),
						/* @__PURE__ */ jsx("div", {
							className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4",
							children: orderOnly.map((brand) => /* @__PURE__ */ jsxs("div", {
								className: "rounded-xl border border-gray-200 bg-white p-4",
								children: [
									/* @__PURE__ */ jsx(BrandMark, {
										brand,
										className: "h-20"
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "mt-3 font-bold text-brand-charcoal",
										children: brand.name
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-sm text-gray-600",
										children: brand.blurb
									})
								]
							}, brand.key))
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-16 bg-slate-50",
				children: /* @__PURE__ */ jsx("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "grid grid-cols-1 lg:grid-cols-2 gap-12 items-center",
						children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h2", {
							className: "text-3xl font-bold text-brand-charcoal mb-6",
							children: "Why buy through JOJO"
						}), /* @__PURE__ */ jsxs("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start space-x-4",
									children: [/* @__PURE__ */ jsx("div", {
										className: "bg-brand-yellow p-2 rounded-lg",
										children: /* @__PURE__ */ jsx("span", {
											className: "text-brand-charcoal font-bold",
											children: "✓"
										})
									}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h4", {
										className: "text-brand-charcoal font-semibold mb-1",
										children: "Tested and trusted"
									}), /* @__PURE__ */ jsx("p", {
										className: "text-gray-500 text-sm",
										children: "We only stock brands with a proven record for reliability and performance"
									})] })]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start space-x-4",
									children: [/* @__PURE__ */ jsx("div", {
										className: "bg-brand-yellow p-2 rounded-lg",
										children: /* @__PURE__ */ jsx("span", {
											className: "text-brand-charcoal font-bold",
											children: "✓"
										})
									}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h4", {
										className: "text-brand-charcoal font-semibold mb-1",
										children: "Genuine, warrantied stock"
									}), /* @__PURE__ */ jsx("p", {
										className: "text-gray-500 text-sm",
										children: "Sourced through authorised channels, so every product is original"
									})] })]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start space-x-4",
									children: [/* @__PURE__ */ jsx("div", {
										className: "bg-brand-yellow p-2 rounded-lg",
										children: /* @__PURE__ */ jsx("span", {
											className: "text-brand-charcoal font-bold",
											children: "✓"
										})
									}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h4", {
										className: "text-brand-charcoal font-semibold mb-1",
										children: "Setup and configuration"
									}), /* @__PURE__ */ jsx("p", {
										className: "text-gray-500 text-sm",
										children: "We help you set up and configure what you buy"
									})] })]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start space-x-4",
									children: [/* @__PURE__ */ jsx("div", {
										className: "bg-brand-yellow p-2 rounded-lg",
										children: /* @__PURE__ */ jsx("span", {
											className: "text-brand-charcoal font-bold",
											children: "✓"
										})
									}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h4", {
										className: "text-brand-charcoal font-semibold mb-1",
										children: "Support after the sale"
									}), /* @__PURE__ */ jsx("p", {
										className: "text-gray-500 text-sm",
										children: "Accessories, replacements and technical help whenever you need them"
									})] })]
								})
							]
						})] }), /* @__PURE__ */ jsxs("div", {
							className: "bg-gradient-to-br from-brand-yellow to-brand-orange rounded-xl p-8 text-brand-charcoal",
							children: [
								/* @__PURE__ */ jsx("h3", {
									className: "text-2xl font-bold mb-4",
									children: "Looking for a specific brand?"
								}),
								/* @__PURE__ */ jsx("p", {
									className: "mb-6",
									children: "Tell us the brand or model you have in mind and we'll check availability and get you a quote."
								}),
								/* @__PURE__ */ jsx("a", {
									href: "/contact",
									className: "inline-block bg-brand-charcoal text-white px-6 py-3 rounded-full font-bold hover:bg-black transition-colors",
									children: "Ask about a brand"
								})
							]
						})]
					})
				})
			})
		]
	});
}
//#endregion
//#region src/components/ProductImage.jsx
function ProductImage({ src: rawSrc, alt, className = "", onOpen }) {
	const src = assetUrl(rawSrc);
	const [isOpen, setIsOpen] = useState(false);
	useEffect(() => {
		if (!isOpen) return void 0;
		const closeOnEscape = (event) => {
			if (event.key === "Escape") setIsOpen(false);
		};
		window.addEventListener("keydown", closeOnEscape);
		return () => window.removeEventListener("keydown", closeOnEscape);
	}, [isOpen]);
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("button", {
		type: "button",
		onClick: () => {
			setIsOpen(true);
			onOpen?.();
		},
		"aria-label": `View larger image: ${alt}`,
		className: `group relative block aspect-square w-full overflow-hidden bg-white ${className}`,
		children: [/* @__PURE__ */ jsx("img", {
			src,
			alt,
			loading: "lazy",
			className: "h-full w-full object-cover"
		}), /* @__PURE__ */ jsx("span", {
			className: "absolute inset-0 flex items-center justify-center bg-brand-charcoal/0 text-white opacity-0 transition group-hover:bg-brand-charcoal/25 group-hover:opacity-100 group-focus-visible:bg-brand-charcoal/25 group-focus-visible:opacity-100",
			children: /* @__PURE__ */ jsx(ZoomIn, {
				size: 30,
				"aria-hidden": "true"
			})
		})]
	}), isOpen && /* @__PURE__ */ jsxs("div", {
		role: "dialog",
		"aria-modal": "true",
		"aria-label": `Larger image: ${alt}`,
		className: "fixed inset-0 z-[100] flex items-center justify-center bg-black/85 p-4 sm:p-8",
		onClick: () => setIsOpen(false),
		children: [/* @__PURE__ */ jsx("button", {
			type: "button",
			onClick: () => setIsOpen(false),
			"aria-label": "Close enlarged image",
			className: "absolute right-4 top-4 z-10 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/25",
			children: /* @__PURE__ */ jsx(X, { size: 24 })
		}), /* @__PURE__ */ jsx("div", {
			className: "relative inline-block max-h-[90vh] max-w-[92vw]",
			onClick: (event) => event.stopPropagation(),
			children: /* @__PURE__ */ jsx("img", {
				src,
				alt,
				className: "max-h-[90vh] max-w-[92vw] object-contain shadow-2xl"
			})
		})]
	})] });
}
//#endregion
//#region src/pages/Products.jsx
var BIG_TILES = 3;
var MEDIUM_TILES = 4;
var TILE_CLASS = {
	big: "col-span-3 row-span-3",
	medium: "col-span-2 row-span-2",
	small: "col-span-1 row-span-1"
};
function shuffle(items, seed) {
	let a = seed >>> 0;
	const random = () => {
		a = a + 1831565813 >>> 0;
		let t = a;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
	const out = [...items];
	for (let i = out.length - 1; i > 0; i--) {
		const j = Math.floor(random() * (i + 1));
		[out[i], out[j]] = [out[j], out[i]];
	}
	return out;
}
function Products() {
	const allProducts = useProducts();
	const { whatsappUrl } = useSiteSettings();
	const [currentPage, setCurrentPage] = useState(1);
	const catalogProducts = allProducts.filter((product) => product.inCatalog !== false);
	const categoryGroups = groupCategories(catalogProducts);
	const [brand, setBrand] = useState("All");
	const [query, setQuery] = useState("");
	const brandOptions = [...new Set(catalogProducts.map((product) => product.brand).filter(Boolean))].sort((a, b) => a.localeCompare(b));
	const searchText = query.trim().toLowerCase();
	const filteredProducts = catalogProducts.filter((product) => (brand === "All" || brandKey(product.brand) === brandKey(brand)) && (!searchText || product.name.toLowerCase().includes(searchText) || (product.brand || "").toLowerCase().includes(searchText) || (product.specs || "").toLowerCase().includes(searchText)));
	const clearFilters = () => {
		setBrand("All");
		setQuery("");
		setCurrentPage(1);
	};
	const [searchParams] = useSearchParams();
	const brandParam = searchParams.get("brand");
	useEffect(() => {
		if (!brandParam) return;
		setBrand(brandParam);
		setCurrentPage(1);
	}, [brandParam]);
	const [seed, setSeed] = useState(null);
	useEffect(() => {
		setSeed(Math.floor(Math.random() * 2 ** 32));
	}, []);
	const shuffledProducts = seed === null ? filteredProducts : shuffle(filteredProducts, seed);
	const pageSize = 24;
	const totalPages = Math.ceil(shuffledProducts.length / pageSize);
	const pageProducts = shuffledProducts.slice((currentPage - 1) * pageSize, currentPage * pageSize);
	const tiers = (() => {
		const big = Math.min(BIG_TILES, pageProducts.length);
		const medium = Math.min(MEDIUM_TILES, pageProducts.length - big);
		const list = [
			...Array(big).fill("big"),
			...Array(medium).fill("medium"),
			...Array(pageProducts.length - big - medium).fill("small")
		];
		return seed === null ? list : shuffle(list, seed + currentPage);
	})();
	const firstProduct = filteredProducts.length ? (currentPage - 1) * pageSize + 1 : 0;
	const lastProduct = Math.min(currentPage * pageSize, filteredProducts.length);
	const renderGalleryTile = (product, tier) => /* @__PURE__ */ jsxs("article", {
		className: `relative overflow-hidden rounded-xl bg-brand-charcoal shadow-md ${TILE_CLASS[tier]}`,
		children: [/* @__PURE__ */ jsx(ProductImage, {
			src: product.image,
			alt: product.name,
			className: "absolute inset-0 !aspect-auto h-full"
		}), /* @__PURE__ */ jsxs("div", {
			className: `pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent text-left ${tier === "small" ? "px-2 pb-2 pt-6" : "px-4 pb-4 pt-12"}`,
			children: [tier !== "small" && /* @__PURE__ */ jsxs("p", {
				className: "mb-1 text-xs uppercase tracking-wide text-white/75",
				children: [
					product.brand,
					product.condition && ` · ${product.condition}`,
					" · ",
					product.categoryName
				]
			}), /* @__PURE__ */ jsx("h2", {
				className: tier === "small" ? "line-clamp-2 text-[11px] font-semibold leading-tight text-white sm:text-xs" : tier === "medium" ? "text-sm font-semibold text-white sm:text-base" : "text-base font-semibold text-white sm:text-xl",
				children: /* @__PURE__ */ jsx(SiteLink, {
					to: productPath(product),
					className: "pointer-events-auto hover:underline",
					children: product.name
				})
			})]
		})]
	}, product.id);
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen bg-gray-50",
		children: [
			/* @__PURE__ */ jsx(PageHeader, {
				eyebrow: "Catalogue",
				title: "Our",
				accent: "products",
				intro: "Browse the full range, then ask for prices and availability on WhatsApp."
			}),
			/* @__PURE__ */ jsx("section", {
				className: "bg-white border-b border-gray-200 lg:sticky lg:top-20 lg:z-40",
				children: /* @__PURE__ */ jsx("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4",
					children: /* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap items-center justify-between gap-4",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex items-center space-x-2",
							children: [/* @__PURE__ */ jsx(Filter, {
								size: 20,
								className: "text-gray-600"
							}), /* @__PURE__ */ jsx("span", {
								className: "text-gray-600 font-medium",
								children: "Filter by:"
							})]
						}), /* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ jsx("span", {
								"aria-current": "page",
								className: "px-4 py-2 rounded-lg font-medium bg-brand-yellow text-brand-charcoal",
								children: "All Products"
							}), categoryGroups.map((group) => /* @__PURE__ */ jsx(SiteLink, {
								to: categoryPath(group.name),
								className: "px-4 py-2 rounded-lg font-medium transition-colors bg-gray-200 text-gray-700 hover:bg-gray-300",
								children: group.name
							}, group.slug))]
						})]
					})
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-16",
				children: /* @__PURE__ */ jsxs("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "relative flex-1",
								children: [/* @__PURE__ */ jsx(Search, {
									className: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400",
									size: 18,
									"aria-hidden": "true"
								}), /* @__PURE__ */ jsx("input", {
									type: "search",
									value: query,
									onChange: (e) => {
										setQuery(e.target.value);
										setCurrentPage(1);
									},
									placeholder: "Search products or brands...",
									"aria-label": "Search the catalogue",
									className: "w-full rounded-lg border border-gray-300 bg-white py-3 pl-10 pr-4 focus:border-transparent focus:ring-2 focus:ring-brand-yellow"
								})]
							}), /* @__PURE__ */ jsxs("select", {
								value: brand,
								onChange: (e) => {
									setBrand(e.target.value);
									setCurrentPage(1);
								},
								"aria-label": "Filter by brand",
								className: "rounded-lg border border-gray-300 bg-white px-4 py-3 focus:border-transparent focus:ring-2 focus:ring-brand-yellow",
								children: [/* @__PURE__ */ jsx("option", {
									value: "All",
									children: "All brands"
								}), brandOptions.map((option) => /* @__PURE__ */ jsx("option", {
									value: option,
									children: option
								}, option))]
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mb-6 flex items-center justify-between",
							children: /* @__PURE__ */ jsx("p", {
								className: "text-gray-600",
								"aria-live": "polite",
								children: filteredProducts.length === 0 ? allProducts.length === 0 ? "No products added yet" : "No products found" : filteredProducts.length === 1 ? "Showing 1 product" : `Showing ${firstProduct}–${lastProduct} of ${filteredProducts.length} products`
							})
						}),
						allProducts.length === 0 ? /* @__PURE__ */ jsx(EmptyState, {
							title: "No products added yet",
							text: "Our catalogue is being stocked. Message us on WhatsApp for current availability and prices."
						}) : filteredProducts.length === 0 && /* @__PURE__ */ jsxs("div", {
							className: "py-12 text-center",
							children: [/* @__PURE__ */ jsx("p", {
								className: "text-lg text-gray-500",
								children: "No products match your search."
							}), /* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: clearFilters,
								className: "mt-3 font-semibold text-brand-charcoal underline",
								children: "Clear filters"
							})]
						}),
						pageProducts.length > 0 && /* @__PURE__ */ jsx("div", {
							className: "[container-type:inline-size]",
							children: /* @__PURE__ */ jsx("div", {
								className: "grid grid-flow-dense grid-cols-3 gap-3 auto-rows-[calc((100cqw-1.5rem)/3)] md:grid-cols-6 md:gap-4 md:auto-rows-[calc((100cqw-5rem)/6)]",
								"aria-label": "Product gallery",
								children: pageProducts.map((product, index) => renderGalleryTile(product, tiers[index]))
							})
						}),
						totalPages > 1 && /* @__PURE__ */ jsxs("nav", {
							"aria-label": "Product pages",
							className: "flex items-center justify-center gap-4 mt-10",
							children: [
								/* @__PURE__ */ jsxs("button", {
									type: "button",
									onClick: () => setCurrentPage((page) => Math.max(1, page - 1)),
									disabled: currentPage === 1,
									className: "inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-300 text-brand-charcoal disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100",
									children: [/* @__PURE__ */ jsx(ChevronLeft, { size: 18 }), " Previous"]
								}),
								/* @__PURE__ */ jsxs("span", {
									className: "text-sm text-gray-600",
									"aria-live": "polite",
									children: [
										"Page ",
										currentPage,
										" of ",
										totalPages
									]
								}),
								/* @__PURE__ */ jsxs("button", {
									type: "button",
									onClick: () => setCurrentPage((page) => Math.min(totalPages, page + 1)),
									disabled: currentPage === totalPages,
									className: "inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-300 text-brand-charcoal disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-100",
									children: ["Next ", /* @__PURE__ */ jsx(ChevronRight, { size: 18 })]
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-16 bg-slate-50 border-t border-slate-200",
				children: /* @__PURE__ */ jsxs("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center",
					children: [
						/* @__PURE__ */ jsx("h2", {
							className: "text-3xl font-bold text-brand-charcoal mb-4",
							children: "Not sure what fits your setup?"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-gray-600 mb-8 max-w-2xl mx-auto",
							children: "Tell us how you will use it and our team will recommend the right product and confirm availability."
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-col sm:flex-row gap-4 justify-center",
							children: [/* @__PURE__ */ jsxs("a", {
								href: whatsappUrl,
								className: "bg-green-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-green-700 transition-colors inline-flex items-center justify-center space-x-2",
								children: [/* @__PURE__ */ jsx("span", { children: "💬" }), /* @__PURE__ */ jsx("span", { children: "Chat on WhatsApp" })]
							}), /* @__PURE__ */ jsx("a", {
								href: "/contact",
								className: "bg-brand-yellow text-brand-charcoal px-8 py-4 rounded-full font-bold text-lg hover:bg-brand-orange transition-colors inline-flex items-center justify-center",
								children: "Contact Us"
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/pages/Contact.jsx
function Contact() {
	const { contact, hours, whatsappUrl } = useSiteSettings();
	const [formData, setFormData] = useState({
		name: "",
		phone: "",
		product: "",
		budget: "",
		message: ""
	});
	const handleSubmit = (e) => {
		e.preventDefault();
		const whatsappMessage = `Hi, I'm interested in your products.\n\nName: ${formData.name}\nPhone: ${formData.phone}\nProduct: ${formData.product}\nBudget Range: ${formData.budget}\nMessage: ${formData.message}`;
		recordMessage(formData);
		trackWhatsApp({
			label: "Contact form",
			message: whatsappMessage
		});
		window.open(whatsappMessageUrl(whatsappMessage), "_blank");
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen bg-gray-50",
		children: [
			/* @__PURE__ */ jsx(PageHeader, {
				eyebrow: "Contact",
				title: "Let's talk",
				accent: "tech",
				intro: "Questions, quotes or technical help: reach the JOJO team on WhatsApp, by phone or in person."
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-16 bg-white",
				children: /* @__PURE__ */ jsx("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "grid grid-cols-1 lg:grid-cols-2 gap-12 items-start",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "rounded-2xl bg-white p-8 ring-1 ring-slate-200",
							children: [
								/* @__PURE__ */ jsx("h2", {
									className: "text-3xl font-bold text-brand-charcoal mb-8",
									children: "Reach us"
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "space-y-6",
									children: [
										/* @__PURE__ */ jsxs("div", {
											className: "flex items-start space-x-4",
											children: [/* @__PURE__ */ jsx("div", {
												className: "bg-brand-yellow p-3 rounded-lg",
												children: /* @__PURE__ */ jsx(MapPin, {
													size: 24,
													className: "text-brand-charcoal"
												})
											}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
												className: "font-semibold text-brand-charcoal mb-1",
												children: "Our Location"
											}), /* @__PURE__ */ jsx("p", {
												className: "whitespace-pre-line text-gray-600",
												children: contact.address
											})] })]
										}),
										/* @__PURE__ */ jsxs("div", {
											className: "flex items-start space-x-4",
											children: [/* @__PURE__ */ jsx("div", {
												className: "bg-brand-yellow p-3 rounded-lg",
												children: /* @__PURE__ */ jsx(Phone, {
													size: 24,
													className: "text-brand-charcoal"
												})
											}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
												className: "font-semibold text-brand-charcoal mb-1",
												children: "Phone & WhatsApp"
											}), [contact.mobilePhone, contact.officePhone].filter(Boolean).map((phone) => /* @__PURE__ */ jsx("p", {
												className: "text-gray-600",
												children: /* @__PURE__ */ jsx("a", {
													href: telHref(phone),
													className: "hover:text-brand-ember transition-colors",
													children: phone
												})
											}, phone))] })]
										}),
										/* @__PURE__ */ jsxs("div", {
											className: "flex items-start space-x-4",
											children: [/* @__PURE__ */ jsx("div", {
												className: "bg-brand-yellow p-3 rounded-lg",
												children: /* @__PURE__ */ jsx(Mail, {
													size: 24,
													className: "text-brand-charcoal"
												})
											}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
												className: "font-semibold text-brand-charcoal mb-1",
												children: "Email"
											}), [contact.email, contact.email2].filter(Boolean).map((email) => /* @__PURE__ */ jsx("p", {
												className: "text-gray-600",
												children: /* @__PURE__ */ jsx("a", {
													href: `mailto:${email}`,
													className: "hover:text-brand-ember transition-colors",
													children: email
												})
											}, email))] })]
										}),
										/* @__PURE__ */ jsxs("div", {
											className: "flex items-start space-x-4",
											children: [/* @__PURE__ */ jsx("div", {
												className: "bg-brand-yellow p-3 rounded-lg",
												children: /* @__PURE__ */ jsx(Clock, {
													size: 24,
													className: "text-brand-charcoal"
												})
											}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
												className: "font-semibold text-brand-charcoal mb-1",
												children: "Opening Hours"
											}), /* @__PURE__ */ jsx("p", {
												className: "text-gray-600",
												children: hours.map(({ days, time }) => /* @__PURE__ */ jsxs("span", {
													className: "block",
													children: [
														days,
														": ",
														time
													]
												}, days))
											})] })]
										})
									]
								}),
								/* @__PURE__ */ jsx("div", {
									className: "mt-8",
									children: /* @__PURE__ */ jsxs("a", {
										href: whatsappUrl,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "inline-flex items-center space-x-3 bg-green-600 text-white px-6 py-4 rounded-full font-bold hover:bg-green-700 transition-colors",
										children: [/* @__PURE__ */ jsx("span", {
											className: "text-2xl",
											children: "💬"
										}), /* @__PURE__ */ jsx("span", { children: "Chat on WhatsApp" })]
									})
								})
							]
						}), /* @__PURE__ */ jsx("div", {
							className: "w-full",
							children: /* @__PURE__ */ jsxs("div", {
								className: "bg-white rounded-2xl p-8 ring-1 ring-slate-200",
								children: [
									/* @__PURE__ */ jsx("h2", {
										className: "text-3xl font-bold text-brand-charcoal mb-2",
										children: "Send Us a Message"
									}),
									/* @__PURE__ */ jsx("p", {
										className: "text-gray-600 mb-8",
										children: "Fill out the form below and we'll get back to you via WhatsApp"
									}),
									/* @__PURE__ */ jsxs("form", {
										onSubmit: handleSubmit,
										className: "space-y-6",
										children: [
											/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("label", {
												htmlFor: "name",
												className: "block text-sm font-medium text-gray-700 mb-2",
												children: "Full Name *"
											}), /* @__PURE__ */ jsx("input", {
												type: "text",
												id: "name",
												required: true,
												value: formData.name,
												onChange: (e) => setFormData({
													...formData,
													name: e.target.value
												}),
												className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-yellow focus:border-transparent",
												placeholder: "Enter your full name"
											})] }),
											/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("label", {
												htmlFor: "phone",
												className: "block text-sm font-medium text-gray-700 mb-2",
												children: "Phone Number *"
											}), /* @__PURE__ */ jsx("input", {
												type: "tel",
												id: "phone",
												required: true,
												value: formData.phone,
												onChange: (e) => setFormData({
													...formData,
													phone: e.target.value
												}),
												className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-yellow focus:border-transparent",
												placeholder: "+254 7XX XXX XXX"
											})] }),
											/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("label", {
												htmlFor: "product",
												className: "block text-sm font-medium text-gray-700 mb-2",
												children: "Product Inquiry"
											}), /* @__PURE__ */ jsx("input", {
												type: "text",
												id: "product",
												value: formData.product,
												onChange: (e) => setFormData({
													...formData,
													product: e.target.value
												}),
												className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-yellow focus:border-transparent",
												placeholder: "e.g., laptop, CCTV kit, Wi-Fi router"
											})] }),
											/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("label", {
												htmlFor: "budget",
												className: "block text-sm font-medium text-gray-700 mb-2",
												children: "Budget Range"
											}), /* @__PURE__ */ jsxs("select", {
												id: "budget",
												value: formData.budget,
												onChange: (e) => setFormData({
													...formData,
													budget: e.target.value
												}),
												className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-yellow focus:border-transparent",
												children: [
													/* @__PURE__ */ jsx("option", {
														value: "",
														children: "Select budget range"
													}),
													/* @__PURE__ */ jsx("option", {
														value: "Under KSh 10,000",
														children: "Under KSh 10,000"
													}),
													/* @__PURE__ */ jsx("option", {
														value: "KSh 10,000 - KSh 50,000",
														children: "KSh 10,000 - KSh 50,000"
													}),
													/* @__PURE__ */ jsx("option", {
														value: "KSh 50,000 - KSh 100,000",
														children: "KSh 50,000 - KSh 100,000"
													}),
													/* @__PURE__ */ jsx("option", {
														value: "KSh 100,000 - KSh 500,000",
														children: "KSh 100,000 - KSh 500,000"
													}),
													/* @__PURE__ */ jsx("option", {
														value: "Over KSh 500,000",
														children: "Over KSh 500,000"
													})
												]
											})] }),
											/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("label", {
												htmlFor: "message",
												className: "block text-sm font-medium text-gray-700 mb-2",
												children: "Message"
											}), /* @__PURE__ */ jsx("textarea", {
												id: "message",
												rows: "4",
												value: formData.message,
												onChange: (e) => setFormData({
													...formData,
													message: e.target.value
												}),
												className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-yellow focus:border-transparent",
												placeholder: "Tell us more about your requirements..."
											})] }),
											/* @__PURE__ */ jsxs("button", {
												type: "submit",
												className: "w-full bg-green-600 text-white py-4 rounded-full font-bold text-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2",
												children: [/* @__PURE__ */ jsx(Send, { size: 20 }), /* @__PURE__ */ jsx("span", { children: "Send via WhatsApp" })]
											})
										]
									})
								]
							})
						})]
					})
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "pb-16 bg-white",
				children: /* @__PURE__ */ jsxs("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "text-3xl font-bold text-brand-charcoal mb-6",
						children: "Find Our Store"
					}), /* @__PURE__ */ jsx("div", {
						className: "bg-gray-200 rounded-xl overflow-hidden h-[28rem]",
						children: /* @__PURE__ */ jsx("iframe", {
							src: "https://www.google.com/maps?q=Moi%20Avenue%2C%20Nairobi%2C%20Kenya&z=16&output=embed",
							width: "100%",
							height: "100%",
							style: { border: 0 },
							allowFullScreen: "",
							loading: "lazy",
							referrerPolicy: "no-referrer-when-downgrade",
							title: "JOJO Tech Solutions Ltd Location"
						})
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/useOrdering.js
var productLink = (product) => `Product page: ${canonicalUrl(productPath(product))}`;
var productFacts = (product) => `Brand: ${product.brand}\nSpecs: ${product.specs}`;
function useOrdering() {
	const [checkoutProduct, setCheckoutProduct] = useState(null);
	const sendOrder = ({ extra, offerIds, quantity = 1, address = "" }) => {
		const product = checkoutProduct;
		const message = [
			`Hi, I'm interested in the ${product.name}.`,
			productFacts(product),
			extra,
			"Please confirm the current price, availability, and delivery or pickup.",
			productLink(product)
		].filter(Boolean).join("\n\n");
		trackWhatsApp({
			label: "Order via WhatsApp",
			productId: product.id,
			message
		});
		recordOrder({
			productId: product.id,
			productName: product.name,
			message,
			offerIds,
			quantity,
			deliveryAddress: address
		});
		window.open(whatsappMessageUrl(message), "_blank");
		setCheckoutProduct(null);
	};
	const requestQuote = (product) => {
		const message = [
			`Hi, I need an expert quote for the ${product.name}.`,
			productFacts(product),
			"Quantity needed: \nDelivery address: ",
			"I would like guidance on specifications and bulk pricing options.",
			productLink(product)
		].join("\n\n");
		trackWhatsApp({
			label: "Expert quote",
			productId: product.id,
			message
		});
		window.open(whatsappMessageUrl(message), "_blank");
	};
	return {
		checkoutProduct,
		startOrder: setCheckoutProduct,
		closeCheckout: () => setCheckoutProduct(null),
		sendOrder,
		requestQuote
	};
}
//#endregion
//#region src/components/AddToCartButton.jsx
function AddToCartButton({ product, variant = "icon" }) {
	const { add } = useCart();
	if (variant === "full") return /* @__PURE__ */ jsxs("button", {
		type: "button",
		onClick: () => add(product),
		className: "flex min-w-[13rem] flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-full border-2 border-brand-charcoal px-6 py-3 font-semibold text-brand-charcoal transition-colors hover:bg-brand-charcoal hover:text-white",
		children: [/* @__PURE__ */ jsx(ShoppingCart, {
			size: 20,
			"aria-hidden": "true"
		}), " Add to cart"]
	});
	return /* @__PURE__ */ jsx("button", {
		type: "button",
		onClick: () => add(product),
		"aria-label": `Add ${product.name} to cart`,
		title: "Add to cart",
		className: "absolute right-2 top-2 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-white/95 text-brand-charcoal shadow-md ring-1 ring-black/10 transition-colors hover:bg-brand-yellow",
		children: /* @__PURE__ */ jsx(ShoppingCart, {
			size: 18,
			"aria-hidden": "true"
		})
	});
}
//#endregion
//#region src/components/FreeGiftBadge.jsx
function FreeGiftBadge({ gift, inline = false }) {
	if (!gift) return null;
	return /* @__PURE__ */ jsxs("span", {
		className: `${inline ? "inline-flex" : "pointer-events-none absolute bottom-2 left-2 inline-flex max-w-[calc(100%-1rem)]"} items-center gap-1 rounded-full bg-red-600 px-2.5 py-1 text-xs font-bold text-white shadow`,
		children: [/* @__PURE__ */ jsx(Gift, {
			size: 13,
			className: "shrink-0",
			"aria-hidden": "true"
		}), /* @__PURE__ */ jsxs("span", {
			className: "truncate",
			children: ["FREE ", gift]
		})]
	});
}
//#endregion
//#region src/components/ConditionTag.jsx
var TONES = {
	new: "bg-green-100 text-green-800",
	refurbished: "bg-blue-100 text-blue-800",
	used: "bg-amber-100 text-amber-800"
};
function ConditionTag({ condition }) {
	if (!condition) return null;
	const key = Object.keys(TONES).find((k) => condition.toLowerCase().includes(k));
	return /* @__PURE__ */ jsx("span", {
		className: `whitespace-nowrap rounded px-1.5 py-0.5 text-[0.7rem] font-semibold normal-case tracking-normal ${TONES[key] || "bg-gray-100 text-gray-700"}`,
		children: condition
	});
}
//#endregion
//#region src/components/HotFeature.jsx
function HotFeature({ feature, className = "" }) {
	if (!feature) return null;
	return /* @__PURE__ */ jsxs("p", {
		className: `flex items-start gap-1.5 text-sm font-semibold text-brand-ember ${className}`,
		children: [/* @__PURE__ */ jsx(Zap, {
			size: 14,
			className: "mt-0.5 shrink-0 fill-current",
			"aria-hidden": "true"
		}), /* @__PURE__ */ jsx("span", {
			className: "line-clamp-2",
			children: feature
		})]
	});
}
//#endregion
//#region src/components/ShopHighlights.jsx
var TABS$1 = [
	{
		key: "hot",
		label: "Hot products",
		icon: Flame,
		badge: "Hot",
		badgeClass: "bg-red-600 text-white"
	},
	{
		key: "bestSellers",
		label: "Best sellers",
		icon: Trophy,
		badge: "Best seller",
		badgeClass: "bg-brand-yellow text-brand-charcoal"
	},
	{
		key: "mostClicked",
		label: "Most clicked",
		icon: MousePointerClick,
		badge: "Popular",
		badgeClass: "bg-brand-charcoal text-white"
	}
];
function ShopHighlights({ products, highlights, onOrder, onOpen }) {
	const byId = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);
	const lists = useMemo(() => Object.fromEntries(TABS$1.map((t) => [t.key, (highlights[t.key] || []).map((id) => byId.get(id)).filter(Boolean)])), [byId, highlights]);
	const available = TABS$1.filter((t) => lists[t.key].length > 0);
	const [chosen, setChosen] = useState(null);
	if (available.length === 0) return null;
	const active = available.find((t) => t.key === chosen) || available[0];
	const items = lists[active.key];
	return /* @__PURE__ */ jsx("section", {
		className: "mt-6 border-y border-gray-200 bg-white",
		"aria-label": "Shop highlights",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",
			children: [/* @__PURE__ */ jsx("div", {
				className: "no-scrollbar mb-5 flex gap-2 overflow-x-auto",
				role: "tablist",
				"aria-label": "Highlight lists",
				children: available.map(({ key, label, icon: Icon }) => /* @__PURE__ */ jsxs("button", {
					type: "button",
					role: "tab",
					"aria-selected": active.key === key,
					onClick: () => setChosen(key),
					className: `inline-flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${active.key === key ? "bg-brand-charcoal text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
					children: [
						/* @__PURE__ */ jsx(Icon, {
							size: 16,
							"aria-hidden": "true"
						}),
						" ",
						label
					]
				}, key))
			}), /* @__PURE__ */ jsx("ul", {
				className: "no-scrollbar flex flex-col gap-4 sm:snap-x sm:flex-row sm:overflow-x-auto sm:pb-3",
				role: "tabpanel",
				children: items.map((product) => /* @__PURE__ */ jsxs("li", {
					className: "w-full overflow-hidden rounded-xl border border-gray-200 bg-white shadow-md sm:w-80 sm:shrink-0 sm:snap-start lg:w-96",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ jsx(ProductImage, {
								src: product.image,
								alt: product.name,
								onOpen: () => onOpen(product)
							}),
							/* @__PURE__ */ jsx(AddToCartButton, { product }),
							/* @__PURE__ */ jsx(FreeGiftBadge, { gift: product.freeGift }),
							/* @__PURE__ */ jsx("span", {
								className: `pointer-events-none absolute left-2 top-2 rounded-full px-2.5 py-1 text-xs font-bold shadow ${active.badgeClass}`,
								children: active.badge
							})
						]
					}), /* @__PURE__ */ jsxs("div", {
						className: "space-y-2 p-4",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ jsx("p", {
									className: "text-xs font-semibold uppercase text-gray-500",
									children: product.brand
								}), /* @__PURE__ */ jsx(ConditionTag, { condition: product.condition })]
							}),
							/* @__PURE__ */ jsx("p", {
								className: "line-clamp-2 min-h-[3rem] text-lg font-semibold text-brand-charcoal",
								children: /* @__PURE__ */ jsx(SiteLink, {
									to: productPath(product),
									className: "hover:underline",
									children: product.name
								})
							}),
							/* @__PURE__ */ jsx(HotFeature, { feature: product.hotFeature }),
							/* @__PURE__ */ jsxs("p", {
								className: "text-base text-gray-600",
								children: [product.price && Number(product.oldPrice) > Number(product.price) && /* @__PURE__ */ jsxs("span", {
									className: "mr-2 text-sm text-gray-400 line-through",
									children: ["KES ", Number(product.oldPrice).toLocaleString()]
								}), product.price ? `KES ${Number(product.price).toLocaleString()}` : "Price on request"]
							}),
							/* @__PURE__ */ jsxs("button", {
								type: "button",
								onClick: () => onOrder(product),
								className: "flex w-full items-center justify-center gap-2 rounded-lg bg-green-600 px-2 py-2 text-sm font-semibold text-white hover:bg-green-700",
								children: [/* @__PURE__ */ jsx(MessageCircle, {
									size: 16,
									className: "shrink-0"
								}), " Order"]
							})
						]
					})]
				}, product.id))
			})]
		})
	});
}
//#endregion
//#region src/useHighlights.js
function useHighlights() {
	const [highlights, setHighlights] = useState({
		hot: [],
		bestSellers: [],
		mostClicked: []
	});
	useEffect(() => {
		let cancelled = false;
		api("/products/highlights").then((data) => !cancelled && setHighlights({
			hot: data.hot || [],
			bestSellers: data.bestSellers || [],
			mostClicked: data.mostClicked || []
		})).catch(() => {
			const list = typeof window !== "undefined" && Array.isArray(window.__PRODUCTS__) ? window.__PRODUCTS__ : [];
			if (!cancelled) setHighlights({
				hot: list.filter((p) => p.hot).map((p) => p.id),
				bestSellers: [],
				mostClicked: []
			});
		});
		return () => {
			cancelled = true;
		};
	}, []);
	return highlights;
}
//#endregion
//#region src/components/PriceLine.jsx
function PriceLine({ product, offers }) {
	const deal = bestPriceOffer(offers.filter((o) => o.type === "discount"), product);
	const listed = product.price ? Number(product.price) : null;
	const was = listed && Number(product.oldPrice) > listed ? Number(product.oldPrice) : null;
	let content = "Price and availability on request";
	if (listed && deal?.price != null && deal.price < listed) content = /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsxs("span", {
			className: "text-gray-400 line-through mr-2",
			children: ["KES ", listed.toLocaleString()]
		}),
		/* @__PURE__ */ jsxs("span", {
			className: "font-bold text-brand-charcoal",
			children: ["KES ", Number(deal.price).toLocaleString()]
		}),
		/* @__PURE__ */ jsx("span", {
			className: "ml-2 rounded bg-green-100 px-1.5 py-0.5 text-xs font-semibold text-green-800",
			children: "Member price"
		})
	] });
	else if (listed && was) content = /* @__PURE__ */ jsxs("span", {
		className: "flex flex-wrap items-center gap-x-2 gap-y-1 whitespace-nowrap",
		children: [
			/* @__PURE__ */ jsxs("span", {
				className: "text-gray-400 line-through",
				children: ["KES ", was.toLocaleString()]
			}),
			/* @__PURE__ */ jsxs("span", {
				className: "font-bold text-brand-charcoal",
				children: ["KES ", listed.toLocaleString()]
			}),
			/* @__PURE__ */ jsxs("span", {
				className: "rounded bg-red-100 px-1.5 py-0.5 text-xs font-semibold text-red-700",
				children: ["Save KES ", (was - listed).toLocaleString()]
			})
		]
	});
	else if (listed) content = `KES ${listed.toLocaleString()} · confirm availability`;
	else if (deal) content = `Member discount: ${offerLabel(deal.offer)} (price on request)`;
	return /* @__PURE__ */ jsx("p", {
		className: "text-sm font-medium text-gray-600 mb-4",
		children: content
	});
}
//#endregion
//#region src/components/ShopProductCard.jsx
function ShopProductCard({ product, offers, view, onOrder, onQuote, onOpen }) {
	const isList = view === "list";
	const size = isList ? "px-2 py-2 text-sm" : "px-1 py-2 text-xs @[13rem]:px-2 @[13rem]:text-sm";
	const buttons = /* @__PURE__ */ jsxs("div", {
		className: isList ? "grid grid-cols-2 gap-2 sm:w-44 sm:shrink-0" : "mt-auto grid grid-cols-2 gap-2 pt-2",
		children: [/* @__PURE__ */ jsxs("button", {
			onClick: () => onOrder(product),
			className: `flex w-full items-center justify-center gap-1.5 rounded-lg bg-green-600 font-semibold text-white transition-colors hover:bg-green-700 ${size}`,
			children: [/* @__PURE__ */ jsx(MessageCircle, {
				size: 14,
				className: "shrink-0"
			}), /* @__PURE__ */ jsx("span", { children: "Order" })]
		}), /* @__PURE__ */ jsx("button", {
			onClick: () => onQuote(product),
			className: `w-full rounded-lg bg-brand-yellow font-semibold text-brand-charcoal transition-colors hover:bg-brand-orange ${size}`,
			children: "Get Quote"
		})]
	});
	if (isList) return /* @__PURE__ */ jsxs("div", {
		className: "flex overflow-hidden rounded-xl border-2 border-transparent bg-white shadow-md transition-all hover:border-brand-yellow hover:shadow-xl",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "relative w-28 shrink-0 sm:w-48",
			children: [
				/* @__PURE__ */ jsx(ProductImage, {
					src: product.image,
					alt: product.name,
					onOpen: () => onOpen(product)
				}),
				/* @__PURE__ */ jsx(AddToCartButton, { product }),
				/* @__PURE__ */ jsx(FreeGiftBadge, { gift: product.freeGift })
			]
		}), /* @__PURE__ */ jsxs("div", {
			className: "flex min-w-0 flex-1 flex-col gap-3 p-4 sm:flex-row sm:items-center sm:gap-6 sm:p-5",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-xs font-semibold uppercase text-gray-500",
							children: product.brand
						}), /* @__PURE__ */ jsx(ConditionTag, { condition: product.condition })]
					}),
					/* @__PURE__ */ jsx("h3", {
						className: "mb-1 line-clamp-2 text-base font-semibold text-brand-charcoal sm:text-lg",
						children: /* @__PURE__ */ jsx(SiteLink, {
							to: productPath(product),
							className: "hover:underline",
							children: product.name
						})
					}),
					/* @__PURE__ */ jsx(HotFeature, {
						feature: product.hotFeature,
						className: "mb-1"
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mb-2 line-clamp-1 text-sm text-gray-600 sm:line-clamp-2",
						children: product.specs
					}),
					/* @__PURE__ */ jsx(PriceLine, {
						product,
						offers
					})
				]
			}), buttons]
		})]
	});
	return /* @__PURE__ */ jsxs("div", {
		className: "@container flex flex-col overflow-hidden rounded-xl border-2 border-transparent bg-white shadow-md transition-all hover:border-brand-yellow hover:shadow-xl",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "relative",
			children: [
				/* @__PURE__ */ jsx(ProductImage, {
					src: product.image,
					alt: product.name,
					onOpen: () => onOpen(product)
				}),
				/* @__PURE__ */ jsx(AddToCartButton, { product }),
				/* @__PURE__ */ jsx(FreeGiftBadge, { gift: product.freeGift })
			]
		}), /* @__PURE__ */ jsxs("div", {
			className: "flex flex-1 flex-col p-4 @[17rem]:p-5",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "mb-2 flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ jsx("span", {
						className: "text-xs font-semibold uppercase text-gray-500",
						children: product.brand
					}), /* @__PURE__ */ jsx(ConditionTag, { condition: product.condition })]
				}),
				/* @__PURE__ */ jsx("h3", {
					className: "mb-2 line-clamp-2 text-lg font-semibold text-brand-charcoal",
					children: /* @__PURE__ */ jsx(SiteLink, {
						to: productPath(product),
						className: "hover:underline",
						children: product.name
					})
				}),
				/* @__PURE__ */ jsx(HotFeature, {
					feature: product.hotFeature,
					className: "mb-2"
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mb-3 line-clamp-1 text-sm text-gray-600",
					children: product.specs
				}),
				/* @__PURE__ */ jsx(PriceLine, {
					product,
					offers
				}),
				buttons
			]
		})]
	});
}
//#endregion
//#region src/components/CheckoutModal.jsx
var kes = (n) => `KES ${Number(n).toLocaleString()}`;
function CheckoutModal({ product, offers, onClose, onSend }) {
	const { user } = useAuth();
	const priceOffers = useMemo(() => offers.filter((o) => o.type !== "delivery" && offerApplies(o, product)), [offers, product]);
	const deliveryOffers = useMemo(() => offers.filter((o) => o.type === "delivery" && offerApplies(o, product)), [offers, product]);
	const [priceOfferId, setPriceOfferId] = useState(() => bestPriceOffer(priceOffers, product)?.offer.id ?? null);
	const [deliveryId, setDeliveryId] = useState(null);
	const [code, setCode] = useState("");
	const [codeMessage, setCodeMessage] = useState({
		ok: true,
		text: ""
	});
	const [quantityText, setQuantityText] = useState("1");
	const [address, setAddress] = useState("");
	useEffect(() => {
		const onKey = (e) => e.key === "Escape" && onClose();
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [onClose]);
	const chosenPrice = priceOffers.find((o) => o.id === priceOfferId) || null;
	const chosenDelivery = deliveryOffers.find((o) => o.id === deliveryId) || null;
	const finalPrice = chosenPrice && product.price != null ? priceAfter(chosenPrice, product.price) : null;
	const quantity = Math.min(9999, Math.max(1, Math.floor(Number(quantityText)) || 1));
	const unitPrice = finalPrice ?? product.price;
	const total = unitPrice != null ? Math.round(unitPrice * quantity * 100) / 100 : null;
	const applyCode = () => {
		const wanted = code.trim().toUpperCase();
		if (!wanted) return;
		const match = offers.find((o) => o.type === "coupon" && o.code === wanted);
		if (!match) setCodeMessage({
			ok: false,
			text: "That code is not recognised."
		});
		else if (!offerApplies(match, product)) setCodeMessage({
			ok: false,
			text: "That coupon does not apply to this product."
		});
		else {
			setPriceOfferId(match.id);
			setCodeMessage({
				ok: true,
				text: `Coupon ${match.code} applied.`
			});
		}
	};
	const send = () => {
		const lines = [];
		lines.push(`Quantity needed: ${quantity}`);
		lines.push(`Delivery address: ${address.trim() || "to be confirmed on WhatsApp"}`);
		if (user) lines.push(`Member: ${user.name || user.username} (${user.username})${user.phone ? `, ${user.phone}` : ""}`);
		if (chosenPrice) {
			const label = offerLabel(chosenPrice);
			const showLabel = label && !chosenPrice.title.toLowerCase().includes(label.toLowerCase());
			lines.push(`${chosenPrice.type === "coupon" ? `Coupon ${chosenPrice.code}` : "Member discount"}: ${chosenPrice.title}${showLabel ? ` (${label})` : ""}`);
			if (finalPrice != null) lines.push(`Price after offer: ${kes(finalPrice)} each (listed ${kes(product.price)})`);
		}
		if (quantity > 1 && total != null) lines.push(`Estimated total for ${quantity}: ${kes(total)}`);
		if (chosenDelivery) lines.push(`Delivery offer: ${chosenDelivery.title}`);
		onSend({
			extra: lines.join("\n"),
			offerIds: [chosenPrice?.id, chosenDelivery?.id].filter(Boolean),
			quantity,
			address: address.trim()
		});
	};
	const radio = "mt-0.5 shrink-0 accent-[#013d83]";
	return /* @__PURE__ */ jsx("div", {
		className: "fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto bg-black/60 p-4",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Before you order",
		children: /* @__PURE__ */ jsxs("div", {
			className: "my-8 w-full max-w-lg rounded-2xl bg-white shadow-2xl",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center justify-between border-b border-gray-200 px-6 py-4",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "text-lg font-bold text-brand-charcoal",
						children: "Before you order"
					}), /* @__PURE__ */ jsx("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "Close",
						className: "rounded-full p-2 text-gray-500 hover:bg-gray-100",
						children: /* @__PURE__ */ jsx(X, { size: 18 })
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-5 px-6 py-5",
					children: [
						/* @__PURE__ */ jsxs("div", { children: [
							/* @__PURE__ */ jsx("p", {
								className: "font-semibold text-brand-charcoal",
								children: product.name
							}),
							/* @__PURE__ */ jsx("p", {
								className: "text-sm text-gray-600",
								children: product.brand
							}),
							/* @__PURE__ */ jsxs("p", {
								className: "mt-1 text-sm",
								children: [product.price != null ? /* @__PURE__ */ jsxs(Fragment, { children: [finalPrice != null && finalPrice !== product.price && /* @__PURE__ */ jsx("span", {
									className: "mr-2 text-gray-400 line-through",
									children: kes(product.price)
								}), /* @__PURE__ */ jsx("span", {
									className: "font-bold text-brand-charcoal",
									children: kes(finalPrice ?? product.price)
								})] }) : /* @__PURE__ */ jsx("span", {
									className: "text-gray-600",
									children: "Price confirmed on WhatsApp"
								}), product.price != null && quantity > 1 && /* @__PURE__ */ jsxs("span", {
									className: "ml-2 text-gray-600",
									children: [
										"× ",
										quantity,
										" = ",
										/* @__PURE__ */ jsx("strong", {
											className: "text-brand-charcoal",
											children: kes(total)
										})
									]
								})]
							})
						] }),
						/* @__PURE__ */ jsxs("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [/* @__PURE__ */ jsxs("label", {
								className: "text-sm font-medium text-gray-700",
								children: ["Quantity needed", /* @__PURE__ */ jsx("input", {
									type: "number",
									inputMode: "numeric",
									min: "1",
									max: "9999",
									step: "1",
									value: quantityText,
									onChange: (e) => setQuantityText(e.target.value),
									onBlur: () => setQuantityText(String(quantity)),
									className: "mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-transparent focus:ring-2 focus:ring-brand-yellow"
								})]
							}), /* @__PURE__ */ jsxs("label", {
								className: "text-sm font-medium text-gray-700 sm:col-span-2",
								children: [
									"Delivery address ",
									/* @__PURE__ */ jsx("span", {
										className: "font-normal text-gray-500",
										children: "(optional)"
									}),
									/* @__PURE__ */ jsx("textarea", {
										rows: 2,
										maxLength: 300,
										value: address,
										onChange: (e) => setAddress(e.target.value),
										placeholder: "Area, street or building. Leave blank to confirm on WhatsApp.",
										className: "mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-transparent focus:ring-2 focus:ring-brand-yellow"
									})
								]
							})]
						}),
						!user && /* @__PURE__ */ jsxs("div", {
							className: "rounded-xl border border-brand-yellow bg-yellow-50 p-4",
							children: [
								/* @__PURE__ */ jsx("p", {
									className: "font-semibold text-brand-charcoal",
									children: "Members get discounts, coupons and delivery offers"
								}),
								/* @__PURE__ */ jsx("p", {
									className: "mt-1 text-sm text-gray-700",
									children: "Create a free account or sign in to unlock them before you send your order."
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "mt-3 flex flex-wrap gap-2",
									children: [/* @__PURE__ */ jsx(Link, {
										to: "/signup",
										state: { from: "/shop" },
										className: "rounded-full bg-brand-yellow px-4 py-2 text-sm font-bold text-brand-charcoal hover:bg-brand-orange",
										children: "Create account"
									}), /* @__PURE__ */ jsx(Link, {
										to: "/login",
										state: { from: "/shop" },
										className: "rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium hover:bg-gray-100",
										children: "Log in"
									})]
								})
							]
						}),
						user && priceOffers.length > 0 && /* @__PURE__ */ jsxs("fieldset", { children: [
							/* @__PURE__ */ jsxs("legend", {
								className: "mb-2 flex items-center gap-2 text-sm font-semibold text-brand-charcoal",
								children: [
									/* @__PURE__ */ jsx(BadgePercent, { size: 16 }),
									" Discount or coupon ",
									/* @__PURE__ */ jsx("span", {
										className: "font-normal text-gray-500",
										children: "(best one applies; they don’t stack)"
									})
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [priceOffers.map((o) => /* @__PURE__ */ jsxs("label", {
									className: "flex cursor-pointer items-start gap-3 rounded-lg border border-gray-200 p-3 text-sm hover:border-brand-yellow",
									children: [/* @__PURE__ */ jsx("input", {
										type: "radio",
										name: "price-offer",
										className: radio,
										checked: priceOfferId === o.id,
										onChange: () => setPriceOfferId(o.id)
									}), /* @__PURE__ */ jsxs("span", { children: [
										/* @__PURE__ */ jsx("span", {
											className: "font-medium",
											children: o.title
										}),
										o.type === "coupon" && /* @__PURE__ */ jsx("span", {
											className: "ml-2 rounded bg-gray-100 px-1.5 py-0.5 font-mono text-xs",
											children: o.code
										}),
										/* @__PURE__ */ jsxs("span", {
											className: "block text-gray-600",
											children: [offerLabel(o), o.description ? ` · ${o.description}` : ""]
										})
									] })]
								}, o.id)), /* @__PURE__ */ jsxs("label", {
									className: "flex cursor-pointer items-center gap-3 rounded-lg border border-gray-200 p-3 text-sm hover:border-brand-yellow",
									children: [/* @__PURE__ */ jsx("input", {
										type: "radio",
										name: "price-offer",
										className: radio,
										checked: priceOfferId === null,
										onChange: () => setPriceOfferId(null)
									}), "No discount"]
								})]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-3 flex gap-2",
								children: [/* @__PURE__ */ jsxs("div", {
									className: "relative flex-1",
									children: [/* @__PURE__ */ jsx(Ticket, {
										size: 16,
										className: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
									}), /* @__PURE__ */ jsx("input", {
										value: code,
										onChange: (e) => setCode(e.target.value),
										onKeyDown: (e) => e.key === "Enter" && (e.preventDefault(), applyCode()),
										placeholder: "Have a coupon code?",
										"aria-label": "Coupon code",
										className: "w-full rounded-lg border border-gray-300 py-2 pl-9 pr-3 text-sm uppercase placeholder:normal-case focus:border-transparent focus:ring-2 focus:ring-brand-yellow"
									})]
								}), /* @__PURE__ */ jsx("button", {
									type: "button",
									onClick: applyCode,
									className: "rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-100",
									children: "Apply"
								})]
							}),
							codeMessage.text && /* @__PURE__ */ jsx("p", {
								role: "status",
								className: `mt-1 text-xs ${codeMessage.ok ? "text-green-700" : "text-red-700"}`,
								children: codeMessage.text
							})
						] }),
						user && deliveryOffers.length > 0 && /* @__PURE__ */ jsxs("fieldset", { children: [/* @__PURE__ */ jsxs("legend", {
							className: "mb-2 flex items-center gap-2 text-sm font-semibold text-brand-charcoal",
							children: [/* @__PURE__ */ jsx(Truck, { size: 16 }), " Delivery offer"]
						}), /* @__PURE__ */ jsxs("div", {
							className: "space-y-2",
							children: [deliveryOffers.map((o) => /* @__PURE__ */ jsxs("label", {
								className: "flex cursor-pointer items-start gap-3 rounded-lg border border-gray-200 p-3 text-sm hover:border-brand-yellow",
								children: [/* @__PURE__ */ jsx("input", {
									type: "radio",
									name: "delivery-offer",
									className: radio,
									checked: deliveryId === o.id,
									onChange: () => setDeliveryId(o.id)
								}), /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
									className: "font-medium",
									children: o.title
								}), o.description && /* @__PURE__ */ jsx("span", {
									className: "block text-gray-600",
									children: o.description
								})] })]
							}, o.id)), /* @__PURE__ */ jsxs("label", {
								className: "flex cursor-pointer items-center gap-3 rounded-lg border border-gray-200 p-3 text-sm hover:border-brand-yellow",
								children: [/* @__PURE__ */ jsx("input", {
									type: "radio",
									name: "delivery-offer",
									className: radio,
									checked: deliveryId === null,
									onChange: () => setDeliveryId(null)
								}), "No delivery offer"]
							})]
						})] }),
						user && priceOffers.length === 0 && deliveryOffers.length === 0 && /* @__PURE__ */ jsx("p", {
							className: "rounded-lg bg-gray-50 p-3 text-sm text-gray-600",
							children: "No member offers apply to this product right now."
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex flex-col-reverse gap-2 border-t border-gray-200 px-6 py-4 sm:flex-row sm:justify-end",
					children: [/* @__PURE__ */ jsx("button", {
						type: "button",
						onClick: onClose,
						className: "rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-100",
						children: "Cancel"
					}), /* @__PURE__ */ jsxs("button", {
						type: "button",
						onClick: send,
						className: "inline-flex items-center justify-center gap-2 rounded-full bg-green-600 px-5 py-2 text-sm font-semibold text-white hover:bg-green-700",
						children: [
							/* @__PURE__ */ jsx(MessageCircle, { size: 18 }),
							" ",
							user ? "Send order on WhatsApp" : "Continue without offers"
						]
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/pages/Shop.jsx
var VIEW_KEY = "jojo-shop-view";
var COLUMN_CHOICES = [
	1,
	2,
	3,
	4,
	5,
	6
];
var GRID_ROWS_PER_PAGE = 3;
var LIST_PAGE_SIZE = 8;
var DEFAULT_PREFS = {
	view: "grid",
	columns: 5
};
var selectClass = "h-12 w-full cursor-pointer appearance-none rounded-xl border border-gray-200 bg-gray-50 pl-10 pr-8 text-sm font-medium sm:pr-10 sm:text-[15px] text-gray-800 transition-colors hover:border-gray-300 focus:border-brand-charcoal focus:bg-white focus:outline-none focus:ring-4 focus:ring-brand-charcoal/10 md:w-52";
function loadViewPrefs() {
	try {
		const saved = JSON.parse(localStorage.getItem(VIEW_KEY) || "{}");
		return {
			view: saved.view === "list" ? "list" : "grid",
			columns: COLUMN_CHOICES.includes(saved.columns) ? saved.columns : DEFAULT_PREFS.columns
		};
	} catch {
		return DEFAULT_PREFS;
	}
}
function Shop() {
	const allProducts = useProducts();
	const [{ view, columns }, setViewPrefs] = useState(DEFAULT_PREFS);
	useEffect(() => {
		setViewPrefs(loadViewPrefs());
	}, []);
	const updateViewPrefs = (patch) => {
		const next = {
			view,
			columns,
			...patch
		};
		setViewPrefs(next);
		setPage(1);
		try {
			localStorage.setItem(VIEW_KEY, JSON.stringify(next));
		} catch {}
	};
	const gridVars = {
		"--m": 2,
		"--t": columns >= 5 ? 3 : Math.min(columns, 2),
		"--cols": columns
	};
	const { user } = useAuth();
	const offers = useOffers();
	const highlights = useHighlights();
	const { checkoutProduct, startOrder, closeCheckout, sendOrder, requestQuote } = useOrdering();
	const navigate = useNavigate();
	const [selectedBrand, setSelectedBrand] = useState("All");
	const [searchQuery, setSearchQuery] = useState("");
	const [page, setPage] = useState(1);
	const [activeHeroSlide, setActiveHeroSlide] = useState(0);
	const heroSlides = [
		{
			image: "/brands/hp-pavilion.jpg",
			alt: "HP Pavilion laptops in blue, silver and gold"
		},
		{
			image: "/brands/apple-macbook.jpg",
			alt: "Apple MacBook on a black background"
		},
		{
			image: "/brands/microsoft-surface.jpg",
			alt: "Microsoft Surface laptop in black"
		},
		{
			image: "/brands/asus-rog.jpg",
			alt: "ASUS ROG gaming laptop with a red glowing logo"
		}
	];
	useEffect(() => {
		if (heroSlides.length < 2 || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return void 0;
		const timer = setTimeout(() => setActiveHeroSlide((slide) => (slide + 1) % heroSlides.length), 6e3);
		return () => clearTimeout(timer);
	}, [activeHeroSlide, heroSlides.length]);
	const products = allProducts.filter((product) => product.inShop !== false);
	const categoryGroups = groupCategories(allProducts);
	const brands = ["All", ...new Set(products.map((product) => product.brand))];
	const filteredProducts = products.filter((product) => {
		const matchesBrand = selectedBrand === "All" || product.brand === selectedBrand;
		const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || product.brand.toLowerCase().includes(searchQuery.toLowerCase());
		return matchesBrand && matchesSearch;
	});
	const pageSize = view === "list" ? LIST_PAGE_SIZE : GRID_ROWS_PER_PAGE * columns;
	const totalPages = Math.max(1, Math.ceil(filteredProducts.length / pageSize));
	const currentPage = Math.min(page, totalPages);
	const pageProducts = filteredProducts.slice((currentPage - 1) * pageSize, currentPage * pageSize);
	const goToPage = (next) => {
		setPage(next);
		document.getElementById("shop-products")?.scrollIntoView({ block: "start" });
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen bg-gray-50",
		children: [
			/* @__PURE__ */ jsxs("section", {
				className: "bg-slate-50 py-6 md:py-10",
				"aria-label": "Shop online carousel",
				"aria-roledescription": "carousel",
				children: [
					/* @__PURE__ */ jsx("h1", {
						className: "sr-only",
						children: "Shop Online"
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: [
							/* @__PURE__ */ jsx("img", {
								src: heroSlides[activeHeroSlide].image,
								alt: heroSlides[activeHeroSlide].alt,
								className: "mx-auto block aspect-[16/9] max-h-[480px] w-full rounded-3xl object-cover shadow-lg ring-1 ring-slate-200"
							}, heroSlides[activeHeroSlide].image),
							/* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: () => setActiveHeroSlide((slide) => (slide - 1 + heroSlides.length) % heroSlides.length),
								"aria-label": "Show previous shop banner",
								className: "absolute left-7 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-brand-charcoal/80 text-white transition-colors hover:bg-brand-yellow hover:text-brand-charcoal sm:left-10",
								children: /* @__PURE__ */ jsx(ChevronLeft, { size: 24 })
							}),
							/* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: () => setActiveHeroSlide((slide) => (slide + 1) % heroSlides.length),
								"aria-label": "Show next shop banner",
								className: "absolute right-7 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-brand-charcoal/80 text-white transition-colors hover:bg-brand-yellow hover:text-brand-charcoal sm:right-10",
								children: /* @__PURE__ */ jsx(ChevronRight, { size: 24 })
							})
						]
					}),
					/* @__PURE__ */ jsx("div", {
						className: "flex justify-center gap-2 py-3",
						"aria-label": "Choose shop banner",
						children: heroSlides.map((slide, index) => /* @__PURE__ */ jsx("button", {
							type: "button",
							onClick: () => setActiveHeroSlide(index),
							"aria-label": `Show shop banner ${index + 1}`,
							"aria-current": activeHeroSlide === index ? "true" : void 0,
							className: `h-2.5 rounded-full transition-all ${activeHeroSlide === index ? "w-8 bg-brand-yellow" : "w-2.5 bg-gray-300 hover:bg-gray-400"}`
						}, slide.image))
					}),
					/* @__PURE__ */ jsx("p", {
						className: "sr-only",
						children: "Browse our catalog and ask our team to confirm current pricing and availability. WhatsApp product enquiries."
					})
				]
			}),
			/* @__PURE__ */ jsx("section", {
				className: "border-b border-gray-200 bg-white/95 backdrop-blur lg:sticky lg:top-20 lg:z-40",
				children: /* @__PURE__ */ jsx("div", {
					className: "mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "flex flex-col gap-3 md:flex-row md:items-center",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "relative flex-1",
							children: [
								/* @__PURE__ */ jsx(Search, {
									className: "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-gray-400",
									size: 20,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx("input", {
									type: "search",
									placeholder: "Search products or brands...",
									"aria-label": "Search products or brands",
									value: searchQuery,
									onChange: (e) => {
										setSearchQuery(e.target.value);
										setPage(1);
									},
									className: "h-12 w-full rounded-xl border border-gray-200 bg-gray-50 pl-12 pr-11 text-[15px] text-gray-900 placeholder:text-gray-400 transition-colors focus:border-brand-charcoal focus:bg-white focus:outline-none focus:ring-4 focus:ring-brand-charcoal/10 [&::-webkit-search-cancel-button]:hidden"
								}),
								searchQuery && /* @__PURE__ */ jsx("button", {
									type: "button",
									onClick: () => {
										setSearchQuery("");
										setPage(1);
									},
									"aria-label": "Clear search",
									className: "absolute right-3 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-gray-500 hover:bg-gray-200 hover:text-gray-800",
									children: /* @__PURE__ */ jsx(X, { size: 16 })
								})
							]
						}), /* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-2 gap-3 md:flex",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ jsx(LayoutGrid, {
										className: "pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-brand-charcoal",
										size: 18,
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ jsxs("select", {
										value: "",
										onChange: (e) => e.target.value && navigate(e.target.value),
										"aria-label": "Go to a category page",
										title: "Opens the category page",
										className: selectClass,
										children: [/* @__PURE__ */ jsx("option", {
											value: "",
											children: "All categories"
										}), categoryGroups.map((group) => /* @__PURE__ */ jsx("option", {
											value: categoryPath(group.name),
											children: group.name
										}, group.slug))]
									}),
									/* @__PURE__ */ jsx(ChevronDown, {
										className: "pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-500",
										size: 18,
										"aria-hidden": "true"
									})
								]
							}), /* @__PURE__ */ jsxs("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ jsx(Tag, {
										className: "pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-brand-charcoal",
										size: 18,
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ jsx("select", {
										value: selectedBrand,
										onChange: (e) => {
											setSelectedBrand(e.target.value);
											setPage(1);
										},
										"aria-label": "Filter by brand",
										className: selectClass,
										children: brands.map((brand) => /* @__PURE__ */ jsx("option", {
											value: brand,
											children: brand === "All" ? "All brands" : brand
										}, brand))
									}),
									/* @__PURE__ */ jsx(ChevronDown, {
										className: "pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-500",
										size: 18,
										"aria-hidden": "true"
									})
								]
							})]
						})]
					})
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mx-auto max-w-7xl space-y-6 px-4 pt-6 sm:px-6 lg:px-8",
				children: [/* @__PURE__ */ jsxs("section", {
					className: "relative overflow-hidden rounded-2xl bg-gradient-to-r from-brand-black to-brand-charcoal px-5 py-4 text-white shadow-md sm:px-6",
					"aria-label": "Member offers",
					children: [/* @__PURE__ */ jsx("div", {
						className: "pointer-events-none absolute -right-10 -top-12 h-40 w-40 rounded-full bg-brand-yellow/15",
						"aria-hidden": "true"
					}), /* @__PURE__ */ jsxs("div", {
						className: "relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ jsx("span", {
								className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-yellow text-brand-black",
								children: /* @__PURE__ */ jsx(BadgePercent, {
									size: 20,
									"aria-hidden": "true"
								})
							}), user ? /* @__PURE__ */ jsxs("p", {
								className: "text-sm leading-snug sm:text-[15px]",
								children: [
									"Signed in as ",
									/* @__PURE__ */ jsx("strong", {
										className: "font-semibold text-brand-yellow",
										children: user.name || user.username
									}),
									/* @__PURE__ */ jsx("span", {
										className: "block text-white/80",
										children: offers.length > 0 ? `${offers.length} member offer${offers.length === 1 ? "" : "s"} available. Pick yours at checkout.` : "Member offers will appear here when available."
									})
								]
							}) : /* @__PURE__ */ jsxs("p", {
								className: "text-sm leading-snug sm:text-[15px]",
								children: [/* @__PURE__ */ jsx("strong", {
									className: "font-semibold",
									children: "Members save more"
								}), /* @__PURE__ */ jsx("span", {
									className: "block text-white/80",
									children: "Discounts, coupon codes and delivery offers for account holders."
								})]
							})]
						}), !user && /* @__PURE__ */ jsxs("div", {
							className: "flex shrink-0 gap-2",
							children: [/* @__PURE__ */ jsx(SiteLink, {
								to: "/signup",
								state: { from: "/shop" },
								className: "rounded-full bg-brand-yellow px-4 py-2 text-sm font-semibold text-brand-black transition-colors hover:bg-white",
								children: "Create account"
							}), /* @__PURE__ */ jsx(SiteLink, {
								to: "/login",
								state: { from: "/shop" },
								className: "rounded-lg border border-white/40 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-white/10",
								children: "Log in"
							})]
						})]
					})]
				}), categoryGroups.length > 0 && /* @__PURE__ */ jsxs("nav", {
					"aria-label": "Shop by category",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "mb-3 text-xs font-bold uppercase tracking-wider text-gray-500",
						children: "Shop by category"
					}), /* @__PURE__ */ jsx("div", {
						className: "no-scrollbar -mx-4 flex gap-2.5 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0",
						children: categoryGroups.map((group) => /* @__PURE__ */ jsxs(SiteLink, {
							to: categoryPath(group.name),
							className: "group inline-flex shrink-0 items-center gap-2 rounded-full border border-gray-200 bg-white py-2 pl-4 pr-2 text-sm font-medium text-gray-800 shadow-sm transition-all hover:-translate-y-0.5 hover:border-brand-charcoal hover:text-brand-charcoal hover:shadow-md",
							children: [group.name, /* @__PURE__ */ jsx("span", {
								className: "rounded-full bg-gray-100 px-2 py-0.5 text-xs font-semibold text-gray-600 transition-colors group-hover:bg-brand-yellow group-hover:text-brand-black",
								children: group.products.length
							})]
						}, group.slug))
					})]
				})]
			}),
			/* @__PURE__ */ jsx(ShopHighlights, {
				products,
				highlights,
				onOrder: startOrder,
				onOpen: (product) => trackProductClick({
					productId: product.id,
					label: product.name
				})
			}),
			/* @__PURE__ */ jsx("section", {
				id: "shop-products",
				className: "scroll-mt-32 py-12",
				children: /* @__PURE__ */ jsxs("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "mb-8 flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ jsxs("p", {
								className: "text-gray-600",
								children: [
									"Showing ",
									/* @__PURE__ */ jsx("span", {
										className: "font-semibold text-brand-charcoal",
										children: filteredProducts.length
									}),
									" products",
									/* @__PURE__ */ jsx("span", {
										className: "ml-3 hidden text-sm sm:inline",
										children: "Confirm price and availability before visiting"
									})
								]
							}), /* @__PURE__ */ jsxs("div", {
								className: "flex items-center gap-3",
								children: [view === "grid" && /* @__PURE__ */ jsxs("label", {
									className: "hidden items-center gap-2 text-sm text-gray-600 sm:flex",
									children: [/* @__PURE__ */ jsx("span", { children: "Per row" }), /* @__PURE__ */ jsx("select", {
										value: columns,
										onChange: (e) => updateViewPrefs({ columns: Number(e.target.value) }),
										title: "Products per row on large screens. Phones and tablets show fewer.",
										className: "rounded-lg border border-gray-300 bg-white px-2 py-2 text-sm focus:ring-2 focus:ring-brand-yellow focus:border-transparent",
										children: COLUMN_CHOICES.map((n) => /* @__PURE__ */ jsx("option", {
											value: n,
											children: n
										}, n))
									})]
								}), /* @__PURE__ */ jsx("div", {
									className: "inline-flex overflow-hidden rounded-lg border border-gray-300 bg-white",
									role: "group",
									"aria-label": "Product layout",
									children: [{
										id: "grid",
										label: "Grid",
										icon: LayoutGrid
									}, {
										id: "list",
										label: "List",
										icon: List
									}].map(({ id, label, icon: Icon }) => /* @__PURE__ */ jsxs("button", {
										type: "button",
										"aria-pressed": view === id,
										onClick: () => updateViewPrefs({ view: id }),
										className: `inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium transition-colors ${view === id ? "bg-brand-charcoal text-white" : "text-gray-700 hover:bg-gray-100"}`,
										children: [
											/* @__PURE__ */ jsx(Icon, {
												size: 16,
												"aria-hidden": "true"
											}),
											" ",
											label
										]
									}, id))
								})]
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							style: view === "grid" ? gridVars : void 0,
							className: view === "grid" ? "grid gap-4 sm:gap-6 [grid-template-columns:repeat(var(--m),minmax(0,1fr))] sm:[grid-template-columns:repeat(var(--t),minmax(0,1fr))] lg:[grid-template-columns:repeat(var(--cols),minmax(0,1fr))]" : "flex flex-col gap-4",
							children: pageProducts.map((product) => /* @__PURE__ */ jsx(ShopProductCard, {
								product,
								offers,
								view,
								onOrder: startOrder,
								onQuote: requestQuote,
								onOpen: (p) => trackProductClick({
									productId: p.id,
									label: p.name
								})
							}, product.id))
						}),
						totalPages > 1 && /* @__PURE__ */ jsxs("nav", {
							"aria-label": "Product pages",
							className: "mt-10 flex items-center justify-center gap-4",
							children: [
								/* @__PURE__ */ jsxs("button", {
									type: "button",
									onClick: () => goToPage(currentPage - 1),
									disabled: currentPage === 1,
									className: "inline-flex items-center gap-2 rounded-lg border border-gray-300 px-4 py-2 text-brand-charcoal hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-40",
									children: [/* @__PURE__ */ jsx(ChevronLeft, { size: 18 }), " Previous"]
								}),
								/* @__PURE__ */ jsxs("span", {
									className: "text-sm text-gray-600",
									"aria-live": "polite",
									children: [
										"Page ",
										currentPage,
										" of ",
										totalPages
									]
								}),
								/* @__PURE__ */ jsxs("button", {
									type: "button",
									onClick: () => goToPage(currentPage + 1),
									disabled: currentPage === totalPages,
									className: "inline-flex items-center gap-2 rounded-lg border border-gray-300 px-4 py-2 text-brand-charcoal hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-40",
									children: ["Next ", /* @__PURE__ */ jsx(ChevronRight, { size: 18 })]
								})
							]
						}),
						products.length === 0 ? /* @__PURE__ */ jsx(EmptyState, {
							title: "No products added yet",
							text: "The shop is being stocked. Message us on WhatsApp and we'll tell you what's available today."
						}) : filteredProducts.length === 0 && /* @__PURE__ */ jsxs("div", {
							className: "text-center py-16",
							children: [/* @__PURE__ */ jsx("p", {
								className: "text-gray-500 text-lg",
								children: "No products found matching your criteria."
							}), /* @__PURE__ */ jsx("button", {
								onClick: () => {
									setSelectedBrand("All");
									setSearchQuery("");
									setPage(1);
								},
								className: "mt-4 text-brand-ember font-semibold hover:underline",
								children: "Clear all filters"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "py-16 bg-white",
				children: /* @__PURE__ */ jsxs("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsx("h2", {
							className: "text-3xl font-bold text-center text-brand-charcoal mb-12",
							children: "How to Order"
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-1 md:grid-cols-4 gap-8",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "text-center",
									children: [
										/* @__PURE__ */ jsx("div", {
											className: "bg-brand-yellow text-brand-charcoal w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold",
											children: "1"
										}),
										/* @__PURE__ */ jsx("h3", {
											className: "font-semibold text-brand-charcoal mb-2",
											children: "Browse & Search"
										}),
										/* @__PURE__ */ jsx("p", {
											className: "text-gray-600 text-sm",
											children: "Find the right product using our filters and search"
										})
									]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "text-center",
									children: [
										/* @__PURE__ */ jsx("div", {
											className: "bg-brand-yellow text-brand-charcoal w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold",
											children: "2"
										}),
										/* @__PURE__ */ jsx("h3", {
											className: "font-semibold text-brand-charcoal mb-2",
											children: "Add to Cart"
										}),
										/* @__PURE__ */ jsx("p", {
											className: "text-gray-600 text-sm",
											children: "Tap the cart icon on each product you want and set the quantities"
										})
									]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "text-center",
									children: [
										/* @__PURE__ */ jsx("div", {
											className: "bg-brand-yellow text-brand-charcoal w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold",
											children: "3"
										}),
										/* @__PURE__ */ jsx("h3", {
											className: "font-semibold text-brand-charcoal mb-2",
											children: "Send on WhatsApp"
										}),
										/* @__PURE__ */ jsx("p", {
											className: "text-gray-600 text-sm",
											children: "Send your whole cart to our sales team in one ready-written message"
										})
									]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "text-center",
									children: [
										/* @__PURE__ */ jsx("div", {
											className: "bg-brand-yellow text-brand-charcoal w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold",
											children: "4"
										}),
										/* @__PURE__ */ jsx("h3", {
											className: "font-semibold text-brand-charcoal mb-2",
											children: "Complete Order"
										}),
										/* @__PURE__ */ jsx("p", {
											className: "text-gray-600 text-sm",
											children: "Pay via M-Pesa/Bank & get delivery or pickup"
										})
									]
								})
							]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "mt-10 flex flex-col items-center gap-3",
							children: [/* @__PURE__ */ jsxs(SiteLink, {
								to: "/how-to-order",
								className: "inline-flex items-center gap-2 rounded-full border-2 border-brand-charcoal px-5 py-3 font-semibold text-brand-charcoal transition-colors hover:bg-brand-charcoal hover:text-white",
								children: [/* @__PURE__ */ jsx(FileText, {
									size: 18,
									"aria-hidden": "true"
								}), " See the full ordering guide"]
							}), /* @__PURE__ */ jsx("a", {
								href: "/how-to-order.pdf",
								target: "_blank",
								rel: "noopener",
								className: "text-sm text-gray-600 underline hover:text-brand-charcoal",
								children: "or download it as a PDF"
							})]
						})
					]
				})
			}),
			checkoutProduct && /* @__PURE__ */ jsx(CheckoutModal, {
				product: checkoutProduct,
				offers,
				onClose: closeCheckout,
				onSend: sendOrder
			})
		]
	});
}
//#endregion
//#region src/pages/ProductPage.jsx
var absolute$1 = (url) => /^https?:\/\//.test(url) ? url : `${SITE_URL}${url}`;
function productJsonLd(product) {
	const images = [product.image, ...product.alternateImages || []].filter(Boolean).map((src) => absolute$1(assetUrl(src)));
	const data = {
		"@context": "https://schema.org",
		"@type": "Product",
		name: product.name,
		sku: product.id,
		url: canonicalUrl(productPath(product)),
		description: product.specs || productMeta(product).description,
		...images.length ? { image: images } : {},
		...product.brand && product.brand.toLowerCase() !== "generic" ? { brand: {
			"@type": "Brand",
			name: product.brand
		} } : {},
		...product.categoryName || product.category ? { category: product.categoryName || product.category } : {},
		...product.price ? { offers: {
			"@type": "Offer",
			url: canonicalUrl(productPath(product)),
			priceCurrency: "KES",
			price: String(product.price),
			seller: {
				"@type": "Organization",
				name: "JOJO Tech Solutions Ltd"
			}
		} } : {}
	};
	return JSON.stringify(data).replace(/</g, "\\u003c");
}
function ProductPage() {
	const { id } = useParams();
	const products = useProducts();
	const offers = useOffers();
	const { checkoutProduct, startOrder, closeCheckout, sendOrder, requestQuote } = useOrdering();
	const fromList = useMemo(() => products.find((p) => p.id === id) || null, [products, id]);
	const [remote, setRemote] = useState({
		id: null,
		product: null
	});
	useEffect(() => {
		if (fromList) return void 0;
		let cancelled = false;
		api(`/products/${encodeURIComponent(id)}`).then((data) => !cancelled && setRemote({
			id,
			product: data.product
		})).catch(() => !cancelled && setRemote({
			id,
			product: null
		}));
		return () => {
			cancelled = true;
		};
	}, [id, fromList]);
	const product = fromList || (remote.id === id ? remote.product : null);
	const lookupDone = Boolean(fromList) || remote.id === id;
	const [activeImage, setActiveImage] = useState(0);
	useEffect(() => {
		setActiveImage(0);
	}, [id]);
	useEffect(() => {
		if (product) applyPageMeta({
			...productMeta(product),
			path: productPath(product)
		});
		else if (lookupDone) applyPageMeta({
			title: "Product not found | JOJO Tech Solutions Ltd",
			description: "This product is no longer available.",
			noindex: true,
			path: `/product/${id}`
		});
	}, [
		product,
		lookupDone,
		id
	]);
	const related = useMemo(() => {
		if (!product) return [];
		return products.filter((p) => p.id !== product.id && p.active !== false && p.category === product.category).slice(0, 4);
	}, [products, product]);
	if (!product) return /* @__PURE__ */ jsx("div", {
		className: "min-h-[60vh] bg-gray-50 px-4 py-20 text-center",
		children: lookupDone ? /* @__PURE__ */ jsxs(Fragment, { children: [
			/* @__PURE__ */ jsx("h1", {
				className: "text-3xl font-bold text-brand-charcoal",
				children: "Product not found"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-3 text-gray-600",
				children: "This product may have been removed or renamed."
			}),
			/* @__PURE__ */ jsx(SiteLink, {
				to: "/shop",
				className: "mt-6 inline-block rounded-full bg-brand-yellow px-6 py-3 font-bold text-brand-charcoal hover:bg-brand-orange",
				children: "Browse the shop"
			})
		] }) : /* @__PURE__ */ jsx("p", {
			className: "text-gray-500",
			children: "Loading product…"
		})
	});
	const images = [product.image, ...product.alternateImages || []].filter(Boolean);
	const hasBrand = product.brand && product.brand.toLowerCase() !== "generic";
	return /* @__PURE__ */ jsxs("div", {
		className: "bg-gray-50 pb-16",
		children: [
			/* @__PURE__ */ jsx("script", {
				type: "application/ld+json",
				dangerouslySetInnerHTML: { __html: productJsonLd(product) }
			}),
			/* @__PURE__ */ jsx("nav", {
				"aria-label": "Breadcrumb",
				className: "mx-auto max-w-7xl px-4 py-4 text-sm text-gray-600 sm:px-6 lg:px-8",
				children: /* @__PURE__ */ jsxs("ol", {
					className: "flex flex-wrap items-center gap-1",
					children: [
						/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(SiteLink, {
							to: "/",
							className: "hover:underline",
							children: "Home"
						}) }),
						/* @__PURE__ */ jsx("li", {
							"aria-hidden": "true",
							children: /* @__PURE__ */ jsx(ChevronRight, { size: 14 })
						}),
						/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(SiteLink, {
							to: "/shop",
							className: "hover:underline",
							children: "Shop"
						}) }),
						/* @__PURE__ */ jsx("li", {
							"aria-hidden": "true",
							children: /* @__PURE__ */ jsx(ChevronRight, { size: 14 })
						}),
						product.category && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(SiteLink, {
							to: categoryPath(product.category),
							className: "hover:underline",
							children: product.category
						}) }), /* @__PURE__ */ jsx("li", {
							"aria-hidden": "true",
							children: /* @__PURE__ */ jsx(ChevronRight, { size: 14 })
						})] }),
						/* @__PURE__ */ jsx("li", {
							"aria-current": "page",
							className: "font-medium text-brand-charcoal",
							children: product.name
						})
					]
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mx-auto grid max-w-7xl gap-8 px-4 sm:px-6 lg:grid-cols-2 lg:gap-12 lg:px-8",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
					className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm",
					children: images.length > 0 ? /* @__PURE__ */ jsx(ProductImage, {
						src: images[activeImage],
						alt: product.name,
						onOpen: () => trackProductClick({
							productId: product.id,
							label: product.name
						})
					}, images[activeImage]) : /* @__PURE__ */ jsx("div", {
						className: "flex aspect-square items-center justify-center text-gray-400",
						children: "No photo yet"
					})
				}), images.length > 1 && /* @__PURE__ */ jsx("ul", {
					className: "mt-3 flex gap-2 overflow-x-auto",
					"aria-label": "Product photos",
					children: images.map((src, index) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("button", {
						type: "button",
						onClick: () => setActiveImage(index),
						"aria-label": `Show photo ${index + 1}`,
						"aria-current": index === activeImage ? "true" : void 0,
						className: `h-20 w-20 overflow-hidden rounded-lg border-2 bg-white ${index === activeImage ? "border-brand-yellow" : "border-gray-200"}`,
						children: /* @__PURE__ */ jsx("img", {
							src: assetUrl(src),
							alt: "",
							loading: "lazy",
							className: "h-full w-full object-cover"
						})
					}) }, src))
				})] }), /* @__PURE__ */ jsxs("div", { children: [
					(hasBrand || product.condition) && /* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [hasBrand && /* @__PURE__ */ jsx("p", {
							className: "text-sm font-semibold uppercase tracking-wide text-gray-500",
							children: product.brand
						}), /* @__PURE__ */ jsx(ConditionTag, { condition: product.condition })]
					}),
					/* @__PURE__ */ jsx("h1", {
						className: "mt-1 text-3xl font-bold text-brand-charcoal md:text-4xl",
						children: product.name
					}),
					/* @__PURE__ */ jsx(HotFeature, {
						feature: product.hotFeature,
						className: "mt-2"
					}),
					product.category && /* @__PURE__ */ jsx("p", {
						className: "mt-2 text-sm text-gray-600",
						children: /* @__PURE__ */ jsx(SiteLink, {
							to: categoryPath(product.category),
							className: "hover:underline",
							children: product.categoryName || product.category
						})
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-6 text-lg",
						children: [/* @__PURE__ */ jsx(PriceLine, {
							product,
							offers
						}), product.freeGift && /* @__PURE__ */ jsx("div", {
							className: "-mt-2 mb-4",
							children: /* @__PURE__ */ jsx(FreeGiftBadge, {
								gift: product.freeGift,
								inline: true
							})
						})]
					}),
					product.specs && /* @__PURE__ */ jsxs("section", {
						className: "mt-2",
						children: [/* @__PURE__ */ jsx("h2", {
							className: "text-lg font-semibold text-brand-charcoal",
							children: "Specifications"
						}), /* @__PURE__ */ jsx("p", {
							className: "mt-2 whitespace-pre-line text-gray-700",
							children: product.specs
						})]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [
							/* @__PURE__ */ jsxs("button", {
								type: "button",
								onClick: () => startOrder(product),
								className: "flex min-w-[13rem] flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-full bg-green-600 px-6 py-3 font-semibold text-white transition-colors hover:bg-green-700",
								children: [/* @__PURE__ */ jsx(MessageCircle, { size: 20 }), " Order via WhatsApp"]
							}),
							/* @__PURE__ */ jsx(AddToCartButton, {
								product,
								variant: "full"
							}),
							/* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: () => requestQuote(product),
								className: "min-w-[13rem] flex-1 whitespace-nowrap rounded-full bg-brand-yellow px-6 py-3 font-semibold text-brand-charcoal transition-colors hover:bg-brand-orange",
								children: "Get Expert Quote"
							})
						]
					}),
					/* @__PURE__ */ jsxs("ul", {
						className: "mt-8 space-y-3 rounded-xl border border-gray-200 bg-white p-5 text-sm text-gray-700",
						children: [
							/* @__PURE__ */ jsxs("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ jsx(MessageCircle, {
									size: 18,
									className: "mt-0.5 shrink-0 text-brand-charcoal",
									"aria-hidden": "true"
								}), " Price and availability are confirmed with you on WhatsApp."]
							}),
							/* @__PURE__ */ jsxs("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ jsx(Wallet, {
									size: 18,
									className: "mt-0.5 shrink-0 text-brand-charcoal",
									"aria-hidden": "true"
								}), " Pay by M-Pesa or bank transfer."]
							}),
							/* @__PURE__ */ jsxs("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ jsx(MapPin, {
									size: 18,
									className: "mt-0.5 shrink-0 text-brand-charcoal",
									"aria-hidden": "true"
								}), " Delivery, or pick up from our shop."]
							})
						]
					})
				] })]
			}),
			related.length > 0 && /* @__PURE__ */ jsxs("section", {
				className: "mx-auto mt-14 max-w-7xl px-4 sm:px-6 lg:px-8",
				"aria-label": "Related products",
				children: [/* @__PURE__ */ jsxs("h2", {
					className: "text-2xl font-bold text-brand-charcoal",
					children: ["More in ", product.categoryName || product.category]
				}), /* @__PURE__ */ jsx("ul", {
					className: "mt-5 grid grid-cols-2 gap-4 md:grid-cols-4",
					children: related.map((item) => /* @__PURE__ */ jsx("li", {
						className: "overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm transition-shadow hover:shadow-md",
						children: /* @__PURE__ */ jsxs(SiteLink, {
							to: productPath(item),
							className: "block",
							children: [/* @__PURE__ */ jsx("img", {
								src: assetUrl(item.image),
								alt: item.name,
								loading: "lazy",
								className: "aspect-square w-full object-cover"
							}), /* @__PURE__ */ jsx("span", {
								className: "block p-3 text-sm font-semibold text-brand-charcoal",
								children: item.name
							})]
						})
					}, item.id))
				})]
			}),
			checkoutProduct && /* @__PURE__ */ jsx(CheckoutModal, {
				product: checkoutProduct,
				offers,
				onClose: closeCheckout,
				onSend: sendOrder
			})
		]
	});
}
//#endregion
//#region src/pages/HowToOrder.jsx
var STEPS = [
	{
		title: "Find your products",
		body: "Open the Shop and browse by category, search by name or brand, and look out for the Hot products and Best sellers at the top."
	},
	{
		title: "Add them to your cart",
		body: "Tap the small cart icon on a product photo (or Add to cart on its page). Keep shopping and add as many as you need, up to 12 different products. Your cart is remembered for 30 days."
	},
	{
		title: "Check your cart",
		body: "Tap the cart icon in the top menu. Change quantities with + and −, remove anything you do not want, and type your delivery address (area, street or building). You can leave the address blank and give it on WhatsApp."
	},
	{
		title: "Send your order on WhatsApp",
		body: "Tap Send order on WhatsApp. Your message opens in WhatsApp already written, with every item, its quantity and a link to its photo. Just press send, and please leave the Order ref line in.",
		whatsapp: true
	},
	{
		title: "We confirm and you receive",
		body: "Our team replies on WhatsApp to confirm the price, availability and delivery or pickup. Pay by M-Pesa or bank transfer, then we deliver, or you collect from our shop."
	}
];
var FAQ = [
	{
		q: "Do I need an account to order?",
		a: "No. You can order as a guest. A free account gives you member discounts, coupon codes and delivery offers in your cart before you send the order."
	},
	{
		q: "When do I pay?",
		a: "After we have confirmed the price and availability with you on WhatsApp. You can pay by M-Pesa or bank transfer."
	},
	{
		q: "Can you deliver, or do I collect?",
		a: "Both are possible. Give your delivery address in the cart, or tell us on WhatsApp, and we confirm delivery or pickup with you."
	},
	{
		q: "How many products can I put in the cart?",
		a: "Up to 12 different products, with up to 999 of each. The cart is saved in your browser for 30 days and is the same on the main site and the shop address."
	},
	{
		q: "What if I only want one product, or need a quote?",
		a: "Use the Order button on a product to send just that item. Use Get Quote for bulk orders or specification questions, and type the quantity you need after \"Quantity needed\"."
	},
	{
		q: "Are the prices final?",
		a: "Prices and availability are always confirmed with you on WhatsApp before you pay anything, because stock can change during the day."
	}
];
function faqJsonLd() {
	const data = {
		"@context": "https://schema.org",
		"@type": "FAQPage",
		mainEntity: FAQ.map(({ q, a }) => ({
			"@type": "Question",
			name: q,
			acceptedAnswer: {
				"@type": "Answer",
				text: a
			}
		}))
	};
	return JSON.stringify(data).replace(/</g, "\\u003c");
}
function HowToOrder() {
	const { contact, hours, whatsappUrl } = useSiteSettings();
	return /* @__PURE__ */ jsxs("div", {
		className: "bg-gray-50 pb-16",
		children: [
			/* @__PURE__ */ jsx("script", {
				type: "application/ld+json",
				dangerouslySetInnerHTML: { __html: faqJsonLd() }
			}),
			/* @__PURE__ */ jsx("section", {
				className: "page-hero",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-4xl px-4 py-14 text-center sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsxs("h1", {
							className: "text-4xl font-bold text-brand-charcoal md:text-5xl",
							children: ["How to ", /* @__PURE__ */ jsx("span", {
								className: "text-brand-ember",
								children: "order online"
							})]
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mx-auto mt-4 max-w-2xl text-lg text-gray-600",
							children: "Pick what you need, then send your order on WhatsApp."
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "mt-7 flex flex-col justify-center gap-3 sm:flex-row",
							children: [/* @__PURE__ */ jsxs(SiteLink, {
								to: "/shop",
								className: "inline-flex items-center justify-center gap-2 rounded-full bg-brand-yellow px-6 py-3 font-bold text-brand-charcoal hover:bg-brand-orange",
								children: [/* @__PURE__ */ jsx(ShoppingCart, {
									size: 18,
									"aria-hidden": "true"
								}), " Go to the Shop"]
							}), /* @__PURE__ */ jsxs("a", {
								href: "/how-to-order.pdf",
								target: "_blank",
								rel: "noopener",
								className: "inline-flex items-center justify-center gap-2 rounded-full border-2 border-brand-charcoal px-6 py-3 font-bold text-brand-charcoal hover:bg-brand-charcoal hover:text-white",
								children: [/* @__PURE__ */ jsx(FileText, {
									size: 18,
									"aria-hidden": "true"
								}), " Download as PDF"]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "mx-auto max-w-4xl px-4 pt-12 sm:px-6 lg:px-8",
				"aria-label": "Ordering steps",
				children: [
					/* @__PURE__ */ jsx("h2", {
						className: "text-2xl font-bold text-brand-charcoal",
						children: "Order in 5 easy steps"
					}),
					/* @__PURE__ */ jsx("ol", {
						className: "mt-6 space-y-4",
						children: STEPS.map((step, index) => /* @__PURE__ */ jsxs("li", {
							className: "flex gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm",
							children: [/* @__PURE__ */ jsx("span", {
								className: `flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-lg font-bold text-white ${step.whatsapp ? "bg-green-600" : "bg-brand-charcoal"}`,
								children: index + 1
							}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("h3", {
								className: "flex items-center gap-2 text-lg font-semibold text-brand-charcoal",
								children: [step.title, step.whatsapp && /* @__PURE__ */ jsx(MessageCircle, {
									size: 18,
									className: "text-green-600",
									"aria-hidden": "true"
								})]
							}), /* @__PURE__ */ jsx("p", {
								className: "mt-1 text-gray-700",
								children: step.body
							})] })]
						}, step.title))
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-8 grid gap-4 md:grid-cols-2",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "rounded-xl border border-gray-200 bg-white p-5",
							children: [/* @__PURE__ */ jsx("h3", {
								className: "text-lg font-semibold text-brand-charcoal",
								children: "Only one item, or need a quote?"
							}), /* @__PURE__ */ jsxs("ul", {
								className: "mt-2 list-disc space-y-1 pl-5 text-gray-700",
								children: [/* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsx("b", { children: "Order" }), " on a product sends just that item, with your quantity and address."] }), /* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsx("b", { children: "Get Quote" }), " opens a message for bulk or specification questions."] })]
							})]
						}), /* @__PURE__ */ jsxs("div", {
							className: "rounded-xl border border-yellow-200 bg-yellow-50 p-5",
							children: [/* @__PURE__ */ jsxs("h3", {
								className: "flex items-center gap-2 text-lg font-semibold text-brand-charcoal",
								children: [/* @__PURE__ */ jsx(BadgePercent, {
									size: 18,
									"aria-hidden": "true"
								}), " Member offers"]
							}), /* @__PURE__ */ jsxs("p", {
								className: "mt-2 text-gray-700",
								children: [
									"Create a free account with ",
									/* @__PURE__ */ jsx("b", { children: "Sign up" }),
									" in the Shop. Signed-in members see ",
									/* @__PURE__ */ jsx("b", { children: "discounts, coupon codes and delivery offers" }),
									" in their cart before they send the order."
								]
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "mx-auto mt-12 max-w-3xl px-4 sm:px-6",
				"aria-label": "Frequently asked questions",
				children: [/* @__PURE__ */ jsx("h2", {
					className: "text-2xl font-bold text-brand-charcoal",
					children: "Common questions"
				}), /* @__PURE__ */ jsx("div", {
					className: "mt-4 divide-y divide-gray-200 rounded-xl border border-gray-200 bg-white",
					children: FAQ.map(({ q, a }) => /* @__PURE__ */ jsxs("details", {
						className: "p-5",
						children: [/* @__PURE__ */ jsx("summary", {
							className: "cursor-pointer list-none font-semibold text-brand-charcoal marker:content-none",
							children: q
						}), /* @__PURE__ */ jsx("p", {
							className: "mt-2 text-gray-700",
							children: a
						})]
					}, q))
				})]
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "mx-auto mt-12 max-w-4xl px-4 sm:px-6 lg:px-8",
				"aria-label": "Contact",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "grid gap-4 rounded-2xl bg-brand-black p-6 text-white md:grid-cols-3",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ jsx(MapPin, {
								size: 20,
								className: "mt-0.5 shrink-0 text-brand-yellow",
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("p", {
								className: "whitespace-pre-line",
								children: [
									/* @__PURE__ */ jsx("b", { children: "Visit us" }),
									/* @__PURE__ */ jsx("br", {}),
									contact.address
								]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ jsx(Clock, {
								size: 20,
								className: "mt-0.5 shrink-0 text-brand-yellow",
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("p", { children: [/* @__PURE__ */ jsx("b", { children: "Opening hours" }), hours.map(({ days, time }) => /* @__PURE__ */ jsxs("span", {
								className: "block",
								children: [
									days,
									": ",
									time
								]
							}, days))] })]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ jsx(Phone, {
								size: 20,
								className: "mt-0.5 shrink-0 text-brand-yellow",
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("p", { children: [/* @__PURE__ */ jsx("b", { children: "WhatsApp & call" }), [contact.mobilePhone, contact.officePhone].filter(Boolean).map((phone) => /* @__PURE__ */ jsx("a", {
								href: telHref(phone),
								className: "block hover:underline",
								children: phone
							}, phone))] })]
						})
					]
				}), /* @__PURE__ */ jsxs("p", {
					className: "mt-4 text-center text-sm text-gray-600",
					children: [
						"Questions? ",
						/* @__PURE__ */ jsx("a", {
							href: whatsappUrl,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "font-semibold text-brand-charcoal underline",
							children: "Chat with us on WhatsApp"
						}),
						" or visit the ",
						/* @__PURE__ */ jsx(SiteLink, {
							to: "/contact",
							className: "font-semibold text-brand-charcoal underline",
							children: "Contact page"
						}),
						"."
					]
				})]
			})
		]
	});
}
//#endregion
//#region src/usePosts.js
var cache = null;
function preloadedPosts() {
	const list = typeof window !== "undefined" ? window.__POSTS__ : globalThis.__SSR_POSTS__;
	return Array.isArray(list) ? list : [];
}
function usePosts() {
	const [state, setState] = useState(() => ({
		posts: cache || preloadedPosts(),
		loaded: Boolean(cache)
	}));
	useEffect(() => {
		let cancelled = false;
		api("/posts").then((data) => {
			if (cancelled) return;
			cache = Array.isArray(data?.posts) ? data.posts : [];
			setState({
				posts: cache,
				loaded: true
			});
		}).catch(() => !cancelled && setState((s) => ({
			...s,
			loaded: true
		})));
		return () => {
			cancelled = true;
		};
	}, []);
	return state;
}
//#endregion
//#region src/pages/News.jsx
var formatPostDate = (value) => {
	const date = /* @__PURE__ */ new Date(`${String(value || "").slice(0, 10)}T00:00:00Z`);
	return Number.isNaN(date.getTime()) ? "" : date.toLocaleDateString("en-GB", {
		day: "numeric",
		month: "long",
		year: "numeric",
		timeZone: "UTC"
	});
};
function News() {
	const { posts } = usePosts();
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen bg-gray-50",
		children: [/* @__PURE__ */ jsx(PageHeader, {
			eyebrow: "Insights",
			title: "News &",
			accent: "updates",
			intro: "New arrivals, offers, tech tips and announcements from JOJO Tech Solutions Ltd."
		}), /* @__PURE__ */ jsx("section", {
			className: "py-16",
			children: /* @__PURE__ */ jsx("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: posts.length === 0 ? /* @__PURE__ */ jsxs("div", {
					className: "py-16 text-center text-gray-500",
					children: [/* @__PURE__ */ jsx(Newspaper, {
						size: 40,
						className: "mx-auto mb-3 text-gray-400",
						"aria-hidden": "true"
					}), /* @__PURE__ */ jsx("p", {
						className: "text-lg",
						children: "No news yet. Check back soon."
					})]
				}) : /* @__PURE__ */ jsx("div", {
					className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
					children: posts.map((post) => /* @__PURE__ */ jsxs("article", {
						className: "flex flex-col overflow-hidden rounded-xl bg-white shadow-md",
						children: [post.image && /* @__PURE__ */ jsx(SiteLink, {
							to: postPath(post),
							className: "block aspect-[16/9] overflow-hidden bg-gray-100",
							"aria-label": post.title,
							children: /* @__PURE__ */ jsx("img", {
								src: assetUrl(post.image),
								alt: "",
								loading: "lazy",
								className: "h-full w-full object-cover"
							})
						}), /* @__PURE__ */ jsxs("div", {
							className: "flex flex-1 flex-col p-5",
							children: [
								/* @__PURE__ */ jsx("p", {
									className: "text-xs font-medium uppercase tracking-wide text-gray-500",
									children: formatPostDate(post.publishedAt)
								}),
								/* @__PURE__ */ jsx("h2", {
									className: "mt-1 text-xl font-bold text-brand-charcoal",
									children: /* @__PURE__ */ jsx(SiteLink, {
										to: postPath(post),
										className: "hover:underline",
										children: post.title
									})
								}),
								post.summary && /* @__PURE__ */ jsx("p", {
									className: "mt-2 flex-1 text-gray-600",
									children: post.summary
								}),
								/* @__PURE__ */ jsx(SiteLink, {
									to: postPath(post),
									className: "mt-4 font-semibold text-brand-charcoal underline",
									children: "Read more"
								})
							]
						})]
					}, post.id))
				})
			})
		})]
	});
}
//#endregion
//#region src/pages/NewsPost.jsx
var absolute = (url) => /^https?:\/\//.test(url) ? url : `${SITE_URL}${url}`;
function NewsPost() {
	const { id } = useParams();
	const { posts, loaded } = usePosts();
	const post = posts.find((p) => String(p.id) === id) || null;
	useEffect(() => {
		if (post) applyPageMeta({
			...postMeta(post),
			path: postPath(post)
		});
		else if (loaded) applyPageMeta({
			title: "News not found | JOJO Tech Solutions Ltd",
			description: "This news post is no longer available.",
			noindex: true
		});
	}, [post, loaded]);
	if (!post) return /* @__PURE__ */ jsxs("div", {
		className: "mx-auto max-w-3xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ jsx("h1", {
			className: "text-2xl font-bold text-brand-charcoal",
			children: loaded ? "This post is no longer available" : "Loading…"
		}), /* @__PURE__ */ jsx(SiteLink, {
			to: "/news",
			className: "mt-4 inline-block font-semibold text-brand-charcoal underline",
			children: "Back to all news"
		})]
	});
	const jsonLd = JSON.stringify({
		"@context": "https://schema.org",
		"@type": "NewsArticle",
		headline: post.title,
		datePublished: post.publishedAt,
		dateModified: post.updatedAt || post.publishedAt,
		mainEntityOfPage: canonicalUrl(postPath(post)),
		...post.image ? { image: absolute(assetUrl(post.image)) } : {},
		author: {
			"@type": "Organization",
			name: "JOJO Tech Solutions Ltd"
		},
		publisher: {
			"@type": "Organization",
			name: "JOJO Tech Solutions Ltd"
		}
	}).replace(/</g, "<");
	const paragraphs = String(post.body || "").split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
	return /* @__PURE__ */ jsxs("article", {
		className: "min-h-screen bg-gray-50 pb-20",
		children: [/* @__PURE__ */ jsx("script", {
			type: "application/ld+json",
			dangerouslySetInnerHTML: { __html: jsonLd }
		}), /* @__PURE__ */ jsxs("div", {
			className: "mx-auto max-w-3xl px-4 pt-10 sm:px-6",
			children: [
				/* @__PURE__ */ jsxs(SiteLink, {
					to: "/news",
					className: "inline-flex items-center gap-1 text-sm font-medium text-gray-600 hover:text-brand-charcoal",
					children: [/* @__PURE__ */ jsx(ArrowLeft, {
						size: 16,
						"aria-hidden": "true"
					}), " All news"]
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-6 text-sm font-medium uppercase tracking-wide text-gray-500",
					children: formatPostDate(post.publishedAt)
				}),
				/* @__PURE__ */ jsx("h1", {
					className: "mt-1 text-3xl font-bold text-brand-charcoal md:text-4xl",
					children: post.title
				}),
				post.image && /* @__PURE__ */ jsx("img", {
					src: assetUrl(post.image),
					alt: "",
					className: "mt-6 w-full rounded-xl object-cover shadow-md"
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-8 space-y-4 text-lg leading-relaxed text-gray-700",
					children: paragraphs.map((text, index) => /* @__PURE__ */ jsx("p", {
						className: "whitespace-pre-line",
						children: text
					}, index))
				})
			]
		})]
	});
}
//#endregion
//#region src/components/AnnouncementBar.jsx
function AnnouncementBar() {
	const { announcement } = useSiteSettings();
	if (!announcement?.enabled || !announcement.text) return null;
	const content = announcement.link ? /* @__PURE__ */ jsx("a", {
		href: announcement.link,
		className: "underline underline-offset-2 hover:no-underline",
		children: announcement.text
	}) : announcement.text;
	return /* @__PURE__ */ jsx("div", {
		role: "region",
		"aria-label": "Announcement",
		className: "bg-brand-yellow px-4 py-2 text-center text-sm font-semibold text-brand-charcoal",
		children: content
	});
}
//#endregion
//#region src/pages/CategoryPage.jsx
var faqFor = (name) => [
	{
		q: `Can I buy ${name.toLowerCase()} from JOJO Tech Solutions Ltd online?`,
		a: "Yes. Open any product, press Order via WhatsApp and our team will confirm the price and availability with you. You can pay by M-Pesa or bank transfer, then arrange delivery or pick up from our shop."
	},
	{
		q: `How much do ${name.toLowerCase()} cost?`,
		a: "Prices depend on the model and what we have in stock. Press Order or Get Expert Quote on any product and we will confirm the current price on WhatsApp. Signed-in members also get access to discounts, coupons and delivery offers."
	},
	{
		q: "Where can I see the products in person?",
		a: "Visit our shop, open Monday to Saturday, 8:00 AM to 6:00 PM. See the Contact page for directions."
	}
];
function categoryJsonLd(group, copy, faq) {
	const url = canonicalUrl(categoryPath(group.name));
	const data = {
		"@context": "https://schema.org",
		"@graph": [
			{
				"@type": "CollectionPage",
				name: copy.heading,
				url,
				description: copy.description
			},
			{
				"@type": "BreadcrumbList",
				itemListElement: [
					{
						"@type": "ListItem",
						position: 1,
						name: "Home",
						item: canonicalUrl("/")
					},
					{
						"@type": "ListItem",
						position: 2,
						name: "Shop",
						item: canonicalUrl("/shop")
					},
					{
						"@type": "ListItem",
						position: 3,
						name: group.name,
						item: url
					}
				]
			},
			{
				"@type": "ItemList",
				itemListElement: group.products.map((product, index) => ({
					"@type": "ListItem",
					position: index + 1,
					url: canonicalUrl(productPath(product)),
					name: product.name
				}))
			},
			{
				"@type": "FAQPage",
				mainEntity: faq.map(({ q, a }) => ({
					"@type": "Question",
					name: q,
					acceptedAnswer: {
						"@type": "Answer",
						text: a
					}
				}))
			}
		]
	};
	return JSON.stringify(data).replace(/</g, "\\u003c");
}
function CategoryPage() {
	const { slug } = useParams();
	const products = useProducts();
	const offers = useOffers();
	const { checkoutProduct, startOrder, closeCheckout, sendOrder, requestQuote } = useOrdering();
	const groups = useMemo(() => groupCategories(products), [products]);
	const group = groups.find((g) => g.slug === slug) || null;
	const [filters, setFilters] = useState({
		slug,
		brand: "All",
		query: ""
	});
	const { brand, query } = filters.slug === slug ? filters : {
		brand: "All",
		query: ""
	};
	const updateFilters = (patch) => setFilters({
		slug,
		brand,
		query,
		...patch
	});
	const brandOptions = useMemo(() => [...new Set((group?.products || []).map((p) => p.brand).filter(Boolean))].sort((a, b) => a.localeCompare(b)), [group]);
	const visibleProducts = useMemo(() => {
		const q = query.trim().toLowerCase();
		return (group?.products || []).filter((p) => (brand === "All" || p.brand === brand) && (!q || p.name.toLowerCase().includes(q) || (p.brand || "").toLowerCase().includes(q) || (p.specs || "").toLowerCase().includes(q)));
	}, [
		group,
		brand,
		query
	]);
	useEffect(() => {
		if (group) applyPageMeta({
			...categoryMeta(group),
			path: categoryPath(group.name)
		});
		else applyPageMeta({
			title: "Category not found | JOJO Tech Solutions Ltd",
			description: "This category is no longer available.",
			noindex: true,
			path: `/category/${slug}`
		});
	}, [group, slug]);
	if (!group) return /* @__PURE__ */ jsxs("div", {
		className: "min-h-[60vh] bg-gray-50 px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ jsx("h1", {
				className: "text-3xl font-bold text-brand-charcoal",
				children: "Category not found"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-3 text-gray-600",
				children: "This category may have been renamed or removed."
			}),
			/* @__PURE__ */ jsx(SiteLink, {
				to: "/shop",
				className: "mt-6 inline-block rounded-full bg-brand-yellow px-6 py-3 font-bold text-brand-charcoal hover:bg-brand-orange",
				children: "Browse the shop"
			})
		]
	});
	const copy = categoryCopy(group);
	const faq = faqFor(group.name);
	const others = groups.filter((g) => g.slug !== group.slug);
	return /* @__PURE__ */ jsxs("div", {
		className: "bg-gray-50 pb-16",
		children: [
			/* @__PURE__ */ jsx("script", {
				type: "application/ld+json",
				dangerouslySetInnerHTML: { __html: categoryJsonLd(group, copy, faq) }
			}),
			/* @__PURE__ */ jsx("section", {
				className: "page-hero",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ jsx("nav", {
							"aria-label": "Breadcrumb",
							className: "text-sm text-gray-600",
							children: /* @__PURE__ */ jsxs("ol", {
								className: "flex flex-wrap items-center gap-1",
								children: [
									/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(SiteLink, {
										to: "/",
										className: "hover:text-brand-charcoal hover:underline",
										children: "Home"
									}) }),
									/* @__PURE__ */ jsx("li", {
										"aria-hidden": "true",
										children: /* @__PURE__ */ jsx(ChevronRight, { size: 14 })
									}),
									/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(SiteLink, {
										to: "/shop",
										className: "hover:text-brand-charcoal hover:underline",
										children: "Shop"
									}) }),
									/* @__PURE__ */ jsx("li", {
										"aria-hidden": "true",
										children: /* @__PURE__ */ jsx(ChevronRight, { size: 14 })
									}),
									/* @__PURE__ */ jsx("li", {
										"aria-current": "page",
										className: "font-medium text-brand-charcoal",
										children: group.name
									})
								]
							})
						}),
						/* @__PURE__ */ jsx("h1", {
							className: "mt-4 text-3xl font-bold text-brand-charcoal md:text-5xl",
							children: copy.heading
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-4 max-w-3xl space-y-3 text-lg text-gray-600",
							children: copy.intro.map((paragraph) => /* @__PURE__ */ jsx("p", { children: paragraph }, paragraph))
						}),
						group.brands.length > 0 && /* @__PURE__ */ jsx("ul", {
							className: "mt-6 flex flex-wrap gap-2",
							"aria-label": `Brands in ${group.name}`,
							children: group.brands.map(({ brand, count }) => /* @__PURE__ */ jsxs("li", {
								className: "rounded-full bg-white shadow-sm ring-1 ring-slate-200 px-3 py-1 text-sm text-gray-700",
								children: [
									brand,
									" ",
									/* @__PURE__ */ jsxs("span", {
										className: "text-gray-500",
										children: [
											"(",
											count,
											")"
										]
									})
								]
							}, brand))
						})
					]
				})
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "mx-auto max-w-7xl px-4 pt-10 sm:px-6 lg:px-8",
				"aria-label": `${group.name} products`,
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-center",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "relative flex-1",
							children: [/* @__PURE__ */ jsx(Search, {
								className: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400",
								size: 18,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsx("input", {
								type: "search",
								value: query,
								onChange: (e) => updateFilters({ query: e.target.value }),
								placeholder: `Search ${group.name.toLowerCase()}...`,
								"aria-label": `Search ${group.name}`,
								className: "w-full rounded-lg border border-gray-300 bg-white py-3 pl-10 pr-4 focus:border-transparent focus:ring-2 focus:ring-brand-yellow"
							})]
						}), brandOptions.length > 1 && /* @__PURE__ */ jsxs("select", {
							value: brand,
							onChange: (e) => updateFilters({ brand: e.target.value }),
							"aria-label": "Filter by brand",
							className: "rounded-lg border border-gray-300 bg-white px-4 py-3 focus:border-transparent focus:ring-2 focus:ring-brand-yellow",
							children: [/* @__PURE__ */ jsx("option", {
								value: "All",
								children: "All brands"
							}), brandOptions.map((option) => /* @__PURE__ */ jsx("option", {
								value: option,
								children: option
							}, option))]
						})]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mb-6 text-gray-600",
						"aria-live": "polite",
						children: visibleProducts.length === group.products.length ? /* @__PURE__ */ jsxs(Fragment, { children: [
							/* @__PURE__ */ jsx("span", {
								className: "font-semibold text-brand-charcoal",
								children: group.products.length
							}),
							" product",
							group.products.length === 1 ? "" : "s"
						] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
							"Showing ",
							/* @__PURE__ */ jsx("span", {
								className: "font-semibold text-brand-charcoal",
								children: visibleProducts.length
							}),
							" of ",
							group.products.length,
							" products"
						] })
					}),
					/* @__PURE__ */ jsx("div", {
						className: "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
						children: visibleProducts.map((product) => /* @__PURE__ */ jsx(ShopProductCard, {
							product,
							offers,
							view: "grid",
							onOrder: startOrder,
							onQuote: requestQuote,
							onOpen: (p) => trackProductClick({
								productId: p.id,
								label: p.name
							})
						}, product.id))
					}),
					visibleProducts.length === 0 && /* @__PURE__ */ jsxs("div", {
						className: "py-12 text-center",
						children: [/* @__PURE__ */ jsx("p", {
							className: "text-lg text-gray-500",
							children: "No products match your search."
						}), /* @__PURE__ */ jsx("button", {
							type: "button",
							onClick: () => updateFilters({
								brand: "All",
								query: ""
							}),
							className: "mt-3 font-semibold text-brand-charcoal underline",
							children: "Clear filters"
						})]
					})
				]
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "mx-auto mt-14 max-w-3xl px-4 sm:px-6",
				"aria-label": "Frequently asked questions",
				children: [/* @__PURE__ */ jsxs("h2", {
					className: "text-2xl font-bold text-brand-charcoal",
					children: ["Questions about ", group.name.toLowerCase()]
				}), /* @__PURE__ */ jsx("div", {
					className: "mt-4 divide-y divide-gray-200 rounded-xl border border-gray-200 bg-white",
					children: faq.map(({ q, a }) => /* @__PURE__ */ jsxs("details", {
						className: "group p-5",
						children: [/* @__PURE__ */ jsx("summary", {
							className: "cursor-pointer list-none font-semibold text-brand-charcoal marker:content-none",
							children: q
						}), /* @__PURE__ */ jsx("p", {
							className: "mt-2 text-gray-700",
							children: a
						})]
					}, q))
				})]
			}),
			others.length > 0 && /* @__PURE__ */ jsxs("section", {
				className: "mx-auto mt-14 max-w-7xl px-4 sm:px-6 lg:px-8",
				"aria-label": "Other categories",
				children: [/* @__PURE__ */ jsx("h2", {
					className: "text-2xl font-bold text-brand-charcoal",
					children: "Shop other categories"
				}), /* @__PURE__ */ jsx("ul", {
					className: "mt-4 flex flex-wrap gap-3",
					children: others.map((other) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(SiteLink, {
						to: categoryPath(other.name),
						className: "inline-block rounded-lg border border-gray-300 bg-white px-4 py-2 font-medium text-brand-charcoal hover:border-brand-yellow hover:bg-yellow-50",
						children: [
							other.name,
							" ",
							/* @__PURE__ */ jsxs("span", {
								className: "text-gray-500",
								children: [
									"(",
									other.products.length,
									")"
								]
							})
						]
					}) }, other.slug))
				})]
			}),
			checkoutProduct && /* @__PURE__ */ jsx(CheckoutModal, {
				product: checkoutProduct,
				offers,
				onClose: closeCheckout,
				onSend: sendOrder
			})
		]
	});
}
//#endregion
//#region src/pages/Account.jsx
var fieldClass = "w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-yellow focus:border-transparent";
function Account({ mode }) {
	const isSignup = mode === "signup";
	const { login, signup } = useAuth();
	const navigate = useNavigate();
	const location = useLocation();
	const from = location.state?.from || "/shop";
	const [form, setForm] = useState({
		username: "",
		password: "",
		name: "",
		phone: ""
	});
	const [error, setError] = useState("");
	const [busy, setBusy] = useState(false);
	const set = (key) => (e) => setForm((f) => ({
		...f,
		[key]: e.target.value
	}));
	const submit = async (event) => {
		event.preventDefault();
		setBusy(true);
		setError("");
		try {
			const href = crossHref((isSignup ? await signup(form) : await login(form.username, form.password)).role === "admin" ? "/admin" : from);
			if (/^https?:/.test(href)) window.location.assign(href);
			else navigate(href, { replace: true });
		} catch (e) {
			setError(e.message);
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsx("div", {
		className: "min-h-screen bg-gray-50 py-12 px-4",
		children: /* @__PURE__ */ jsxs("div", {
			className: "mx-auto grid max-w-4xl overflow-hidden rounded-2xl bg-white shadow-xl md:grid-cols-5",
			children: [/* @__PURE__ */ jsxs("aside", {
				className: "bg-brand-charcoal p-8 text-white md:col-span-2",
				children: [
					/* @__PURE__ */ jsx("h1", {
						className: "text-2xl font-bold",
						children: isSignup ? "Create your account" : "Welcome back"
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-2 text-sm text-gray-300",
						children: "Members unlock exclusive offers before they send an order on WhatsApp."
					}),
					/* @__PURE__ */ jsx("ul", {
						className: "mt-6 space-y-4",
						children: [
							{
								icon: BadgePercent,
								text: "Member discounts on shop prices"
							},
							{
								icon: Ticket,
								text: "Coupon codes you can use at checkout"
							},
							{
								icon: Truck,
								text: "Delivery offers on your orders"
							}
						].map(({ icon: Icon, text }) => /* @__PURE__ */ jsxs("li", {
							className: "flex items-start gap-3 text-sm",
							children: [/* @__PURE__ */ jsx(Icon, {
								size: 20,
								className: "mt-0.5 shrink-0 text-brand-yellow",
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsx("span", { children: text })]
						}, text))
					})
				]
			}), /* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				className: "space-y-4 p-8 md:col-span-3",
				children: [
					error && /* @__PURE__ */ jsx("div", {
						role: "alert",
						className: "rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800",
						children: error
					}),
					isSignup && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("label", {
						className: "block text-sm font-medium text-gray-700",
						children: ["Full name", /* @__PURE__ */ jsx("input", {
							required: true,
							autoComplete: "name",
							className: `${fieldClass} mt-1`,
							value: form.name,
							onChange: set("name")
						})]
					}), /* @__PURE__ */ jsxs("label", {
						className: "block text-sm font-medium text-gray-700",
						children: ["Phone number", /* @__PURE__ */ jsx("input", {
							required: true,
							type: "tel",
							autoComplete: "tel",
							placeholder: "+254 7XX XXX XXX",
							className: `${fieldClass} mt-1`,
							value: form.phone,
							onChange: set("phone")
						})]
					})] }),
					/* @__PURE__ */ jsxs("label", {
						className: "block text-sm font-medium text-gray-700",
						children: [
							"Username",
							/* @__PURE__ */ jsx("input", {
								required: true,
								autoComplete: "username",
								className: `${fieldClass} mt-1`,
								value: form.username,
								onChange: set("username")
							}),
							isSignup && /* @__PURE__ */ jsx("span", {
								className: "mt-1 block text-xs font-normal text-gray-500",
								children: "3–32 letters, numbers, dots, dashes or underscores."
							})
						]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "block text-sm font-medium text-gray-700",
						children: [
							"Password",
							/* @__PURE__ */ jsx("input", {
								required: true,
								type: "password",
								minLength: isSignup ? 8 : void 0,
								autoComplete: isSignup ? "new-password" : "current-password",
								className: `${fieldClass} mt-1`,
								value: form.password,
								onChange: set("password")
							}),
							isSignup && /* @__PURE__ */ jsx("span", {
								className: "mt-1 block text-xs font-normal text-gray-500",
								children: "At least 8 characters."
							})
						]
					}),
					/* @__PURE__ */ jsx("button", {
						type: "submit",
						disabled: busy,
						className: "w-full rounded-full bg-brand-yellow px-4 py-3 font-bold text-brand-charcoal transition-colors hover:bg-brand-orange disabled:opacity-50",
						children: busy ? "Please wait…" : isSignup ? "Create account" : "Sign in"
					}),
					/* @__PURE__ */ jsxs("p", {
						className: "text-center text-sm text-gray-600",
						children: [isSignup ? "Already have an account? " : "New here? ", /* @__PURE__ */ jsx(Link, {
							to: isSignup ? "/login" : "/signup",
							state: location.state,
							className: "font-semibold text-brand-charcoal underline",
							children: isSignup ? "Sign in" : "Create an account"
						})]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/pages/admin/ui.js
var inputClass = "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-brand-yellow focus:border-transparent bg-white";
var btnPrimary = "inline-flex items-center justify-center gap-2 rounded-lg bg-brand-charcoal px-4 py-2 text-sm font-semibold text-white hover:bg-brand-black disabled:opacity-50 disabled:cursor-not-allowed";
var btnYellow = "inline-flex items-center justify-center gap-2 rounded-lg bg-brand-yellow px-4 py-2 text-sm font-semibold text-brand-charcoal hover:bg-brand-orange disabled:opacity-50 disabled:cursor-not-allowed";
var btnGhost = "inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed";
function formatDate(value) {
	if (!value) return "";
	const d = new Date(String(value).replace(" ", "T"));
	return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString([], {
		dateStyle: "medium",
		timeStyle: "short"
	});
}
//#endregion
//#region src/pages/admin/Widgets.jsx
function Badge({ children, tone = "gray" }) {
	return /* @__PURE__ */ jsx("span", {
		className: `inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold ${{
			gray: "bg-gray-100 text-gray-700",
			green: "bg-green-100 text-green-800",
			red: "bg-red-100 text-red-800",
			amber: "bg-amber-100 text-amber-800",
			purple: "bg-purple-100 text-purple-800"
		}[tone]}`,
		children
	});
}
function Notice({ tone = "error", children }) {
	return /* @__PURE__ */ jsx("div", {
		role: tone === "error" ? "alert" : "status",
		className: `rounded-lg border px-4 py-3 text-sm ${{
			error: "border-red-200 bg-red-50 text-red-800",
			ok: "border-green-200 bg-green-50 text-green-800",
			info: "border-blue-200 bg-blue-50 text-blue-800"
		}[tone]}`,
		children
	});
}
function Empty({ children }) {
	return /* @__PURE__ */ jsx("p", {
		className: "rounded-xl border border-dashed border-gray-300 bg-white py-12 text-center text-sm text-gray-500",
		children
	});
}
//#endregion
//#region src/pages/admin/useLoad.js
function useLoad(path) {
	const [data, setData] = useState(null);
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(true);
	const reload = useCallback(async () => {
		setLoading(true);
		try {
			setData(await api(path));
			setError("");
		} catch (e) {
			setError(e.message);
			if (e.status === 401) window.dispatchEvent(new Event("jojo-admin-logout"));
		} finally {
			setLoading(false);
		}
	}, [path]);
	useEffect(() => {
		reload();
	}, [reload]);
	return {
		data,
		error,
		loading,
		reload
	};
}
//#endregion
//#region src/pages/admin/Dashboard.jsx
function Dashboard({ goTo }) {
	const { data, error, loading } = useLoad("/admin/stats");
	if (error) return /* @__PURE__ */ jsx(Notice, { children: error });
	if (loading && !data) return /* @__PURE__ */ jsx("p", {
		className: "text-gray-500",
		children: "Loading…"
	});
	const cards = [
		{
			label: "Products",
			value: data.products,
			tab: "products"
		},
		{
			label: "Customer accounts",
			value: data.customers,
			tab: "customers"
		},
		{
			label: "Unhandled messages",
			value: data.unreadMessages,
			tab: "messages"
		},
		{
			label: "WhatsApp clicks (7 days)",
			value: data.clicks7,
			tab: "clicks"
		},
		{
			label: "Orders awaiting a decision",
			value: data.pendingOrders,
			tab: "orders"
		},
		{
			label: "Orders dispatched",
			value: data.dispatchedOrders,
			tab: "orders"
		}
	];
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ jsx("div", {
			className: "grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6",
			children: cards.map((card) => /* @__PURE__ */ jsxs("button", {
				type: "button",
				onClick: () => goTo(card.tab),
				className: "rounded-xl border border-gray-200 bg-white p-5 text-left shadow-sm transition hover:border-brand-yellow hover:shadow-md",
				children: [/* @__PURE__ */ jsx("p", {
					className: "text-3xl font-bold text-brand-charcoal",
					children: card.value
				}), /* @__PURE__ */ jsx("p", {
					className: "mt-1 text-sm text-gray-600",
					children: card.label
				})]
			}, card.label))
		}), /* @__PURE__ */ jsxs(Notice, {
			tone: "info",
			children: [
				"An \"order\" is recorded each time a visitor presses ",
				/* @__PURE__ */ jsx("strong", { children: "Order via WhatsApp" }),
				" in the shop. The site cannot see what happens inside WhatsApp, so open the ",
				/* @__PURE__ */ jsx("strong", { children: "Orders" }),
				" tab to mark each one as dispatched or not once you have dealt with the customer."
			]
		})]
	});
}
//#endregion
//#region src/pages/admin/ProductForm.jsx
var blank$1 = {
	name: "",
	brand: "",
	category: "",
	categoryName: "",
	specs: "",
	image: "",
	alternateImages: [],
	price: "",
	oldPrice: "",
	freeGift: "",
	condition: "",
	hotFeature: "",
	inShop: true,
	inCatalog: true,
	active: true,
	hot: false
};
function Field({ label, children, hint }) {
	return /* @__PURE__ */ jsxs("label", {
		className: "block text-sm font-medium text-gray-700",
		children: [
			label,
			/* @__PURE__ */ jsx("div", {
				className: "mt-1",
				children
			}),
			hint && /* @__PURE__ */ jsx("span", {
				className: "mt-1 block text-xs font-normal text-gray-500",
				children: hint
			})
		]
	});
}
function ProductForm({ product, categories, onClose, onSaved }) {
	const isNew = !product.id;
	const [form, setForm] = useState({
		...blank$1,
		...product,
		price: product.price ?? "",
		oldPrice: product.oldPrice ?? ""
	});
	const [error, setError] = useState("");
	const [busy, setBusy] = useState(false);
	const [uploading, setUploading] = useState(false);
	useEffect(() => {
		const onKey = (e) => e.key === "Escape" && onClose();
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [onClose]);
	const set = (key) => (e) => setForm((f) => ({
		...f,
		[key]: e.target.type === "checkbox" ? e.target.checked : e.target.value
	}));
	const upload = async (event) => {
		const file = event.target.files?.[0];
		event.target.value = "";
		if (!file) return;
		setUploading(true);
		setError("");
		try {
			const fd = new FormData();
			fd.append("image", file);
			const res = await api("/admin/upload", {
				method: "POST",
				form: fd
			});
			setForm((f) => ({
				...f,
				image: res.url
			}));
		} catch (e) {
			setError(e.message);
		} finally {
			setUploading(false);
		}
	};
	const submit = async (event) => {
		event.preventDefault();
		setBusy(true);
		setError("");
		try {
			const payload = {
				...form,
				price: form.price === "" ? null : form.price,
				oldPrice: form.oldPrice === "" ? null : form.oldPrice
			};
			if (isNew) await api("/admin/products", {
				method: "POST",
				body: payload
			});
			else await api(`/admin/products/${encodeURIComponent(product.id)}`, {
				method: "PUT",
				body: payload
			});
			onSaved(isNew ? `Added "${form.name}".` : `Saved "${form.name}".`);
		} catch (e) {
			setError(e.message);
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsx("div", {
		className: "fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto bg-black/60 p-4",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": isNew ? "Add product" : "Edit product",
		children: /* @__PURE__ */ jsxs("form", {
			onSubmit: submit,
			className: "my-8 w-full max-w-2xl rounded-2xl bg-white shadow-2xl",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center justify-between border-b border-gray-200 px-6 py-4",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "text-lg font-bold text-brand-charcoal",
						children: isNew ? "Add product" : "Edit product"
					}), /* @__PURE__ */ jsx("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "Close",
						className: "rounded-full p-2 text-gray-500 hover:bg-gray-100",
						children: /* @__PURE__ */ jsx(X, { size: 18 })
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "grid gap-4 px-6 py-5 sm:grid-cols-2",
					children: [
						error && /* @__PURE__ */ jsx("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ jsx(Notice, { children: error })
						}),
						/* @__PURE__ */ jsx("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ jsx(Field, {
								label: "Name *",
								children: /* @__PURE__ */ jsx("input", {
									required: true,
									className: inputClass,
									value: form.name,
									onChange: set("name")
								})
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Brand",
							children: /* @__PURE__ */ jsx("input", {
								className: inputClass,
								value: form.brand,
								onChange: set("brand"),
								placeholder: "Generic"
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Price (KES)",
							hint: "Leave empty to show “Price on request”.",
							children: /* @__PURE__ */ jsx("input", {
								type: "number",
								min: "0",
								step: "0.01",
								className: inputClass,
								value: form.price,
								onChange: set("price")
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Old price (KES)",
							hint: "Optional “was” price, shown struck through. Must be higher than the price.",
							children: /* @__PURE__ */ jsx("input", {
								type: "number",
								min: "0",
								step: "0.01",
								className: inputClass,
								value: form.oldPrice,
								onChange: set("oldPrice")
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Free gift",
							hint: "Optional, e.g. “Wireless mouse”. Shown as a badge on the product.",
							children: /* @__PURE__ */ jsx("input", {
								maxLength: 120,
								className: inputClass,
								value: form.freeGift,
								onChange: set("freeGift"),
								placeholder: "Wireless mouse"
							})
						}),
						/* @__PURE__ */ jsxs(Field, {
							label: "Condition",
							hint: "Shown next to the brand. Pick one or type your own, e.g. Ex-UK.",
							children: [/* @__PURE__ */ jsx("input", {
								list: "admin-conditions",
								maxLength: 40,
								className: inputClass,
								value: form.condition,
								onChange: set("condition")
							}), /* @__PURE__ */ jsx("datalist", {
								id: "admin-conditions",
								children: [
									"New",
									"Refurbished",
									"Used"
								].map((c) => /* @__PURE__ */ jsx("option", { value: c }, c))
							})]
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Hot feature",
							hint: "Optional one-line selling point, e.g. “16GB RAM + 512GB SSD”. Shown on the card.",
							children: /* @__PURE__ */ jsx("input", {
								maxLength: 120,
								className: inputClass,
								value: form.hotFeature,
								onChange: set("hotFeature")
							})
						}),
						/* @__PURE__ */ jsxs(Field, {
							label: "Category",
							hint: "Used for filters, e.g. Laptops, Desktops, Accessories.",
							children: [/* @__PURE__ */ jsx("input", {
								list: "admin-categories",
								className: inputClass,
								value: form.category,
								onChange: set("category")
							}), /* @__PURE__ */ jsx("datalist", {
								id: "admin-categories",
								children: categories.map((c) => /* @__PURE__ */ jsx("option", { value: c }, c))
							})]
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Category label",
							hint: "Longer display name (optional).",
							children: /* @__PURE__ */ jsx("input", {
								className: inputClass,
								value: form.categoryName,
								onChange: set("categoryName")
							})
						}),
						/* @__PURE__ */ jsx("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ jsx(Field, {
								label: "Specs",
								children: /* @__PURE__ */ jsx("textarea", {
									rows: 3,
									className: inputClass,
									value: form.specs,
									onChange: set("specs")
								})
							})
						}),
						/* @__PURE__ */ jsx("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ jsx(Field, {
								label: "Image",
								hint: "Upload a JPG/PNG/WebP (max 5 MB) or paste a path such as /products/prod-10001.jpg.",
								children: /* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [form.image ? /* @__PURE__ */ jsx("img", {
										src: assetUrl(form.image),
										alt: "",
										className: "h-20 w-20 rounded-lg border border-gray-200 object-cover"
									}) : /* @__PURE__ */ jsx("div", { className: "h-20 w-20 rounded-lg bg-gray-100" }), /* @__PURE__ */ jsxs("div", {
										className: "flex-1 space-y-2",
										children: [
											/* @__PURE__ */ jsx("input", {
												className: inputClass,
												value: form.image,
												onChange: set("image"),
												placeholder: "/products/hp-pavilion-15.jpg"
											}),
											/* @__PURE__ */ jsx("input", {
												type: "file",
												accept: "image/jpeg,image/png,image/webp,image/gif",
												onChange: upload,
												disabled: uploading,
												className: "block w-full text-sm text-gray-600 file:mr-3 file:rounded-lg file:border-0 file:bg-gray-100 file:px-3 file:py-2 file:text-sm file:font-medium hover:file:bg-gray-200"
											}),
											uploading && /* @__PURE__ */ jsx("p", {
												className: "text-xs text-gray-500",
												children: "Uploading…"
											})
										]
									})]
								})
							})
						}),
						/* @__PURE__ */ jsxs("fieldset", {
							className: "sm:col-span-2",
							children: [/* @__PURE__ */ jsx("legend", {
								className: "text-sm font-medium text-gray-700",
								children: "Visibility"
							}), /* @__PURE__ */ jsxs("div", {
								className: "mt-2 flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-700",
								children: [
									/* @__PURE__ */ jsxs("label", {
										className: "inline-flex items-center gap-2",
										children: [/* @__PURE__ */ jsx("input", {
											type: "checkbox",
											checked: form.inShop,
											onChange: set("inShop")
										}), " Show in Shop"]
									}),
									/* @__PURE__ */ jsxs("label", {
										className: "inline-flex items-center gap-2",
										children: [/* @__PURE__ */ jsx("input", {
											type: "checkbox",
											checked: form.inCatalog,
											onChange: set("inCatalog")
										}), " Show in Product Catalogue"]
									}),
									/* @__PURE__ */ jsxs("label", {
										className: "inline-flex items-center gap-2",
										children: [/* @__PURE__ */ jsx("input", {
											type: "checkbox",
											checked: form.active,
											onChange: set("active")
										}), " Active (untick to hide everywhere)"]
									}),
									/* @__PURE__ */ jsxs("label", {
										className: "inline-flex items-center gap-2",
										children: [/* @__PURE__ */ jsx("input", {
											type: "checkbox",
											checked: form.hot,
											onChange: set("hot")
										}), " Hot product (featured at the top of the Shop)"]
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex justify-end gap-3 border-t border-gray-200 px-6 py-4",
					children: [/* @__PURE__ */ jsx("button", {
						type: "button",
						className: btnGhost,
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ jsx("button", {
						type: "submit",
						className: btnPrimary,
						disabled: busy || uploading,
						children: busy ? "Saving…" : "Save product"
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/pages/admin/importParser.js
var ALIASES = {
	id: "id",
	sku: "id",
	productid: "id",
	code: "id",
	name: "name",
	productname: "name",
	title: "name",
	product: "name",
	item: "name",
	brand: "brand",
	make: "brand",
	manufacturer: "brand",
	category: "category",
	type: "category",
	categoryname: "categoryName",
	categorylabel: "categoryName",
	department: "categoryName",
	specs: "specs",
	specifications: "specs",
	description: "specs",
	details: "specs",
	spec: "specs",
	image: "image",
	imageurl: "image",
	photo: "image",
	picture: "image",
	img: "image",
	alternateimages: "alternateImages",
	altimages: "alternateImages",
	images: "alternateImages",
	extraimages: "alternateImages",
	price: "price",
	priceksh: "price",
	pricekes: "price",
	cost: "price",
	amount: "price",
	hotfeature: "hotFeature",
	feature: "hotFeature",
	highlight: "hotFeature",
	keyfeature: "hotFeature",
	sellingpoint: "hotFeature",
	condition: "condition",
	state: "condition",
	grade: "condition",
	itemcondition: "condition",
	freegift: "freeGift",
	gift: "freeGift",
	bonus: "freeGift",
	freebie: "freeGift",
	oldprice: "oldPrice",
	wasprice: "oldPrice",
	was: "oldPrice",
	originalprice: "oldPrice",
	compareatprice: "oldPrice",
	rrp: "oldPrice",
	inshop: "inShop",
	shop: "inShop",
	showinshop: "inShop",
	onshop: "inShop",
	incatalog: "inCatalog",
	catalog: "inCatalog",
	catalogue: "inCatalog",
	showincatalog: "inCatalog",
	showincatalogue: "inCatalog",
	hot: "hot",
	hotproduct: "hot",
	featured: "hot",
	active: "active",
	visible: "active",
	enabled: "active",
	published: "active"
};
var TEMPLATE_HEADERS = [
	"id",
	"name",
	"brand",
	"category",
	"categoryName",
	"specs",
	"image",
	"alternateImages",
	"price",
	"oldPrice",
	"freeGift",
	"condition",
	"hotFeature",
	"inShop",
	"inCatalog",
	"active",
	"hot"
];
var normalizeHeader = (h) => String(h ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
function rowsFromMatrix(matrix) {
	const filtered = matrix.filter((row) => Array.isArray(row) && row.some((cell) => cell !== null && cell !== void 0 && String(cell).trim() !== ""));
	if (filtered.length < 2) throw new Error("The file needs a header row and at least one product row.");
	const headers = filtered[0].map((h) => ALIASES[normalizeHeader(h)] || null);
	if (!headers.includes("name")) throw new Error("No \"name\" column found. Add a column headed \"name\" (see the template).");
	const unknown = filtered[0].filter((h, i) => !headers[i] && String(h ?? "").trim() !== "").map(String);
	return {
		rows: filtered.slice(1).map((cells) => {
			const obj = {};
			headers.forEach((field, i) => {
				if (!field) return;
				const v = cells[i];
				if (v === null || v === void 0 || String(v).trim() === "") return;
				obj[field] = typeof v === "string" ? v.trim() : v;
			});
			return obj;
		}),
		ignoredColumns: unknown
	};
}
async function parseProductFile(file) {
	const ext = file.name.split(".").pop().toLowerCase();
	if (ext === "csv" || ext === "txt") {
		const text = await file.text();
		return rowsFromMatrix(Papa.parse(text.replace(/^﻿/, ""), { skipEmptyLines: true }).data);
	}
	if (ext === "xlsx") {
		const { readSheet } = await import("read-excel-file/browser");
		return rowsFromMatrix(await readSheet(file));
	}
	throw new Error("Unsupported file type. Upload a .xlsx or .csv file. (Old .xls files: re-save as .xlsx or .csv.)");
}
function downloadTemplate(sampleRows = []) {
	const data = [TEMPLATE_HEADERS, ...sampleRows.map((p) => TEMPLATE_HEADERS.map((h) => {
		const v = h === "alternateImages" ? (p.alternateImages || []).join("|") : p[h];
		return v === void 0 || v === null ? "" : v;
	}))];
	const csv = "﻿" + Papa.unparse(data);
	const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
	const a = document.createElement("a");
	a.href = url;
	a.download = "products-template.csv";
	a.click();
	URL.revokeObjectURL(url);
}
//#endregion
//#region src/pages/admin/ImportPanel.jsx
function ImportPanel({ currentProducts, onDone }) {
	const inputRef = useRef(null);
	const [parsed, setParsed] = useState(null);
	const [error, setError] = useState("");
	const [busy, setBusy] = useState(false);
	const [result, setResult] = useState(null);
	const choose = async (event) => {
		const file = event.target.files?.[0];
		event.target.value = "";
		if (!file) return;
		setError("");
		setResult(null);
		setParsed(null);
		try {
			const { rows, ignoredColumns } = await parseProductFile(file);
			setParsed({
				fileName: file.name,
				rows,
				ignoredColumns
			});
		} catch (e) {
			setError(e.message);
		}
	};
	const confirm = async () => {
		setBusy(true);
		setError("");
		try {
			const res = await api("/admin/products/import", {
				method: "POST",
				body: { rows: parsed.rows }
			});
			setResult(res);
			setParsed(null);
			onDone(`Import finished: ${res.added} added, ${res.updated} updated${res.skipped.length ? `, ${res.skipped.length} skipped` : ""}.`);
		} catch (e) {
			setError(e.message);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("section", {
		className: "space-y-3 rounded-xl border border-gray-200 bg-white p-5 shadow-sm",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h2", {
					className: "font-semibold text-brand-charcoal",
					children: "Import products from a spreadsheet"
				}), /* @__PURE__ */ jsxs("p", {
					className: "text-sm text-gray-600",
					children: [
						"Upload a ",
						/* @__PURE__ */ jsx("strong", { children: ".xlsx" }),
						" or ",
						/* @__PURE__ */ jsx("strong", { children: ".csv" }),
						" with a header row. Only ",
						/* @__PURE__ */ jsx("code", { children: "name" }),
						" is required. Rows whose ",
						/* @__PURE__ */ jsx("code", { children: "id" }),
						" already exists are updated; the rest are added."
					]
				})] }), /* @__PURE__ */ jsxs("button", {
					type: "button",
					className: btnGhost,
					onClick: () => downloadTemplate(currentProducts.slice(0, 3)),
					children: [/* @__PURE__ */ jsx(Download, { size: 16 }), " Download template"]
				})]
			}),
			/* @__PURE__ */ jsx("input", {
				ref: inputRef,
				type: "file",
				accept: ".xlsx,.csv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
				onChange: choose,
				className: "block w-full text-sm text-gray-600 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-yellow file:px-4 file:py-2 file:text-sm file:font-semibold file:text-brand-charcoal hover:file:bg-brand-orange"
			}),
			error && /* @__PURE__ */ jsx(Notice, { children: error }),
			parsed && /* @__PURE__ */ jsxs("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ jsxs("p", {
						className: "flex items-center gap-2 text-sm font-medium text-gray-800",
						children: [
							/* @__PURE__ */ jsx(FileSpreadsheet, { size: 16 }),
							" ",
							parsed.fileName,
							": ",
							parsed.rows.length,
							" rows ready to import"
						]
					}),
					parsed.ignoredColumns.length > 0 && /* @__PURE__ */ jsxs(Notice, {
						tone: "info",
						children: ["Ignored columns: ", parsed.ignoredColumns.join(", ")]
					}),
					/* @__PURE__ */ jsx("div", {
						className: "max-h-64 overflow-auto rounded-lg border border-gray-200",
						children: /* @__PURE__ */ jsxs("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ jsx("thead", {
								className: "sticky top-0 bg-gray-50 text-gray-500",
								children: /* @__PURE__ */ jsxs("tr", { children: [
									/* @__PURE__ */ jsx("th", {
										className: "px-3 py-2",
										children: "#"
									}),
									/* @__PURE__ */ jsx("th", {
										className: "px-3 py-2",
										children: "Name"
									}),
									/* @__PURE__ */ jsx("th", {
										className: "px-3 py-2",
										children: "Brand"
									}),
									/* @__PURE__ */ jsx("th", {
										className: "px-3 py-2",
										children: "Category"
									}),
									/* @__PURE__ */ jsx("th", {
										className: "px-3 py-2",
										children: "Price"
									}),
									/* @__PURE__ */ jsx("th", {
										className: "px-3 py-2",
										children: "ID"
									})
								] })
							}), /* @__PURE__ */ jsx("tbody", {
								className: "divide-y divide-gray-100",
								children: parsed.rows.slice(0, 50).map((r, i) => /* @__PURE__ */ jsxs("tr", {
									className: r.name ? "" : "bg-red-50",
									children: [
										/* @__PURE__ */ jsx("td", {
											className: "px-3 py-1.5 text-gray-400",
											children: i + 1
										}),
										/* @__PURE__ */ jsx("td", {
											className: "px-3 py-1.5",
											children: r.name || /* @__PURE__ */ jsx("em", {
												className: "text-red-700",
												children: "missing name (will be skipped)"
											})
										}),
										/* @__PURE__ */ jsx("td", {
											className: "px-3 py-1.5",
											children: r.brand
										}),
										/* @__PURE__ */ jsx("td", {
											className: "px-3 py-1.5",
											children: r.category
										}),
										/* @__PURE__ */ jsx("td", {
											className: "px-3 py-1.5",
											children: r.price
										}),
										/* @__PURE__ */ jsx("td", {
											className: "px-3 py-1.5 text-gray-500",
											children: r.id || "new"
										})
									]
								}, i))
							})]
						})
					}),
					parsed.rows.length > 50 && /* @__PURE__ */ jsxs("p", {
						className: "text-xs text-gray-500",
						children: [
							"Showing the first 50 of ",
							parsed.rows.length,
							" rows."
						]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ jsx("button", {
							type: "button",
							className: "inline-flex items-center justify-center gap-2 rounded-lg bg-brand-charcoal px-4 py-2 text-sm font-semibold text-white hover:bg-brand-black disabled:opacity-50 disabled:cursor-not-allowed",
							onClick: confirm,
							disabled: busy,
							children: busy ? "Importing…" : `Import ${parsed.rows.length} rows`
						}), /* @__PURE__ */ jsx("button", {
							type: "button",
							className: "inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed",
							onClick: () => setParsed(null),
							disabled: busy,
							children: "Cancel"
						})]
					})
				]
			}),
			result && result.skipped.length > 0 && /* @__PURE__ */ jsxs(Notice, {
				tone: "info",
				children: ["Skipped rows: ", result.skipped.map((s) => `#${s.row} (${s.reason})`).join(", ")]
			})
		]
	});
}
//#endregion
//#region src/pages/admin/ProductsTab.jsx
function ProductsTab() {
	const { data, error, loading, reload } = useLoad("/admin/products");
	const [editing, setEditing] = useState(null);
	const [showImport, setShowImport] = useState(false);
	const [query, setQuery] = useState("");
	const [status, setStatus] = useState("");
	const [actionError, setActionError] = useState("");
	const products = useMemo(() => data?.products ?? [], [data]);
	const shown = useMemo(() => {
		const q = query.trim().toLowerCase();
		if (!q) return products;
		return products.filter((p) => [
			p.name,
			p.brand,
			p.category,
			p.id
		].some((v) => (v || "").toLowerCase().includes(q)));
	}, [products, query]);
	const remove = async (product) => {
		if (!window.confirm(`Delete "${product.name}"? This removes it from the website.`)) return;
		setActionError("");
		try {
			await api(`/admin/products/${encodeURIComponent(product.id)}`, { method: "DELETE" });
			setStatus(`Deleted "${product.name}".`);
			reload();
		} catch (e) {
			setActionError(e.message);
		}
	};
	const loadStarter = async () => {
		if (!window.confirm(`Load the ${newProducts.length} products bundled with the site into the database? Existing items with the same id are updated.`)) return;
		setActionError("");
		try {
			const res = await api("/admin/products/import", {
				method: "POST",
				body: { rows: newProducts }
			});
			setStatus(`Starter catalogue loaded: ${res.added} added, ${res.updated} updated.`);
			reload();
		} catch (e) {
			setActionError(e.message);
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "relative min-w-[220px] flex-1",
						children: [/* @__PURE__ */ jsx(Search, {
							size: 16,
							className: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
						}), /* @__PURE__ */ jsx("input", {
							type: "search",
							value: query,
							onChange: (e) => setQuery(e.target.value),
							placeholder: "Search name, brand, category…",
							"aria-label": "Search products",
							className: `${inputClass} pl-9`
						})]
					}),
					/* @__PURE__ */ jsxs("button", {
						type: "button",
						className: btnGhost,
						onClick: () => setShowImport((v) => !v),
						children: [/* @__PURE__ */ jsx(Upload, { size: 16 }), " Import XLSX / CSV"]
					}),
					/* @__PURE__ */ jsxs("button", {
						type: "button",
						className: btnYellow,
						onClick: () => setEditing({}),
						children: [/* @__PURE__ */ jsx(Plus, { size: 16 }), " Add product"]
					})
				]
			}),
			showImport && /* @__PURE__ */ jsx(ImportPanel, {
				currentProducts: products,
				onDone: (msg) => {
					setStatus(msg);
					reload();
				}
			}),
			status && /* @__PURE__ */ jsx(Notice, {
				tone: "ok",
				children: status
			}),
			(error || actionError) && /* @__PURE__ */ jsx(Notice, { children: error || actionError }),
			!loading && products.length === 0 && !error && /* @__PURE__ */ jsxs(Empty, { children: [/* @__PURE__ */ jsx("span", {
				className: "block",
				children: "No products added yet."
			}), newProducts.length > 0 ? /* @__PURE__ */ jsxs("button", {
				type: "button",
				className: `inline-flex items-center justify-center gap-2 rounded-lg bg-brand-charcoal px-4 py-2 text-sm font-semibold text-white hover:bg-brand-black disabled:opacity-50 disabled:cursor-not-allowed mt-4`,
				onClick: loadStarter,
				children: [
					"Load the ",
					newProducts.length,
					" starter products"
				]
			}) : /* @__PURE__ */ jsx("span", {
				className: "mt-2 block text-sm",
				children: "Add your first product with the button above, or import a spreadsheet."
			})] }),
			products.length > 0 && /* @__PURE__ */ jsxs("div", {
				className: "overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm",
				children: [/* @__PURE__ */ jsxs("table", {
					className: "w-full min-w-[760px] text-left text-sm",
					children: [/* @__PURE__ */ jsx("thead", {
						className: "bg-gray-50 text-xs uppercase tracking-wide text-gray-500",
						children: /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Product"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Category"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Price (KES)"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Shown on"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3 text-right",
								children: "Actions"
							})
						] })
					}), /* @__PURE__ */ jsxs("tbody", {
						className: "divide-y divide-gray-100",
						children: [shown.map((p) => /* @__PURE__ */ jsxs("tr", {
							className: p.active ? "" : "bg-gray-50 text-gray-400",
							children: [
								/* @__PURE__ */ jsx("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ jsxs("div", {
										className: "flex items-center gap-3",
										children: [p.image ? /* @__PURE__ */ jsx("img", {
											src: assetUrl(p.image),
											alt: "",
											className: "h-12 w-12 rounded-lg border border-gray-200 object-cover",
											loading: "lazy"
										}) : /* @__PURE__ */ jsx("div", { className: "h-12 w-12 rounded-lg bg-gray-100" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
											className: "font-semibold text-brand-charcoal",
											children: p.name
										}), /* @__PURE__ */ jsxs("p", {
											className: "text-xs text-gray-500",
											children: [
												p.brand,
												" · ",
												p.id
											]
										})] })]
									})
								}),
								/* @__PURE__ */ jsx("td", {
									className: "px-4 py-3",
									children: p.category || "—"
								}),
								/* @__PURE__ */ jsxs("td", {
									className: "px-4 py-3",
									children: [p.price ? p.price.toLocaleString() : /* @__PURE__ */ jsx("span", {
										className: "text-gray-400",
										children: "On request"
									}), p.oldPrice ? /* @__PURE__ */ jsx("span", {
										className: "ml-1.5 text-xs text-gray-400 line-through",
										children: p.oldPrice.toLocaleString()
									}) : null]
								}),
								/* @__PURE__ */ jsx("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ jsxs("div", {
										className: "flex flex-wrap gap-1",
										children: [
											!p.active && /* @__PURE__ */ jsx(Badge, {
												tone: "red",
												children: "Hidden"
											}),
											p.active && p.inShop && /* @__PURE__ */ jsx(Badge, {
												tone: "green",
												children: "Shop"
											}),
											p.active && p.inCatalog && /* @__PURE__ */ jsx(Badge, {
												tone: "purple",
												children: "Catalogue"
											}),
											p.active && p.hot && /* @__PURE__ */ jsx(Badge, {
												tone: "amber",
												children: "Hot"
											})
										]
									})
								}),
								/* @__PURE__ */ jsx("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ jsxs("div", {
										className: "flex justify-end gap-2",
										children: [
											p.active && /* @__PURE__ */ jsxs("a", {
												href: crossHref(productPath(p)),
												target: "_blank",
												rel: "noopener noreferrer",
												className: "inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed",
												"aria-label": `View page for ${p.name}`,
												children: [/* @__PURE__ */ jsx(ExternalLink, { size: 14 }), " View"]
											}),
											/* @__PURE__ */ jsxs("button", {
												type: "button",
												className: "inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed",
												onClick: () => setEditing(p),
												"aria-label": `Edit ${p.name}`,
												children: [/* @__PURE__ */ jsx(Pencil, { size: 14 }), " Edit"]
											}),
											/* @__PURE__ */ jsx("button", {
												type: "button",
												className: `inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed text-red-700`,
												onClick: () => remove(p),
												"aria-label": `Delete ${p.name}`,
												children: /* @__PURE__ */ jsx(Trash2, { size: 14 })
											})
										]
									})
								})
							]
						}, p.id)), shown.length === 0 && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsxs("td", {
							colSpan: 5,
							className: "px-4 py-8 text-center text-gray-500",
							children: [
								"No products match \"",
								query,
								"\"."
							]
						}) })]
					})]
				}), /* @__PURE__ */ jsxs("p", {
					className: "border-t border-gray-100 px-4 py-2 text-xs text-gray-500",
					children: [
						shown.length,
						" of ",
						products.length,
						" products"
					]
				})]
			}),
			editing && /* @__PURE__ */ jsx(ProductForm, {
				product: editing,
				categories: [...new Set(products.map((p) => p.category).filter(Boolean))],
				onClose: () => setEditing(null),
				onSaved: (msg) => {
					setEditing(null);
					setStatus(msg);
					reload();
				}
			})
		]
	});
}
//#endregion
//#region src/pages/admin/MessagesTab.jsx
function MessagesTab() {
	const { data, error, loading, reload } = useLoad("/admin/messages");
	const [actionError, setActionError] = useState("");
	const act = async (fn) => {
		setActionError("");
		try {
			await fn();
			reload();
		} catch (e) {
			setActionError(e.message);
		}
	};
	const messages = data?.messages ?? [];
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsx("p", {
				className: "text-sm text-gray-600",
				children: "Contact form submissions from the website. Every submission is also opened in WhatsApp for the visitor to send."
			}),
			(error || actionError) && /* @__PURE__ */ jsx(Notice, { children: error || actionError }),
			!loading && messages.length === 0 && !error && /* @__PURE__ */ jsx(Empty, { children: "No messages yet." }),
			/* @__PURE__ */ jsx("ul", {
				className: "space-y-3",
				children: messages.map((m) => /* @__PURE__ */ jsxs("li", {
					className: `rounded-xl border bg-white p-5 shadow-sm ${m.handled === "1" || m.handled === 1 ? "border-gray-200 opacity-75" : "border-brand-yellow"}`,
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap items-start justify-between gap-3",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
								className: "font-semibold text-brand-charcoal",
								children: m.name
							}), /* @__PURE__ */ jsxs("p", {
								className: "text-sm text-gray-600",
								children: [
									/* @__PURE__ */ jsx("a", {
										href: `tel:${m.phone}`,
										className: "hover:underline",
										children: m.phone
									}),
									" · ",
									formatDate(m.created_at)
								]
							})] }), /* @__PURE__ */ jsxs("div", {
								className: "flex items-center gap-2",
								children: [
									Number(m.handled) ? /* @__PURE__ */ jsx(Badge, {
										tone: "green",
										children: "Handled"
									}) : /* @__PURE__ */ jsx(Badge, {
										tone: "amber",
										children: "New"
									}),
									/* @__PURE__ */ jsxs("button", {
										type: "button",
										className: btnGhost,
										onClick: () => act(() => api(`/admin/messages/${m.id}`, {
											method: "PATCH",
											body: { handled: !Number(m.handled) }
										})),
										children: [
											/* @__PURE__ */ jsx(Check, { size: 14 }),
											" ",
											Number(m.handled) ? "Mark new" : "Mark handled"
										]
									}),
									/* @__PURE__ */ jsx("button", {
										type: "button",
										className: `${btnGhost} text-red-700`,
										"aria-label": `Delete message from ${m.name}`,
										onClick: () => window.confirm("Delete this message?") && act(() => api(`/admin/messages/${m.id}`, { method: "DELETE" })),
										children: /* @__PURE__ */ jsx(Trash2, { size: 14 })
									})
								]
							})]
						}),
						/* @__PURE__ */ jsxs("dl", {
							className: "mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2",
							children: [m.product && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("dt", {
								className: "sr-only",
								children: "Product"
							}), /* @__PURE__ */ jsxs("dd", { children: [
								/* @__PURE__ */ jsx("span", {
									className: "text-gray-500",
									children: "Product:"
								}),
								" ",
								m.product
							] })] }), m.budget && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("dt", {
								className: "sr-only",
								children: "Budget"
							}), /* @__PURE__ */ jsxs("dd", { children: [
								/* @__PURE__ */ jsx("span", {
									className: "text-gray-500",
									children: "Budget:"
								}),
								" ",
								m.budget
							] })] })]
						}),
						m.message && /* @__PURE__ */ jsx("p", {
							className: "mt-2 whitespace-pre-wrap text-sm text-gray-800",
							children: m.message
						})
					]
				}, m.id))
			})
		]
	});
}
//#endregion
//#region src/pages/admin/ClicksTab.jsx
function ClicksTab() {
	const { data, error, loading } = useLoad("/admin/clicks");
	if (error) return /* @__PURE__ */ jsx(Notice, { children: error });
	if (loading && !data) return /* @__PURE__ */ jsx("p", {
		className: "text-gray-500",
		children: "Loading…"
	});
	const { top, recent, totals } = data;
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ jsxs("p", {
				className: "text-sm text-gray-600",
				children: [
					"Every time a visitor presses a WhatsApp button or link. ",
					/* @__PURE__ */ jsx("strong", { children: totals.total }),
					" clicks in total, ",
					/* @__PURE__ */ jsx("strong", { children: totals.last7 }),
					" in the last 7 days."
				]
			}),
			/* @__PURE__ */ jsxs("section", { children: [/* @__PURE__ */ jsx("h2", {
				className: "mb-2 font-semibold text-brand-charcoal",
				children: "Most clicked products"
			}), top.length === 0 ? /* @__PURE__ */ jsx(Empty, { children: "No product clicks yet." }) : /* @__PURE__ */ jsx("div", {
				className: "overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm",
				children: /* @__PURE__ */ jsxs("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ jsx("thead", {
						className: "bg-gray-50 text-xs uppercase tracking-wide text-gray-500",
						children: /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Product"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Clicks"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Last click"
							})
						] })
					}), /* @__PURE__ */ jsx("tbody", {
						className: "divide-y divide-gray-100",
						children: top.map((row) => /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-3 font-medium text-brand-charcoal",
								children: row.name || row.product_id
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-3",
								children: row.clicks
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-3 text-gray-600",
								children: formatDate(row.last_click)
							})
						] }, row.product_id))
					})]
				})
			})] }),
			/* @__PURE__ */ jsxs("section", { children: [/* @__PURE__ */ jsx("h2", {
				className: "mb-2 font-semibold text-brand-charcoal",
				children: "Recent clicks"
			}), recent.length === 0 ? /* @__PURE__ */ jsx(Empty, { children: "No clicks recorded yet." }) : /* @__PURE__ */ jsx("div", {
				className: "overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm",
				children: /* @__PURE__ */ jsxs("table", {
					className: "w-full min-w-[640px] text-left text-sm",
					children: [/* @__PURE__ */ jsx("thead", {
						className: "bg-gray-50 text-xs uppercase tracking-wide text-gray-500",
						children: /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "When"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Button"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Product"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Page"
							})
						] })
					}), /* @__PURE__ */ jsx("tbody", {
						className: "divide-y divide-gray-100",
						children: recent.map((row) => /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("td", {
								className: "whitespace-nowrap px-4 py-2 text-gray-600",
								children: formatDate(row.created_at)
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-2",
								children: row.label || "—"
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-2",
								children: row.product_name || row.product_id || "—"
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-2 text-gray-600",
								children: row.page
							})
						] }, row.id))
					})]
				})
			})] })
		]
	});
}
//#endregion
//#region src/pages/admin/OrdersTab.jsx
var STATUSES = [
	{
		value: "pending",
		label: "Pending",
		tone: "amber"
	},
	{
		value: "dispatched",
		label: "Dispatched",
		tone: "green"
	},
	{
		value: "not_dispatched",
		label: "Not dispatched",
		tone: "red"
	},
	{
		value: "cancelled",
		label: "Cancelled",
		tone: "gray"
	}
];
function OrderCard({ order, onSaved, onError }) {
	const [form, setForm] = useState({
		status: order.status,
		note: order.note || "",
		customerName: order.customer_name || "",
		customerPhone: order.customer_phone || ""
	});
	const [busy, setBusy] = useState(false);
	const dirty = form.status !== order.status || form.note !== (order.note || "") || form.customerName !== (order.customer_name || "") || form.customerPhone !== (order.customer_phone || "");
	const tone = STATUSES.find((s) => s.value === order.status)?.tone;
	const save = async (patch = {}) => {
		setBusy(true);
		onError("");
		try {
			await api(`/admin/orders/${order.id}`, {
				method: "PATCH",
				body: {
					...form,
					...patch
				}
			});
			onSaved();
		} catch (e) {
			onError(e.message);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("li", {
		className: "rounded-xl border border-gray-200 bg-white p-5 shadow-sm",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
					className: "font-semibold text-brand-charcoal",
					children: order.product_name
				}), /* @__PURE__ */ jsxs("p", {
					className: "text-sm text-gray-600",
					children: [
						"Order #",
						order.id,
						" · clicked ",
						formatDate(order.created_at),
						order.user_id ? " · member account" : " · guest",
						order.cart_ref ? ` · cart ${order.cart_ref}` : ""
					]
				})] }), /* @__PURE__ */ jsx(Badge, {
					tone,
					children: STATUSES.find((s) => s.value === order.status)?.label
				})]
			}),
			/* @__PURE__ */ jsxs("dl", {
				className: "mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-[auto_1fr]",
				children: [
					/* @__PURE__ */ jsx("dt", {
						className: "font-medium text-gray-700",
						children: "Quantity"
					}),
					/* @__PURE__ */ jsx("dd", {
						className: "text-brand-charcoal",
						children: /* @__PURE__ */ jsx("strong", { children: order.quantity ?? 1 })
					}),
					/* @__PURE__ */ jsx("dt", {
						className: "font-medium text-gray-700",
						children: "Deliver to"
					}),
					/* @__PURE__ */ jsx("dd", {
						className: "whitespace-pre-wrap",
						children: order.delivery_address || /* @__PURE__ */ jsx("span", {
							className: "text-gray-500",
							children: "Not given. Confirm on WhatsApp."
						})
					})
				]
			}),
			order.offers_applied && /* @__PURE__ */ jsxs("div", {
				className: "mt-3 rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-900",
				children: [/* @__PURE__ */ jsxs("p", {
					className: "font-semibold",
					children: ["Member offers applied", order.final_price != null ? `: KES ${Number(order.final_price).toLocaleString()} each${(order.quantity ?? 1) > 1 ? `, KES ${(Number(order.final_price) * order.quantity).toLocaleString()} for ${order.quantity}` : ""}` : ""]
				}), /* @__PURE__ */ jsx("p", {
					className: "whitespace-pre-wrap",
					children: order.offers_applied
				})]
			}),
			order.message && /* @__PURE__ */ jsxs("details", {
				className: "mt-2 text-sm text-gray-600",
				children: [/* @__PURE__ */ jsx("summary", {
					className: "cursor-pointer text-gray-500",
					children: "WhatsApp message sent"
				}), /* @__PURE__ */ jsx("p", {
					className: "mt-1 whitespace-pre-wrap",
					children: order.message
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ jsxs("label", {
						className: "text-sm font-medium text-gray-700",
						children: ["Customer name", /* @__PURE__ */ jsx("input", {
							className: `${inputClass} mt-1`,
							value: form.customerName,
							onChange: (e) => setForm({
								...form,
								customerName: e.target.value
							})
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "text-sm font-medium text-gray-700",
						children: ["Customer phone", /* @__PURE__ */ jsx("input", {
							className: `${inputClass} mt-1`,
							value: form.customerPhone,
							onChange: (e) => setForm({
								...form,
								customerPhone: e.target.value
							})
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "text-sm font-medium text-gray-700 sm:col-span-2",
						children: ["Note (payment, courier, reason not dispatched…)", /* @__PURE__ */ jsx("input", {
							className: `${inputClass} mt-1`,
							value: form.note,
							onChange: (e) => setForm({
								...form,
								note: e.target.value
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-4 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ jsx("span", {
						className: "text-sm font-medium text-gray-700",
						children: "Did this order go out?"
					}),
					STATUSES.map((s) => /* @__PURE__ */ jsx("button", {
						type: "button",
						disabled: busy,
						"aria-pressed": form.status === s.value,
						onClick: () => {
							setForm({
								...form,
								status: s.value
							});
							save({ status: s.value });
						},
						className: `rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors disabled:opacity-50 ${form.status === s.value ? "border-brand-charcoal bg-brand-charcoal text-white" : "border-gray-300 bg-white text-gray-700 hover:bg-gray-100"}`,
						children: s.label
					}, s.value)),
					/* @__PURE__ */ jsx("span", { className: "flex-1" }),
					dirty && /* @__PURE__ */ jsx("button", {
						type: "button",
						disabled: busy,
						className: `inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed border-brand-yellow`,
						onClick: () => save(),
						children: "Save changes"
					}),
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: `${btnGhost} text-red-700`,
						"aria-label": `Delete order ${order.id}`,
						onClick: async () => {
							if (!window.confirm("Delete this order record?")) return;
							try {
								await api(`/admin/orders/${order.id}`, { method: "DELETE" });
								onSaved();
							} catch (e) {
								onError(e.message);
							}
						},
						children: /* @__PURE__ */ jsx(Trash2, { size: 14 })
					})
				]
			})
		]
	});
}
function OrdersTab() {
	const { data, error, loading, reload } = useLoad("/admin/orders");
	const [filter, setFilter] = useState("all");
	const [actionError, setActionError] = useState("");
	const orders = useMemo(() => data?.orders ?? [], [data]);
	const counts = useMemo(() => {
		const c = { all: orders.length };
		STATUSES.forEach((s) => {
			c[s.value] = orders.filter((o) => o.status === s.value).length;
		});
		return c;
	}, [orders]);
	const shown = filter === "all" ? orders : orders.filter((o) => o.status === filter);
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsxs(Notice, {
				tone: "info",
				children: [
					"An order is logged when a visitor presses ",
					/* @__PURE__ */ jsx("strong", { children: "Order via WhatsApp" }),
					". Their payment and delivery are arranged in WhatsApp, which this site cannot see, so record here whether each order was actually dispatched."
				]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "flex flex-wrap gap-2",
				role: "group",
				"aria-label": "Filter orders",
				children: [{
					value: "all",
					label: "All"
				}, ...STATUSES].map((s) => /* @__PURE__ */ jsxs("button", {
					type: "button",
					"aria-pressed": filter === s.value,
					onClick: () => setFilter(s.value),
					className: `rounded-lg px-3 py-1.5 text-sm font-medium ${filter === s.value ? "bg-brand-yellow text-brand-charcoal" : "bg-gray-200 text-gray-700 hover:bg-gray-300"}`,
					children: [
						s.label,
						" (",
						counts[s.value] ?? 0,
						")"
					]
				}, s.value))
			}),
			(error || actionError) && /* @__PURE__ */ jsx(Notice, { children: error || actionError }),
			!loading && shown.length === 0 && !error && /* @__PURE__ */ jsx(Empty, { children: "No orders in this view." }),
			/* @__PURE__ */ jsx("ul", {
				className: "space-y-3",
				children: shown.map((o) => /* @__PURE__ */ jsx(OrderCard, {
					order: o,
					onSaved: reload,
					onError: setActionError
				}, `${o.id}-${o.updated_at}`))
			})
		]
	});
}
//#endregion
//#region src/pages/admin/OffersTab.jsx
var TYPES = [
	{
		value: "discount",
		label: "Member discount",
		icon: BadgePercent,
		help: "Applied automatically as a member price, and offered at checkout."
	},
	{
		value: "coupon",
		label: "Coupon code",
		icon: Ticket,
		help: "Members see the code and can pick or type it at checkout."
	},
	{
		value: "delivery",
		label: "Delivery offer",
		icon: Truck,
		help: "e.g. free delivery in town. Members choose it at checkout."
	}
];
var blank = {
	type: "discount",
	title: "",
	description: "",
	code: "",
	percentOff: "",
	amountOff: "",
	minPrice: "",
	category: "",
	startsOn: "",
	endsOn: "",
	active: true
};
function OfferForm({ offer, onClose, onSaved }) {
	const isNew = !offer.id;
	const [form, setForm] = useState({
		...blank,
		...Object.fromEntries(Object.entries(offer).map(([k, v]) => [k, v ?? ""]))
	});
	const [error, setError] = useState("");
	const [busy, setBusy] = useState(false);
	const set = (key) => (e) => setForm((f) => ({
		...f,
		[key]: e.target.type === "checkbox" ? e.target.checked : e.target.value
	}));
	const type = TYPES.find((t) => t.value === form.type);
	const submit = async (event) => {
		event.preventDefault();
		setBusy(true);
		setError("");
		try {
			if (isNew) await api("/admin/offers", {
				method: "POST",
				body: form
			});
			else await api(`/admin/offers/${offer.id}`, {
				method: "PUT",
				body: form
			});
			onSaved(isNew ? "Offer created." : "Offer saved.");
		} catch (e) {
			setError(e.message);
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsx("div", {
		className: "fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto bg-black/60 p-4",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": isNew ? "New offer" : "Edit offer",
		children: /* @__PURE__ */ jsxs("form", {
			onSubmit: submit,
			className: "my-8 w-full max-w-xl rounded-2xl bg-white shadow-2xl",
			children: [
				/* @__PURE__ */ jsx("div", {
					className: "border-b border-gray-200 px-6 py-4",
					children: /* @__PURE__ */ jsx("h2", {
						className: "text-lg font-bold text-brand-charcoal",
						children: isNew ? "New offer" : "Edit offer"
					})
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "grid gap-4 px-6 py-5 sm:grid-cols-2",
					children: [
						error && /* @__PURE__ */ jsx("div", {
							className: "sm:col-span-2",
							children: /* @__PURE__ */ jsx(Notice, { children: error })
						}),
						/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700 sm:col-span-2",
							children: [
								"Type",
								/* @__PURE__ */ jsx("select", {
									className: `${inputClass} mt-1`,
									value: form.type,
									onChange: set("type"),
									children: TYPES.map((t) => /* @__PURE__ */ jsx("option", {
										value: t.value,
										children: t.label
									}, t.value))
								}),
								/* @__PURE__ */ jsx("span", {
									className: "mt-1 block text-xs font-normal text-gray-500",
									children: type.help
								})
							]
						}),
						/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700 sm:col-span-2",
							children: ["Title *", /* @__PURE__ */ jsx("input", {
								required: true,
								className: `${inputClass} mt-1`,
								value: form.title,
								onChange: set("title"),
								placeholder: form.type === "delivery" ? "Free delivery in town" : "10% off for members"
							})]
						}),
						/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700 sm:col-span-2",
							children: ["Details shown to members", /* @__PURE__ */ jsx("textarea", {
								rows: 2,
								className: `${inputClass} mt-1`,
								value: form.description,
								onChange: set("description")
							})]
						}),
						form.type === "coupon" && /* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700 sm:col-span-2",
							children: ["Coupon code *", /* @__PURE__ */ jsx("input", {
								required: true,
								className: `w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-brand-yellow focus:border-transparent bg-white mt-1 font-mono uppercase`,
								value: form.code,
								onChange: set("code"),
								placeholder: "WELCOME500"
							})]
						}),
						form.type !== "delivery" && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700",
							children: ["Percent off (%)", /* @__PURE__ */ jsx("input", {
								type: "number",
								min: "0",
								max: "100",
								step: "0.01",
								className: `w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-brand-yellow focus:border-transparent bg-white mt-1`,
								value: form.percentOff,
								onChange: set("percentOff")
							})]
						}), /* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700",
							children: [
								"Or amount off (KES)",
								/* @__PURE__ */ jsx("input", {
									type: "number",
									min: "0",
									step: "0.01",
									className: `w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-brand-yellow focus:border-transparent bg-white mt-1`,
									value: form.amountOff,
									onChange: set("amountOff")
								}),
								/* @__PURE__ */ jsx("span", {
									className: "mt-1 block text-xs font-normal text-gray-500",
									children: "If both are set, the bigger saving applies."
								})
							]
						})] }),
						/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700",
							children: ["Minimum product price (KES)", /* @__PURE__ */ jsx("input", {
								type: "number",
								min: "0",
								step: "0.01",
								className: `${inputClass} mt-1`,
								value: form.minPrice,
								onChange: set("minPrice")
							})]
						}),
						/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700",
							children: ["Only for category", /* @__PURE__ */ jsx("input", {
								className: `${inputClass} mt-1`,
								value: form.category,
								onChange: set("category"),
								placeholder: "All categories"
							})]
						}),
						/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700",
							children: ["Starts on", /* @__PURE__ */ jsx("input", {
								type: "date",
								className: `${inputClass} mt-1`,
								value: form.startsOn,
								onChange: set("startsOn")
							})]
						}),
						/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium text-gray-700",
							children: ["Ends on", /* @__PURE__ */ jsx("input", {
								type: "date",
								className: `${inputClass} mt-1`,
								value: form.endsOn,
								onChange: set("endsOn")
							})]
						}),
						/* @__PURE__ */ jsxs("label", {
							className: "inline-flex items-center gap-2 text-sm text-gray-700 sm:col-span-2",
							children: [/* @__PURE__ */ jsx("input", {
								type: "checkbox",
								checked: form.active,
								onChange: set("active")
							}), " Active"]
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex justify-end gap-3 border-t border-gray-200 px-6 py-4",
					children: [/* @__PURE__ */ jsx("button", {
						type: "button",
						className: btnGhost,
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ jsx("button", {
						type: "submit",
						className: btnPrimary,
						disabled: busy,
						children: busy ? "Saving…" : "Save offer"
					})]
				})
			]
		})
	});
}
function OffersTab() {
	const { data, error, loading, reload } = useLoad("/admin/offers");
	const [editing, setEditing] = useState(null);
	const [status, setStatus] = useState("");
	const [actionError, setActionError] = useState("");
	const offers = data?.offers ?? [];
	const remove = async (offer) => {
		if (!window.confirm(`Delete "${offer.title}"?`)) return;
		setActionError("");
		try {
			await api(`/admin/offers/${offer.id}`, { method: "DELETE" });
			reload();
		} catch (e) {
			setActionError(e.message);
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ jsxs("p", {
					className: "max-w-2xl text-sm text-gray-600",
					children: [
						"Offers are visible to signed-in members only. At checkout a member picks one discount ",
						/* @__PURE__ */ jsx("em", { children: "or" }),
						" coupon (the cheapest, they don’t stack) and optionally one delivery offer, before the order is sent to WhatsApp."
					]
				}), /* @__PURE__ */ jsxs("button", {
					type: "button",
					className: btnYellow,
					onClick: () => setEditing({}),
					children: [/* @__PURE__ */ jsx(Plus, { size: 16 }), " New offer"]
				})]
			}),
			status && /* @__PURE__ */ jsx(Notice, {
				tone: "ok",
				children: status
			}),
			(error || actionError) && /* @__PURE__ */ jsx(Notice, { children: error || actionError }),
			!loading && offers.length === 0 && !error && /* @__PURE__ */ jsx(Empty, { children: "No offers yet. Create a discount, coupon or delivery offer to reward members." }),
			/* @__PURE__ */ jsx("ul", {
				className: "grid gap-3 md:grid-cols-2",
				children: offers.map((o) => {
					const meta = TYPES.find((t) => t.value === o.type);
					const Icon = meta.icon;
					return /* @__PURE__ */ jsxs("li", {
						className: `rounded-xl border bg-white p-5 shadow-sm ${o.active ? "border-gray-200" : "border-gray-200 opacity-60"}`,
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ jsx(Icon, {
										size: 20,
										className: "mt-0.5 text-brand-charcoal",
										"aria-hidden": "true"
									}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
										className: "font-semibold text-brand-charcoal",
										children: o.title
									}), /* @__PURE__ */ jsxs("p", {
										className: "text-sm text-gray-600",
										children: [
											meta.label,
											offerLabel(o) ? ` · ${offerLabel(o)}` : "",
											o.code && /* @__PURE__ */ jsx("span", {
												className: "ml-2 rounded bg-gray-100 px-1.5 py-0.5 font-mono text-xs",
												children: o.code
											})
										]
									})] })]
								}), /* @__PURE__ */ jsx(Badge, {
									tone: o.active ? "green" : "gray",
									children: o.active ? "Active" : "Off"
								})]
							}),
							o.description && /* @__PURE__ */ jsx("p", {
								className: "mt-2 text-sm text-gray-700",
								children: o.description
							}),
							/* @__PURE__ */ jsx("p", {
								className: "mt-2 text-xs text-gray-500",
								children: [
									o.category && `Category: ${o.category}`,
									o.minPrice != null && `Min price KES ${o.minPrice.toLocaleString()}`,
									o.startsOn && `From ${o.startsOn}`,
									o.endsOn && `Until ${o.endsOn}`
								].filter(Boolean).join(" · ") || "All products, no dates"
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-3 flex gap-2",
								children: [/* @__PURE__ */ jsxs("button", {
									type: "button",
									className: btnGhost,
									onClick: () => setEditing(o),
									children: [/* @__PURE__ */ jsx(Pencil, { size: 14 }), " Edit"]
								}), /* @__PURE__ */ jsx("button", {
									type: "button",
									className: `${btnGhost} text-red-700`,
									"aria-label": `Delete ${o.title}`,
									onClick: () => remove(o),
									children: /* @__PURE__ */ jsx(Trash2, { size: 14 })
								})]
							})
						]
					}, o.id);
				})
			}),
			editing && /* @__PURE__ */ jsx(OfferForm, {
				offer: editing,
				onClose: () => setEditing(null),
				onSaved: (msg) => {
					setEditing(null);
					setStatus(msg);
					reload();
				}
			})
		]
	});
}
//#endregion
//#region src/pages/admin/CustomersTab.jsx
function CustomersTab() {
	const { data, error, loading } = useLoad("/admin/customers");
	const customers = data?.customers ?? [];
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsx("p", {
				className: "text-sm text-gray-600",
				children: "Customers who created an account on the site."
			}),
			error && /* @__PURE__ */ jsx(Notice, { children: error }),
			!loading && customers.length === 0 && !error && /* @__PURE__ */ jsx(Empty, { children: "No customer accounts yet." }),
			customers.length > 0 && /* @__PURE__ */ jsx("div", {
				className: "overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm",
				children: /* @__PURE__ */ jsxs("table", {
					className: "w-full min-w-[560px] text-left text-sm",
					children: [/* @__PURE__ */ jsx("thead", {
						className: "bg-gray-50 text-xs uppercase tracking-wide text-gray-500",
						children: /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Name"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Username"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Phone"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Orders"
							}),
							/* @__PURE__ */ jsx("th", {
								className: "px-4 py-3",
								children: "Joined"
							})
						] })
					}), /* @__PURE__ */ jsx("tbody", {
						className: "divide-y divide-gray-100",
						children: customers.map((c) => /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-3 font-medium text-brand-charcoal",
								children: c.name
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-3",
								children: c.username
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ jsx("a", {
									href: `tel:${c.phone}`,
									className: "hover:underline",
									children: c.phone
								})
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-3",
								children: c.orders
							}),
							/* @__PURE__ */ jsx("td", {
								className: "px-4 py-3 text-gray-600",
								children: formatDate(c.created_at)
							})
						] }, c.id))
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/pages/admin/CredentialsForm.jsx
function CredentialsForm({ forced = false }) {
	const { user, setUser } = useAuth();
	const [form, setForm] = useState({
		currentPassword: "",
		username: forced ? "" : user.username,
		newPassword: "",
		confirm: ""
	});
	const [error, setError] = useState("");
	const [done, setDone] = useState(false);
	const [busy, setBusy] = useState(false);
	const set = (key) => (e) => setForm((f) => ({
		...f,
		[key]: e.target.value
	}));
	const submit = async (event) => {
		event.preventDefault();
		setError("");
		setDone(false);
		if (form.newPassword !== form.confirm) {
			setError("The new passwords do not match.");
			return;
		}
		setBusy(true);
		try {
			const res = await api("/admin/credentials", {
				method: "POST",
				body: {
					currentPassword: form.currentPassword,
					username: form.username,
					newPassword: form.newPassword
				}
			});
			setUser({
				...user,
				username: res.username,
				mustChange: false
			});
			setForm((f) => ({
				...f,
				currentPassword: "",
				newPassword: "",
				confirm: ""
			}));
			setDone(true);
		} catch (e) {
			setError(e.message);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		className: "w-full max-w-md space-y-4 rounded-2xl bg-white p-8 shadow-lg",
		children: [
			/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h2", {
				className: "text-xl font-bold text-brand-charcoal",
				children: forced ? "Set your admin username and password" : "Admin username and password"
			}), forced && /* @__PURE__ */ jsx("p", {
				className: "mt-1 text-sm text-gray-600",
				children: "You signed in with the default credentials. Choose your own before continuing. This is required."
			})] }),
			error && /* @__PURE__ */ jsx(Notice, { children: error }),
			done && /* @__PURE__ */ jsx(Notice, {
				tone: "ok",
				children: "Saved. Use the new details next time you sign in."
			}),
			/* @__PURE__ */ jsxs("label", {
				className: "block text-sm font-medium text-gray-700",
				children: ["Current password", /* @__PURE__ */ jsx("input", {
					type: "password",
					required: true,
					autoComplete: "current-password",
					className: `${inputClass} mt-1`,
					value: form.currentPassword,
					onChange: set("currentPassword")
				})]
			}),
			/* @__PURE__ */ jsxs("label", {
				className: "block text-sm font-medium text-gray-700",
				children: ["New username", /* @__PURE__ */ jsx("input", {
					required: true,
					autoComplete: "username",
					className: `${inputClass} mt-1`,
					value: form.username,
					onChange: set("username")
				})]
			}),
			/* @__PURE__ */ jsxs("label", {
				className: "block text-sm font-medium text-gray-700",
				children: [
					"New password ",
					/* @__PURE__ */ jsx("span", {
						className: "font-normal text-gray-500",
						children: "(at least 8 characters)"
					}),
					/* @__PURE__ */ jsx("input", {
						type: "password",
						required: true,
						minLength: 8,
						autoComplete: "new-password",
						className: `${inputClass} mt-1`,
						value: form.newPassword,
						onChange: set("newPassword")
					})
				]
			}),
			/* @__PURE__ */ jsxs("label", {
				className: "block text-sm font-medium text-gray-700",
				children: ["Confirm new password", /* @__PURE__ */ jsx("input", {
					type: "password",
					required: true,
					minLength: 8,
					autoComplete: "new-password",
					className: `${inputClass} mt-1`,
					value: form.confirm,
					onChange: set("confirm")
				})]
			}),
			/* @__PURE__ */ jsx("button", {
				type: "submit",
				disabled: busy,
				className: `${btnPrimary} w-full`,
				children: busy ? "Saving…" : "Save username and password"
			})
		]
	});
}
//#endregion
//#region src/pages/admin/SettingsTab.jsx
var platforms = [
	"facebook",
	"x",
	"linkedin",
	"tiktok",
	"instagram",
	"youtube",
	"whatsapp",
	"link"
];
var clone = (value) => JSON.parse(JSON.stringify(value));
function SettingsTab() {
	const [form, setForm] = useState(() => clone(DEFAULT_SETTINGS));
	const [loading, setLoading] = useState(true);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState("");
	const [saved, setSaved] = useState(false);
	useEffect(() => {
		let active = true;
		api("/settings").then((data) => {
			if (active) setForm({
				...clone(DEFAULT_SETTINGS),
				...data,
				contact: {
					...DEFAULT_SETTINGS.contact,
					...data.contact
				},
				announcement: {
					...DEFAULT_SETTINGS.announcement,
					...data.announcement
				}
			});
		}).catch((e) => {
			if (active) setError(e.message);
		}).finally(() => {
			if (active) setLoading(false);
		});
		return () => {
			active = false;
		};
	}, []);
	const update = (section, key, value) => {
		setSaved(false);
		setForm((current) => ({
			...current,
			[section]: {
				...current[section],
				[key]: value
			}
		}));
	};
	const updateRow = (section, index, key, value) => {
		setSaved(false);
		setForm((current) => ({
			...current,
			[section]: current[section].map((row, i) => i === index ? {
				...row,
				[key]: value
			} : row)
		}));
	};
	const submit = async (event) => {
		event.preventDefault();
		setBusy(true);
		setError("");
		setSaved(false);
		try {
			const result = await api("/admin/settings", {
				method: "PUT",
				body: form
			});
			setForm(result);
			setSiteSettings(result);
			setSaved(true);
		} catch (e) {
			setError(e.message);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ jsx(CredentialsForm, {}), /* @__PURE__ */ jsxs("form", {
			onSubmit: submit,
			className: "max-w-4xl space-y-6 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm sm:p-8",
			children: [
				/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h2", {
					className: "text-xl font-bold text-brand-charcoal",
					children: "Website details"
				}), /* @__PURE__ */ jsx("p", {
					className: "mt-1 text-sm text-gray-600",
					children: "These details appear across the public website and in customer contact links."
				})] }),
				error && /* @__PURE__ */ jsx(Notice, { children: error }),
				saved && /* @__PURE__ */ jsx(Notice, {
					tone: "ok",
					children: "Website settings saved."
				}),
				loading ? /* @__PURE__ */ jsx("p", {
					className: "text-sm text-gray-500",
					children: "Loading website settings…"
				}) : /* @__PURE__ */ jsxs(Fragment, { children: [
					/* @__PURE__ */ jsxs("section", {
						className: "space-y-4",
						children: [/* @__PURE__ */ jsx("h3", {
							className: "font-semibold text-brand-charcoal",
							children: "Contact information"
						}), /* @__PURE__ */ jsxs("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ jsxs("label", {
									className: "text-sm font-medium text-gray-700",
									children: ["Main email", /* @__PURE__ */ jsx("input", {
										type: "email",
										required: true,
										className: `${inputClass} mt-1`,
										value: form.contact.email,
										onChange: (e) => update("contact", "email", e.target.value)
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "text-sm font-medium text-gray-700",
									children: ["Additional email", /* @__PURE__ */ jsx("input", {
										type: "email",
										className: `${inputClass} mt-1`,
										value: form.contact.email2,
										onChange: (e) => update("contact", "email2", e.target.value)
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "text-sm font-medium text-gray-700",
									children: [
										"WhatsApp number (include country code)",
										/* @__PURE__ */ jsx("input", {
											type: "tel",
											required: true,
											className: `${inputClass} mt-1`,
											value: form.contact.whatsapp,
											onChange: (e) => update("contact", "whatsapp", e.target.value)
										}),
										/* @__PURE__ */ jsx("span", {
											className: "mt-1 block text-xs font-normal text-gray-500",
											children: "For Kenya, use 254 followed by the number, e.g. 254700000000."
										})
									]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "text-sm font-medium text-gray-700",
									children: ["Mobile phone", /* @__PURE__ */ jsx("input", {
										type: "tel",
										className: `${inputClass} mt-1`,
										value: form.contact.mobilePhone,
										onChange: (e) => update("contact", "mobilePhone", e.target.value)
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "text-sm font-medium text-gray-700",
									children: ["Office phone", /* @__PURE__ */ jsx("input", {
										type: "tel",
										className: `${inputClass} mt-1`,
										value: form.contact.officePhone,
										onChange: (e) => update("contact", "officePhone", e.target.value)
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "text-sm font-medium text-gray-700 sm:col-span-2",
									children: ["Address", /* @__PURE__ */ jsx("textarea", {
										rows: 3,
										className: `${inputClass} mt-1`,
										value: form.contact.address,
										onChange: (e) => update("contact", "address", e.target.value)
									})]
								})
							]
						})]
					}),
					/* @__PURE__ */ jsxs("section", {
						className: "space-y-4 border-t border-gray-200 pt-5",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
								className: "font-semibold text-brand-charcoal",
								children: "Opening hours"
							}), /* @__PURE__ */ jsx("p", {
								className: "text-xs text-gray-500",
								children: "Add up to 8 rows."
							})] }), /* @__PURE__ */ jsxs("button", {
								type: "button",
								className: btnGhost,
								disabled: form.hours.length >= 8,
								onClick: () => {
									setSaved(false);
									setForm((f) => ({
										...f,
										hours: [...f.hours, {
											days: "",
											time: ""
										}]
									}));
								},
								children: [/* @__PURE__ */ jsx(Plus, { size: 15 }), " Add hours"]
							})]
						}), form.hours.map((row, index) => /* @__PURE__ */ jsxs("div", {
							className: "grid gap-2 sm:grid-cols-[1fr_1fr_auto]",
							children: [
								/* @__PURE__ */ jsxs("label", {
									className: "text-xs font-medium text-gray-600",
									children: ["Days", /* @__PURE__ */ jsx("input", {
										className: `${inputClass} mt-1`,
										value: row.days,
										onChange: (e) => updateRow("hours", index, "days", e.target.value),
										placeholder: "Monday - Friday"
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "text-xs font-medium text-gray-600",
									children: ["Hours", /* @__PURE__ */ jsx("input", {
										className: `${inputClass} mt-1`,
										value: row.time,
										onChange: (e) => updateRow("hours", index, "time", e.target.value),
										placeholder: "8:00 AM - 5:00 PM"
									})]
								}),
								/* @__PURE__ */ jsx("button", {
									type: "button",
									className: `${btnGhost} self-end text-red-700`,
									"aria-label": "Remove opening hours row",
									onClick: () => {
										setSaved(false);
										setForm((f) => ({
											...f,
											hours: f.hours.filter((_, i) => i !== index)
										}));
									},
									children: /* @__PURE__ */ jsx(Trash2, { size: 15 })
								})
							]
						}, index))]
					}),
					/* @__PURE__ */ jsxs("section", {
						className: "space-y-4 border-t border-gray-200 pt-5",
						children: [
							/* @__PURE__ */ jsx("h3", {
								className: "font-semibold text-brand-charcoal",
								children: "Announcement bar"
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "inline-flex items-center gap-2 text-sm text-gray-700",
								children: [/* @__PURE__ */ jsx("input", {
									type: "checkbox",
									checked: form.announcement.enabled,
									onChange: (e) => update("announcement", "enabled", e.target.checked)
								}), " Show announcement across the site"]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ jsxs("label", {
									className: "text-sm font-medium text-gray-700 sm:col-span-2",
									children: ["Message", /* @__PURE__ */ jsx("input", {
										maxLength: 200,
										className: `${inputClass} mt-1`,
										value: form.announcement.text,
										onChange: (e) => update("announcement", "text", e.target.value)
									})]
								}), /* @__PURE__ */ jsxs("label", {
									className: "text-sm font-medium text-gray-700 sm:col-span-2",
									children: [
										"Optional link",
										/* @__PURE__ */ jsx("input", {
											className: `${inputClass} mt-1`,
											value: form.announcement.link,
											onChange: (e) => update("announcement", "link", e.target.value),
											placeholder: "/shop or https://example.com"
										}),
										/* @__PURE__ */ jsx("span", {
											className: "mt-1 block text-xs font-normal text-gray-500",
											children: "Use a site path beginning with / or a full http/https address."
										})
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ jsxs("section", {
						className: "space-y-4 border-t border-gray-200 pt-5",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
								className: "font-semibold text-brand-charcoal",
								children: "Social links"
							}), /* @__PURE__ */ jsx("p", {
								className: "text-xs text-gray-500",
								children: "Only links with a URL are shown on the site."
							})] }), /* @__PURE__ */ jsxs("button", {
								type: "button",
								className: btnGhost,
								disabled: form.social.length >= 12,
								onClick: () => {
									setSaved(false);
									setForm((f) => ({
										...f,
										social: [...f.social, {
											id: "link",
											label: "",
											url: ""
										}]
									}));
								},
								children: [/* @__PURE__ */ jsx(Plus, { size: 15 }), " Add link"]
							})]
						}), form.social.map((row, index) => /* @__PURE__ */ jsxs("div", {
							className: "grid gap-2 sm:grid-cols-[150px_1fr_1fr_auto]",
							children: [
								/* @__PURE__ */ jsxs("label", {
									className: "text-xs font-medium text-gray-600",
									children: ["Platform", /* @__PURE__ */ jsx("select", {
										className: `${inputClass} mt-1`,
										value: row.id,
										onChange: (e) => updateRow("social", index, "id", e.target.value),
										children: platforms.map((platform) => /* @__PURE__ */ jsx("option", {
											value: platform,
											children: platform === "x" ? "X" : platform[0].toUpperCase() + platform.slice(1)
										}, platform))
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "text-xs font-medium text-gray-600",
									children: ["Display name", /* @__PURE__ */ jsx("input", {
										className: `${inputClass} mt-1`,
										value: row.label,
										onChange: (e) => updateRow("social", index, "label", e.target.value)
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "text-xs font-medium text-gray-600",
									children: ["URL", /* @__PURE__ */ jsx("input", {
										type: "url",
										className: `${inputClass} mt-1`,
										value: row.url,
										onChange: (e) => updateRow("social", index, "url", e.target.value),
										placeholder: "https://…"
									})]
								}),
								/* @__PURE__ */ jsx("button", {
									type: "button",
									className: `${btnGhost} self-end text-red-700`,
									"aria-label": "Remove social link",
									onClick: () => {
										setSaved(false);
										setForm((f) => ({
											...f,
											social: f.social.filter((_, i) => i !== index)
										}));
									},
									children: /* @__PURE__ */ jsx(Trash2, { size: 15 })
								})
							]
						}, index))]
					}),
					/* @__PURE__ */ jsx("div", {
						className: "border-t border-gray-200 pt-5",
						children: /* @__PURE__ */ jsx("button", {
							type: "submit",
							className: btnYellow,
							disabled: busy || loading,
							children: busy ? "Saving…" : "Save website details"
						})
					})
				] })
			]
		})]
	});
}
//#endregion
//#region src/pages/admin/Admin.jsx
var TABS = [
	{
		id: "overview",
		label: "Overview",
		icon: LayoutDashboard
	},
	{
		id: "products",
		label: "Products & Shop",
		icon: Boxes
	},
	{
		id: "offers",
		label: "Offers",
		icon: BadgePercent
	},
	{
		id: "orders",
		label: "Orders",
		icon: PackageCheck
	},
	{
		id: "messages",
		label: "Messages",
		icon: Inbox
	},
	{
		id: "clicks",
		label: "Clicks",
		icon: MousePointerClick
	},
	{
		id: "customers",
		label: "Customers",
		icon: Users
	},
	{
		id: "settings",
		label: "Settings",
		icon: Settings
	}
];
function Screen({ children }) {
	return /* @__PURE__ */ jsx("div", {
		className: "flex min-h-screen items-center justify-center bg-brand-black px-4 py-10",
		children
	});
}
function AdminLogin() {
	const { login, logout } = useAuth();
	const [form, setForm] = useState({
		username: "",
		password: ""
	});
	const [error, setError] = useState("");
	const [busy, setBusy] = useState(false);
	const submit = async (event) => {
		event.preventDefault();
		setBusy(true);
		setError("");
		try {
			if ((await login(form.username, form.password)).role !== "admin") {
				await logout();
				setError("That account is not an administrator.");
			}
		} catch (e) {
			setError(e.message);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsx(Screen, { children: /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		className: "w-full max-w-sm space-y-4 rounded-2xl bg-white p-8 shadow-2xl",
		children: [
			/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
				className: "text-2xl font-bold text-brand-charcoal",
				children: "JOJO Admin"
			}), /* @__PURE__ */ jsx("p", {
				className: "mt-1 text-sm text-gray-500",
				children: "Sign in to manage products, offers and orders."
			})] }),
			error && /* @__PURE__ */ jsx(Notice, { children: error }),
			/* @__PURE__ */ jsxs("label", {
				className: "block text-sm font-medium text-gray-700",
				children: ["Username", /* @__PURE__ */ jsx("input", {
					required: true,
					autoFocus: true,
					autoComplete: "username",
					value: form.username,
					onChange: (e) => setForm({
						...form,
						username: e.target.value
					}),
					className: `${inputClass} mt-1`
				})]
			}),
			/* @__PURE__ */ jsxs("label", {
				className: "block text-sm font-medium text-gray-700",
				children: ["Password", /* @__PURE__ */ jsx("input", {
					type: "password",
					required: true,
					autoComplete: "current-password",
					value: form.password,
					onChange: (e) => setForm({
						...form,
						password: e.target.value
					}),
					className: `${inputClass} mt-1`
				})]
			}),
			/* @__PURE__ */ jsx("button", {
				type: "submit",
				disabled: busy,
				className: `${btnPrimary} w-full`,
				children: busy ? "Signing in…" : "Sign in"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "text-center text-xs text-gray-500",
				children: /* @__PURE__ */ jsx("a", {
					href: crossHref("/"),
					className: "underline",
					children: "Back to site"
				})
			})
		]
	}) });
}
function Admin() {
	const { user, ready, logout, setUser } = useAuth();
	const [tab, setTab] = useState("overview");
	useEffect(() => {
		applyPageMeta({
			title: "JOJO Admin",
			noindex: true
		});
	}, []);
	useEffect(() => {
		const onLogout = () => setUser(null);
		window.addEventListener("jojo-admin-logout", onLogout);
		return () => window.removeEventListener("jojo-admin-logout", onLogout);
	}, [setUser]);
	if (!ready) return /* @__PURE__ */ jsx(Screen, { children: /* @__PURE__ */ jsx("p", {
		className: "text-gray-300",
		children: "Loading…"
	}) });
	if (!user) return /* @__PURE__ */ jsx(AdminLogin, {});
	if (user.role !== "admin") return /* @__PURE__ */ jsx(Screen, { children: /* @__PURE__ */ jsxs("div", {
		className: "w-full max-w-sm space-y-4 rounded-2xl bg-white p-8 text-center shadow-2xl",
		children: [
			/* @__PURE__ */ jsx("h1", {
				className: "text-xl font-bold text-brand-charcoal",
				children: "Admins only"
			}),
			/* @__PURE__ */ jsxs("p", {
				className: "text-sm text-gray-600",
				children: [
					"You are signed in as ",
					user.name || user.username,
					", which is a customer account."
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex justify-center gap-3",
				children: [/* @__PURE__ */ jsx("a", {
					href: crossHref("/shop"),
					className: btnPrimary,
					children: "Back to shop"
				}), /* @__PURE__ */ jsx("button", {
					type: "button",
					onClick: logout,
					className: "rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-100",
					children: "Sign out"
				})]
			})
		]
	}) });
	if (user.mustChange) return /* @__PURE__ */ jsx(Screen, { children: /* @__PURE__ */ jsx(CredentialsForm, { forced: true }) });
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen bg-gray-50",
		children: [/* @__PURE__ */ jsxs("header", {
			className: "bg-brand-black text-white",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ jsxs("span", {
						className: "text-lg font-bold",
						children: ["JOJO ", /* @__PURE__ */ jsx("span", {
							className: "text-brand-yellow",
							children: "Admin"
						})]
					}), /* @__PURE__ */ jsx("a", {
						href: crossHref("/"),
						className: "text-xs text-gray-300 hover:text-white",
						children: "View site ↗"
					})]
				}), /* @__PURE__ */ jsxs("button", {
					type: "button",
					onClick: logout,
					className: "inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-200 hover:bg-white/10",
					children: [/* @__PURE__ */ jsx(LogOut, { size: 16 }), " Sign out"]
				})]
			}), /* @__PURE__ */ jsx("nav", {
				className: "mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 sm:px-6",
				"aria-label": "Admin sections",
				children: TABS.map(({ id, label, icon: Icon }) => /* @__PURE__ */ jsxs("button", {
					type: "button",
					onClick: () => setTab(id),
					"aria-current": tab === id ? "page" : void 0,
					className: `inline-flex shrink-0 items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition-colors ${tab === id ? "border-brand-yellow text-brand-yellow" : "border-transparent text-gray-300 hover:text-white"}`,
					children: [
						/* @__PURE__ */ jsx(Icon, { size: 16 }),
						" ",
						label
					]
				}, id))
			})]
		}), /* @__PURE__ */ jsxs("main", {
			className: "mx-auto max-w-7xl px-4 py-6 sm:px-6",
			children: [
				tab === "overview" && /* @__PURE__ */ jsx(Dashboard, { goTo: setTab }),
				tab === "products" && /* @__PURE__ */ jsx(ProductsTab, {}),
				tab === "offers" && /* @__PURE__ */ jsx(OffersTab, {}),
				tab === "orders" && /* @__PURE__ */ jsx(OrdersTab, {}),
				tab === "messages" && /* @__PURE__ */ jsx(MessagesTab, {}),
				tab === "clicks" && /* @__PURE__ */ jsx(ClicksTab, {}),
				tab === "customers" && /* @__PURE__ */ jsx(CustomersTab, {}),
				tab === "settings" && /* @__PURE__ */ jsx(SettingsTab, {})
			]
		})]
	});
}
//#endregion
//#region src/App.jsx
function PublicSite() {
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen flex flex-col",
		children: [
			/* @__PURE__ */ jsx(AnnouncementBar, {}),
			/* @__PURE__ */ jsx(Navigation, {}),
			/* @__PURE__ */ jsx("main", {
				className: "flex-grow",
				children: /* @__PURE__ */ jsxs(Routes, { children: [
					/* @__PURE__ */ jsx(Route, {
						path: "/",
						element: hostKind("/") === "shop" ? /* @__PURE__ */ jsx(Shop, {}) : /* @__PURE__ */ jsx(Home, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/about",
						element: /* @__PURE__ */ jsx(About, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/brands",
						element: /* @__PURE__ */ jsx(Brands, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/products",
						element: /* @__PURE__ */ jsx(Products, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/contact",
						element: /* @__PURE__ */ jsx(Contact, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/shop",
						element: /* @__PURE__ */ jsx(Shop, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/how-to-order",
						element: /* @__PURE__ */ jsx(HowToOrder, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/news",
						element: /* @__PURE__ */ jsx(News, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/news/:id/:slug?",
						element: /* @__PURE__ */ jsx(NewsPost, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/product/:id/:slug?",
						element: /* @__PURE__ */ jsx(ProductPage, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/category/:slug",
						element: /* @__PURE__ */ jsx(CategoryPage, {})
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/login",
						element: /* @__PURE__ */ jsx(Account, { mode: "login" })
					}),
					/* @__PURE__ */ jsx(Route, {
						path: "/signup",
						element: /* @__PURE__ */ jsx(Account, { mode: "signup" })
					})
				] })
			}),
			/* @__PURE__ */ jsx(Footer, {}),
			/* @__PURE__ */ jsx(WhatsAppWidget, {}),
			/* @__PURE__ */ jsx(CartDrawer, {}),
			/* @__PURE__ */ jsx(WhatsAppClickTracker, {}),
			/* @__PURE__ */ jsx(PageMeta, {})
		]
	});
}
function App() {
	return /* @__PURE__ */ jsxs(Routes, { children: [/* @__PURE__ */ jsx(Route, {
		path: "/admin/*",
		element: /* @__PURE__ */ jsx(Admin, {})
	}), /* @__PURE__ */ jsx(Route, {
		path: "*",
		element: /* @__PURE__ */ jsx(PublicSite, {})
	})] });
}
//#endregion
//#region src/auth/AuthProvider.jsx
function AuthProvider({ children }) {
	const [user, setUser] = useState(null);
	const [ready, setReady] = useState(false);
	useEffect(() => {
		let cancelled = false;
		api("/auth/me").then((data) => !cancelled && setUser(data.user)).catch(() => {}).finally(() => !cancelled && setReady(true));
		return () => {
			cancelled = true;
		};
	}, []);
	const login = useCallback(async (username, password) => {
		const data = await api("/auth/login", {
			method: "POST",
			body: {
				username,
				password
			}
		});
		setUser(data.user);
		return data.user;
	}, []);
	const signup = useCallback(async (fields) => {
		const data = await api("/auth/signup", {
			method: "POST",
			body: fields
		});
		setUser(data.user);
		return data.user;
	}, []);
	const logout = useCallback(async () => {
		try {
			await api("/auth/logout", {
				method: "POST",
				body: {}
			});
		} catch {}
		setUser(null);
	}, []);
	const value = useMemo(() => ({
		user,
		ready,
		login,
		signup,
		logout,
		setUser
	}), [
		user,
		ready,
		login,
		signup,
		logout
	]);
	return /* @__PURE__ */ jsx(AuthContext.Provider, {
		value,
		children
	});
}
//#endregion
//#region src/cart/cartStorage.js
var COOKIE = "jojo_cart";
var MAX_LINES = 12;
var MAX_QTY = 999;
var CART_LIMITS = {
	maxLines: MAX_LINES,
	maxQty: MAX_QTY
};
function clampQty(value) {
	const n = Math.floor(Number(value));
	return Math.min(MAX_QTY, Math.max(1, Number.isFinite(n) ? n : 1));
}
function encodeCart(items) {
	return items.map(({ id, qty }) => `${encodeURIComponent(id)}:${clampQty(qty)}`).join(",");
}
function decodeCart(text) {
	if (!text) return [];
	const items = [];
	for (const part of text.split(",")) {
		const cut = part.lastIndexOf(":");
		if (cut < 1) continue;
		let id = "";
		try {
			id = decodeURIComponent(part.slice(0, cut));
		} catch {
			continue;
		}
		if (id && !items.some((item) => item.id === id)) items.push({
			id,
			qty: clampQty(part.slice(cut + 1))
		});
		if (items.length >= MAX_LINES) break;
	}
	return items;
}
function readCart() {
	try {
		const match = document.cookie.split("; ").find((row) => row.startsWith(`${COOKIE}=`));
		return match ? decodeCart(decodeURIComponent(match.slice(10))) : [];
	} catch {
		return [];
	}
}
function writeCart(items) {
	try {
		const shared = hostKind(window.location.pathname) !== null ? `; domain=.${ROOT_DOMAIN}` : "";
		const secure = window.location.protocol === "https:" ? "; secure" : "";
		const expires = items.length ? `max-age=2592000` : "max-age=0";
		document.cookie = `${COOKIE}=${encodeURIComponent(encodeCart(items))}; path=/; ${expires}; samesite=lax${shared}${secure}`;
	} catch {}
}
//#endregion
//#region src/cart/CartProvider.jsx
function CartProvider({ children }) {
	const [items, setItems] = useState([]);
	const [isOpen, setIsOpen] = useState(false);
	const [notice, setNotice] = useState(null);
	const [ready, setReady] = useState(false);
	useEffect(() => {
		setItems(readCart());
		setReady(true);
	}, []);
	useEffect(() => {
		if (ready) writeCart(items);
	}, [items, ready]);
	useEffect(() => {
		if (!notice) return void 0;
		const timer = setTimeout(() => setNotice(null), 3500);
		return () => clearTimeout(timer);
	}, [notice]);
	const add = useCallback((product, qty = 1) => {
		setItems((current) => {
			if (current.find((item) => item.id === product.id)) return current.map((item) => item.id === product.id ? {
				...item,
				qty: clampQty(item.qty + qty)
			} : item);
			if (current.length >= CART_LIMITS.maxLines) {
				setNotice({
					text: `The cart holds up to ${CART_LIMITS.maxLines} different items. Send this order first.`,
					name: product.name,
					full: true
				});
				return current;
			}
			return [...current, {
				id: product.id,
				qty: clampQty(qty)
			}];
		});
		setNotice((current) => current?.full ? current : {
			text: "Added to cart",
			name: product.name
		});
	}, []);
	const setQty = useCallback((id, qty) => setItems((current) => current.map((item) => item.id === id ? {
		...item,
		qty: clampQty(qty)
	} : item)), []);
	const remove = useCallback((id) => setItems((current) => current.filter((item) => item.id !== id)), []);
	const clear = useCallback(() => setItems([]), []);
	const open = useCallback(() => {
		setItems(readCart());
		setIsOpen(true);
	}, []);
	const close = useCallback(() => setIsOpen(false), []);
	const value = useMemo(() => ({
		items,
		count: items.reduce((sum, item) => sum + item.qty, 0),
		isOpen,
		notice,
		add,
		setQty,
		remove,
		clear,
		open,
		close
	}), [
		items,
		isOpen,
		notice,
		add,
		setQty,
		remove,
		clear,
		open,
		close
	]);
	return /* @__PURE__ */ jsx(CartContext.Provider, {
		value,
		children
	});
}
//#endregion
//#region src/entry-server.jsx
function render(url, products, site = {}) {
	globalThis.__SSR_PRODUCTS__ = products;
	globalThis.__SSR_SETTINGS__ = site.settings;
	globalThis.__SSR_POSTS__ = site.posts || [];
	globalThis.__SSR_SITE__ = true;
	return renderToString(/* @__PURE__ */ jsx(StaticRouter, {
		location: url,
		children: /* @__PURE__ */ jsx(AuthProvider, { children: /* @__PURE__ */ jsx(CartProvider, { children: /* @__PURE__ */ jsx(App, {}) }) })
	}));
}
//#endregion
export { render };
